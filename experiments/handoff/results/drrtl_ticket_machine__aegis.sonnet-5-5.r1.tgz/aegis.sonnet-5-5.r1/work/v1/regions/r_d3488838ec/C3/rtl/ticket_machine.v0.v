module ticket_machine #(
    parameter ON  = 1'b1,
    parameter OFF = 1'b0
) (
    input  clk, clear, ten, twenty,
    output reg ready, dispense, return_sig, bill
);

    // use one-hot encoding to define states
    localparam RDY    = 6'b000001,
               DISP   = 6'b000010,
               RTN    = 6'b000100,
               BILL10 = 6'b001000,
               BILL20 = 6'b010000,
               BILL30 = 6'b100000;

    reg [5:0] State, NextState;

    // mutually exclusive select terms and flat clear masking
    wire sel_ten    = ten;
    wire sel_twenty = twenty & ~ten;
    wire [5:0] State_d = ({6{~clear}} & NextState) | {5'b00000, clear};

    // update state on clock rising edge
    always @(posedge clk) begin 
        State <= State_d;
    end

    // output logic based on current state (Moore state machine)
    always @(State) begin
        case (State)
            RDY:    begin
                ready     = ON;
                bill      = OFF;
                dispense  = OFF;
                return_sig = OFF;
            end

            DISP:   begin
                ready     = OFF;
                bill      = OFF;
                dispense  = ON;
                return_sig = OFF;
            end

            RTN:    begin
                ready     = OFF;
                bill      = OFF;
                dispense  = OFF;
                return_sig = ON;
            end

            BILL10: begin
                ready     = OFF;
                bill      = ON;
                dispense  = OFF;
                return_sig = OFF;
            end

            BILL20: begin
                ready     = OFF;
                bill      = ON;
                dispense  = OFF;
                return_sig = OFF;
            end

            BILL30: begin
                ready     = OFF;
                bill      = ON;
                dispense  = OFF;
                return_sig = OFF;
            end

            default: begin
                ready     = OFF;
                bill      = OFF;
                dispense  = OFF;
                return_sig = OFF;
            end
        endcase
    end

    // next state logic
    always @(State or ten or twenty) begin
        case (State)
            RDY:    begin
                if (sel_ten)
                    NextState = BILL10;
                else if (sel_twenty)
                    NextState = BILL20;
                else
                    NextState = RDY;
            end

            BILL10: begin
                if (sel_ten)
                    NextState = BILL20;
                else if (sel_twenty)
                    NextState = BILL30;
                else
                    NextState = BILL10;
            end

            BILL20: begin
                if (sel_ten)
                    NextState = BILL30;
                else if (sel_twenty)
                    NextState = DISP;
                else
                    NextState = BILL20;
            end

            BILL30: begin
                if (sel_ten)
                    NextState = DISP;
                else if (sel_twenty)
                    NextState = RTN;
                else
                    NextState = BILL30;
            end

            DISP:   begin
                    NextState = RDY;
            end

            RTN:    begin
                    NextState = RDY;
            end

            default: begin
                    NextState = RDY;
            end
        endcase
    end

endmodule