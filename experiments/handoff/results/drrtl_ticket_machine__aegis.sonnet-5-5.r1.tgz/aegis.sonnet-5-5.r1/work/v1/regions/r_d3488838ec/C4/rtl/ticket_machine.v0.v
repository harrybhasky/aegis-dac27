module ticket_machine #(
    parameter ON  = 1'b1,
    parameter OFF = 1'b0
) (
    input  clk, clear, ten, twenty,
    output reg ready, dispense, return_sig, bill
);

    // use one-hot encoding to define states
    localparam RDY    = 6'b000001,
               DISP   = 6'b000010,
               RTN    = 6'b000100,
               BILL10 = 6'b001000,
               BILL20 = 6'b010000,
               BILL30 = 6'b100000;

    reg [5:0] State, NextState;

    // flat, mutually exclusive next-state selection (single level)
    wire is_rdy = (State == RDY);
    wire is_b10 = (State == BILL10);
    wire is_b20 = (State == BILL20);
    wire is_b30 = (State == BILL30);
    wire any_a  = is_rdy | is_b10 | is_b20 | is_b30;

    wire sel_ten = ten;
    wire sel_twe = ~ten & twenty;
    wire sel_hld = ~ten & ~twenty;

    wire [5:0] ns_flat;
    assign ns_flat[0] = ~any_a | (is_rdy & sel_hld);
    assign ns_flat[1] = (is_b20 & sel_twe) | (is_b30 & sel_ten);
    assign ns_flat[2] = is_b30 & sel_twe;
    assign ns_flat[3] = (is_rdy & sel_ten) | (is_b10 & sel_hld);
    assign ns_flat[4] = (is_rdy & sel_twe) | (is_b10 & sel_ten) | (is_b20 & sel_hld);
    assign ns_flat[5] = (is_b10 & sel_twe) | (is_b20 & sel_ten) | (is_b30 & sel_hld);

    wire [5:0] st_d;
    assign st_d[0] = clear | ns_flat[0];
    assign st_d[5:1] = ns_flat[5:1] & {5{~clear}};

    // update state on clock rising edge
    always @(posedge clk) begin
        State <= st_d;
    end

    // output logic based on current state (Moore state machine)
    always @(State) begin
        case (State)
            RDY:    begin
                ready     = ON;
                bill      = OFF;
                dispense  = OFF;
                return_sig = OFF;
            end

            DISP:   begin
                ready     = OFF;
                bill      = OFF;
                dispense  = ON;
                return_sig = OFF;
            end

            RTN:    begin
                ready     = OFF;
                bill      = OFF;
                dispense  = OFF;
                return_sig = ON;
            end

            BILL10: begin
                ready     = OFF;
                bill      = ON;
                dispense  = OFF;
                return_sig = OFF;
            end

            BILL20: begin
                ready     = OFF;
                bill      = ON;
                dispense  = OFF;
                return_sig = OFF;
            end

            BILL30: begin
                ready     = OFF;
                bill      = ON;
                dispense  = OFF;
                return_sig = OFF;
            end

            default: begin
                ready     = OFF;
                bill      = OFF;
                dispense  = OFF;
                return_sig = OFF;
            end
        endcase
    end

    // next state logic
    always @(State or ten or twenty) begin
        case (State)
            RDY:    begin
                if (ten)
                    NextState = BILL10;
                else if (twenty)
                    NextState = BILL20;
                else
                    NextState = RDY;
            end

            BILL10: begin
                if (ten)
                    NextState = BILL20;
                else if (twenty)
                    NextState = BILL30;
                else
                    NextState = BILL10;
            end

            BILL20: begin
                if (ten)
                    NextState = BILL30;
                else if (twenty)
                    NextState = DISP;
                else
                    NextState = BILL20;
            end

            BILL30: begin
                if (ten)
                    NextState = DISP;
                else if (twenty)
                    NextState = RTN;
                else
                    NextState = BILL30;
            end

            DISP:   begin
                    NextState = RDY;
            end

            RTN:    begin
                    NextState = RDY;
            end

            default: begin
                    NextState = RDY;
            end
        endcase
    end

endmodule