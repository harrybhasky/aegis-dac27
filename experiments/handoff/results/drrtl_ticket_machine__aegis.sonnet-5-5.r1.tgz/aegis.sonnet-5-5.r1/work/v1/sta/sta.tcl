read_liberty /home/lalit/Documents/dev/aegis-dac27/aegis_agents/pdk/nangate45.lib
read_verilog /home/lalit/Documents/dev/aegis-dac27/aegis_agents/flow/runs/drrtl_ticket_machine/aegis.sonnet-5-5.r1/work/v1/sta/netlist.v
link_design ticket_machine
read_sdc /home/lalit/Documents/dev/aegis-dac27/aegis_agents/flow/designs/drrtl_ticket_machine/drrtl_ticket_machine.sdc
set ::env(AEGIS_MARGIN) 0.0
set ::env(AEGIS_STA_RPT) /home/lalit/Documents/dev/aegis-dac27/aegis_agents/flow/runs/drrtl_ticket_machine/aegis.sonnet-5-5.r1/work/v1/sta/endpoints.rpt
source /home/lalit/Documents/dev/aegis-dac27/aegis_agents/tools/sta_endpoints.tcl
report_checks -path_delay max -format full -group_path_count 1 > /home/lalit/Documents/dev/aegis-dac27/aegis_agents/flow/runs/drrtl_ticket_machine/aegis.sonnet-5-5.r1/work/v1/sta/groups.rpt
report_checks -unconstrained -path_delay max -format end -group_path_count 5 > /home/lalit/Documents/dev/aegis-dac27/aegis_agents/flow/runs/drrtl_ticket_machine/aegis.sonnet-5-5.r1/work/v1/sta/unconstrained.rpt
exit