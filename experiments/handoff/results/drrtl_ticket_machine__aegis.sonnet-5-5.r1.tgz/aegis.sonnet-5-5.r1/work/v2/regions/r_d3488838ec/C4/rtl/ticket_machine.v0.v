module ticket_machine #(
    parameter ON  = 1'b1,
    parameter OFF = 1'b0
) (
    input  clk, clear, ten, twenty,
    output reg ready, dispense, return_sig, bill
);

    // use one-hot encoding to define states
    localparam RDY    = 6'b000001,
               DISP   = 6'b000010,
               RTN    = 6'b000100,
               BILL10 = 6'b001000,
               BILL20 = 6'b010000,
               BILL30 = 6'b100000;

    reg [5:0] State, NextState;

    // direct one-hot bit-indexed next-state equations
    // shared coin-decode conditions, built once and reused by every branch
    wire any_coin = ten | twenty;
    wire no_coin  = ~any_coin;
    wire only_20  = ~ten & twenty;

    // shared state/coin prefix terms
    wire s0_nc = State[0] & no_coin;
    wire s0_t  = State[0] & ten;
    wire s0_20 = State[0] & only_20;
    wire s3_nc = State[3] & no_coin;
    wire s3_t  = State[3] & ten;
    wire s3_20 = State[3] & only_20;
    wire s4_nc = State[4] & no_coin;
    wire s4_t  = State[4] & ten;
    wire s4_20 = State[4] & only_20;
    wire s5_nc = State[5] & no_coin;
    wire s5_t  = State[5] & ten;
    wire s5_20 = State[5] & only_20;

    wire [5:0] ns_fast;
    assign ns_fast[0] = s0_nc | State[1] | State[2];
    assign ns_fast[1] = s4_20 | s5_t;
    assign ns_fast[2] = s5_20;
    assign ns_fast[3] = s0_t | s3_nc;
    assign ns_fast[4] = s0_20 | s3_t | s4_nc;
    assign ns_fast[5] = s3_20 | s4_t | s5_nc;

    // update state on clock rising edge
    // synchronous clear folded into the next-state wires
    wire [5:0] ns_final = clear ? RDY : ns_fast;

    always @(posedge clk) begin 
        State <= ns_final;
    end

    // output logic based on current state (Moore state machine)
    always @(State) begin
        case (State)
            RDY:    begin
                ready     = ON;
                bill      = OFF;
                dispense  = OFF;
                return_sig = OFF;
            end

            DISP:   begin
                ready     = OFF;
                bill      = OFF;
                dispense  = ON;
                return_sig = OFF;
            end

            RTN:    begin
                ready     = OFF;
                bill      = OFF;
                dispense  = OFF;
                return_sig = ON;
            end

            BILL10: begin
                ready     = OFF;
                bill      = ON;
                dispense  = OFF;
                return_sig = OFF;
            end

            BILL20: begin
                ready     = OFF;
                bill      = ON;
                dispense  = OFF;
                return_sig = OFF;
            end

            BILL30: begin
                ready     = OFF;
                bill      = ON;
                dispense  = OFF;
                return_sig = OFF;
            end

            default: begin
                ready     = OFF;
                bill      = OFF;
                dispense  = OFF;
                return_sig = OFF;
            end
        endcase
    end

    // next state logic
    always @(State or ten or twenty) begin
        case (State)
            RDY:    begin
                if (ten)
                    NextState = BILL10;
                else if (twenty)
                    NextState = BILL20;
                else
                    NextState = RDY;
            end

            BILL10: begin
                if (ten)
                    NextState = BILL20;
                else if (twenty)
                    NextState = BILL30;
                else
                    NextState = BILL10;
            end

            BILL20: begin
                if (ten)
                    NextState = BILL30;
                else if (twenty)
                    NextState = DISP;
                else
                    NextState = BILL20;
            end

            BILL30: begin
                if (ten)
                    NextState = DISP;
                else if (twenty)
                    NextState = RTN;
                else
                    NextState = BILL30;
            end

            DISP:   begin
                    NextState = RDY;
            end

            RTN:    begin
                    NextState = RDY;
            end

            default: begin
                    NextState = RDY;
            end
        endcase
    end

endmodule