module ticket_machine #(
    parameter ON  = 1'b1,
    parameter OFF = 1'b0
) (
    input  clk, clear, ten, twenty,
    output reg ready, dispense, return_sig, bill
);

    // use one-hot encoding to define states
    localparam RDY    = 6'b000001,
               DISP   = 6'b000010,
               RTN    = 6'b000100,
               BILL10 = 6'b001000,
               BILL20 = 6'b010000,
               BILL30 = 6'b100000;

    reg [5:0] State, NextState;

    // direct one-hot bit-indexed next-state equations
    wire no_coin = ~ten & ~twenty;
    wire only_20 = ~ten & twenty;
    wire [5:0] ns_fast;

    // exact state predecode (matches the original case on all 64 encodings)
    wire is0 = (State == RDY);
    wire is1 = (State == DISP);
    wire is2 = (State == RTN);
    wire is3 = (State == BILL10);
    wire is4 = (State == BILL20);
    wire is5 = (State == BILL30);
    wire illegal = ~(is0 | is1 | is2 | is3 | is4 | is5);

    // shared state/coin product terms, each built once
    wire s0_none = is0 & no_coin;
    wire s0_ten  = is0 & ten;
    wire s0_20   = is0 & only_20;
    wire s3_none = is3 & no_coin;
    wire s3_ten  = is3 & ten;
    wire s3_20   = is3 & only_20;
    wire s4_none = is4 & no_coin;
    wire s4_ten  = is4 & ten;
    wire s4_20   = is4 & only_20;
    wire s5_none = is5 & no_coin;
    wire s5_ten  = is5 & ten;
    wire s5_20   = is5 & only_20;

    assign ns_fast[0] = s0_none | is1 | is2 | illegal;
    assign ns_fast[1] = s4_20 | s5_ten;
    assign ns_fast[2] = s5_20;
    assign ns_fast[3] = s0_ten | s3_none;
    assign ns_fast[4] = s0_20 | s3_ten | s4_none;
    assign ns_fast[5] = s3_20 | s4_ten | s5_none;

    // update state on clock rising edge
    always @(posedge clk) begin
        if (clear)
            State <= RDY;
        else
            State <= ns_fast;
    end

    // output logic based on current state (Moore state machine)
    always @(State) begin
        case (State)
            RDY:    begin
                ready     = ON;
                bill      = OFF;
                dispense  = OFF;
                return_sig = OFF;
            end

            DISP:   begin
                ready     = OFF;
                bill      = OFF;
                dispense  = ON;
                return_sig = OFF;
            end

            RTN:    begin
                ready     = OFF;
                bill      = OFF;
                dispense  = OFF;
                return_sig = ON;
            end

            BILL10: begin
                ready     = OFF;
                bill      = ON;
                dispense  = OFF;
                return_sig = OFF;
            end

            BILL20: begin
                ready     = OFF;
                bill      = ON;
                dispense  = OFF;
                return_sig = OFF;
            end

            BILL30: begin
                ready     = OFF;
                bill      = ON;
                dispense  = OFF;
                return_sig = OFF;
            end

            default: begin
                ready     = OFF;
                bill      = OFF;
                dispense  = OFF;
                return_sig = OFF;
            end
        endcase
    end

    // next state logic
    always @(State or ten or twenty) begin
        case (State)
            RDY:    begin
                if (ten)
                    NextState = BILL10;
                else if (twenty)
                    NextState = BILL20;
                else
                    NextState = RDY;
            end

            BILL10: begin
                if (ten)
                    NextState = BILL20;
                else if (twenty)
                    NextState = BILL30;
                else
                    NextState = BILL10;
            end

            BILL20: begin
                if (ten)
                    NextState = BILL30;
                else if (twenty)
                    NextState = DISP;
                else
                    NextState = BILL20;
            end

            BILL30: begin
                if (ten)
                    NextState = DISP;
                else if (twenty)
                    NextState = RTN;
                else
                    NextState = BILL30;
            end

            DISP:   begin
                    NextState = RDY;
            end

            RTN:    begin
                    NextState = RDY;
            end

            default: begin
                    NextState = RDY;
            end
        endcase
    end

endmodule