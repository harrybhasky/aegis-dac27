`timescale 1ns / 10ps



`define I2C_CMD_NOP   4'b0000
`define I2C_CMD_START 4'b0001
`define I2C_CMD_STOP  4'b0010
`define I2C_CMD_WRITE 4'b0100
`define I2C_CMD_READ  4'b1000


module i2c_master_bit_ctrl(
	clk, rst, nReset, 
	clk_cnt, ena, cmd, cmd_ack, busy, al, din, dout,
	scl_i, scl_o, scl_oen, sda_i, sda_o, sda_oen
	);

	input clk;
	input rst;
	input nReset;
	input ena;

	input [15:0] clk_cnt;

	input  [3:0] cmd;
	output       cmd_ack;
	reg cmd_ack;
	output       busy;
	reg busy;
	output       al;
	reg al;

	input  din;
	output dout;
	reg dout;

	input  scl_i;
	output scl_o;
	output scl_oen;
	reg scl_oen;
	input  sda_i;
	output sda_o;
	output sda_oen;
	reg sda_oen;

	reg sSCL, sSDA;
	reg dscl_oen;
	reg sda_chk;
	reg clk_en;
	wire slave_wait;
	reg [15:0] cnt;

	reg [16:0] c_state; 

	always @(posedge clk)
	  dscl_oen <= #1 scl_oen;

	assign slave_wait = dscl_oen && !sSCL;

	// ------------------------------------------------------------
	// clock divider: balanced zero detect, borrow lookahead, flat select
	// ------------------------------------------------------------
	wire z0 = ~|cnt[3:0];
	wire z1 = ~|cnt[7:4];
	wire z2 = ~|cnt[11:8];
	wire z3 = ~|cnt[15:12];
	wire z01  = z0 & z1;
	wire z012 = z01 & z2;
	wire cnt_zero = z01 & (z2 & z3);

	wire [15:0] lz;   // lz[i] = all lower bits of cnt are zero
	assign lz[0]  = 1'b1;
	assign lz[1]  = ~cnt[0];
	assign lz[2]  = ~(cnt[0] | cnt[1]);
	assign lz[3]  = ~(cnt[0] | cnt[1] | cnt[2]);
	assign lz[4]  = z0;
	assign lz[5]  = z0 & ~cnt[4];
	assign lz[6]  = z0 & ~(cnt[4] | cnt[5]);
	assign lz[7]  = z0 & ~(cnt[4] | cnt[5] | cnt[6]);
	assign lz[8]  = z01;
	assign lz[9]  = z01 & ~cnt[8];
	assign lz[10] = z01 & ~(cnt[8] | cnt[9]);
	assign lz[11] = z01 & ~(cnt[8] | cnt[9] | cnt[10]);
	assign lz[12] = z012;
	assign lz[13] = z012 & ~cnt[12];
	assign lz[14] = z012 & ~(cnt[12] | cnt[13]);
	assign lz[15] = z012 & ~(cnt[12] | cnt[13] | cnt[14]);

	wire [15:0] cnt_dec = cnt ^ lz;

	wire reload_or_hold = cnt_zero | ~ena;
	wire do_load = reload_or_hold & ~slave_wait;
	wire do_hold = reload_or_hold &  slave_wait;

	wire [15:0] cnt_next = do_load ? clk_cnt : (do_hold ? cnt : cnt_dec);

	always @(posedge clk or negedge nReset)
	  if(~nReset)
	    begin
	        cnt    <= #1 16'h0;
	        clk_en <= #1 1'b1;
	    end
	  else if (rst)
	    begin
	        cnt    <= #1 16'h0;
	        clk_en <= #1 1'b1;
	    end
	  else
	    begin
	        cnt    <= #1 cnt_next;
	        clk_en <= #1 do_load;
	    end


	// generate bus status controller
	reg dSCL, dSDA;
	reg sta_condition;
	reg sto_condition;

	always @(posedge clk or negedge nReset)
	  if (~nReset)
	    begin
	        sSCL <= #1 1'b1;
	        sSDA <= #1 1'b1;

	        dSCL <= #1 1'b1;
	        dSDA <= #1 1'b1;
	    end
	  else if (rst)
	    begin
	        sSCL <= #1 1'b1;
	        sSDA <= #1 1'b1;

	        dSCL <= #1 1'b1;
	        dSDA <= #1 1'b1;
	    end
	  else
	    begin
	        sSCL <= #1 scl_i;
	        sSDA <= #1 sda_i;

	        dSCL <= #1 sSCL;
	        dSDA <= #1 sSDA;
	    end

	always @(posedge clk or negedge nReset)
	  if (~nReset)
	    begin
	        sta_condition <= #1 1'b0;
	        sto_condition <= #1 1'b0;
	    end
	  else if (rst)
	    begin
	        sta_condition <= #1 1'b0;
	        sto_condition <= #1 1'b0;
	    end
	  else
	    begin
	        sta_condition <= #1 ~sSDA &  dSDA & sSCL;
	        sto_condition <= #1  sSDA & ~dSDA & sSCL;
	    end

	always @(posedge clk or negedge nReset)
	  if(!nReset)
	    busy <= #1 1'b0;
	  else if (rst)
	    busy <= #1 1'b0;
	  else
	    busy <= #1 (sta_condition | busy) & ~sto_condition;

	reg cmd_stop;
	always @(posedge clk or negedge nReset)
	  if (~nReset)
	    cmd_stop <= #1 1'b0;
	  else if (rst)
	    cmd_stop <= #1 1'b0;
	  else if (clk_en)
	    cmd_stop <= #1 cmd == `I2C_CMD_STOP;

	// state not idle (balanced OR tree)
	wire st_or_a = |c_state[3:0];
	wire st_or_b = |c_state[7:4];
	wire st_or_c = |c_state[11:8];
	wire st_or_d = |c_state[15:12];
	wire st_or_e = c_state[16];
	wire not_idle = (st_or_a | st_or_b) | (st_or_c | st_or_d) | st_or_e;
	wire s_idle = ~not_idle;

	always @(posedge clk or negedge nReset)
	  if (~nReset)
	    al <= #1 1'b0;
	  else if (rst)
	    al <= #1 1'b0;
	  else
	    al <= #1 (sda_chk & ~sSDA & sda_oen) | (not_idle & sto_condition & ~cmd_stop);


	always @(posedge clk)
	  if(sSCL & ~dSCL)
	    dout <= #1 sSDA;

	// generate statemachine

	parameter [16:0] idle    = 17'b0_0000_0000_0000_0000;
	parameter [16:0] start_a = 17'b0_0000_0000_0000_0001;
	parameter [16:0] start_b = 17'b0_0000_0000_0000_0010;
	parameter [16:0] start_c = 17'b0_0000_0000_0000_0100;
	parameter [16:0] start_d = 17'b0_0000_0000_0000_1000;
	parameter [16:0] start_e = 17'b0_0000_0000_0001_0000;
	parameter [16:0] stop_a  = 17'b0_0000_0000_0010_0000;
	parameter [16:0] stop_b  = 17'b0_0000_0000_0100_0000;
	parameter [16:0] stop_c  = 17'b0_0000_0000_1000_0000;
	parameter [16:0] stop_d  = 17'b0_0000_0001_0000_0000;
	parameter [16:0] rd_a    = 17'b0_0000_0010_0000_0000;
	parameter [16:0] rd_b    = 17'b0_0000_0100_0000_0000;
	parameter [16:0] rd_c    = 17'b0_0000_1000_0000_0000;
	parameter [16:0] rd_d    = 17'b0_0001_0000_0000_0000;
	parameter [16:0] wr_a    = 17'b0_0010_0000_0000_0000;
	parameter [16:0] wr_b    = 17'b0_0100_0000_0000_0000;
	parameter [16:0] wr_c    = 17'b0_1000_0000_0000_0000;
	parameter [16:0] wr_d    = 17'b1_0000_0000_0000_0000;

	// one-hot state bit aliases
	wire start_a_s = c_state[0];
	wire start_b_s = c_state[1];
	wire start_c_s = c_state[2];
	wire start_d_s = c_state[3];
	wire start_e_s = c_state[4];
	wire stop_a_s  = c_state[5];
	wire stop_b_s  = c_state[6];
	wire stop_c_s  = c_state[7];
	wire stop_d_s  = c_state[8];
	wire rd_a_s    = c_state[9];
	wire rd_b_s    = c_state[10];
	wire rd_c_s    = c_state[11];
	wire rd_d_s    = c_state[12];
	wire wr_a_s    = c_state[13];
	wire wr_b_s    = c_state[14];
	wire wr_c_s    = c_state[15];
	wire wr_d_s    = c_state[16];

	// command decode (once)
	wire cmd_is_start = (cmd == `I2C_CMD_START);
	wire cmd_is_stop  = (cmd == `I2C_CMD_STOP);
	wire cmd_is_write = (cmd == `I2C_CMD_WRITE);
	wire cmd_is_read  = (cmd == `I2C_CMD_READ);

	wire go_start_a = s_idle & cmd_is_start;
	wire go_stop_a  = s_idle & cmd_is_stop;
	wire go_wr_a    = s_idle & cmd_is_write;
	wire go_rd_a    = s_idle & cmd_is_read;

	// next-state bits (shift chain), gated by clk_en
	wire [16:0] pred;
	assign pred[0]  = go_start_a;
	assign pred[1]  = start_a_s;
	assign pred[2]  = start_b_s;
	assign pred[3]  = start_c_s;
	assign pred[4]  = start_d_s;
	assign pred[5]  = go_stop_a;
	assign pred[6]  = stop_a_s;
	assign pred[7]  = stop_b_s;
	assign pred[8]  = stop_c_s;
	assign pred[9]  = go_rd_a;
	assign pred[10] = rd_a_s;
	assign pred[11] = rd_b_s;
	assign pred[12] = rd_c_s;
	assign pred[13] = go_wr_a;
	assign pred[14] = wr_a_s;
	assign pred[15] = wr_b_s;
	assign pred[16] = wr_c_s;

	wire [16:0] c_state_next = clk_en ? pred : c_state;

	// output equations
	wire ack_state = start_e_s | stop_d_s | rd_d_s | wr_d_s;

	wire scl_set1 = (start_b_s | start_c_s) | (start_d_s | stop_b_s) | (stop_c_s | stop_d_s)
	              | (rd_b_s | rd_c_s) | (wr_b_s | wr_c_s);
	wire scl_set0 = (start_e_s | stop_a_s) | (rd_a_s | rd_d_s) | (wr_a_s | wr_d_s);
	wire scl_do1  = clk_en & scl_set1;
	wire scl_do0  = clk_en & scl_set0;
	wire scl_oen_next = scl_do1 | (scl_oen & ~scl_do0);

	wire sda_one  = (start_a_s | start_b_s) | stop_d_s | (rd_a_s | rd_b_s) | (rd_c_s | rd_d_s);
	wire sda_wr   = (wr_a_s | wr_b_s) | (wr_c_s | wr_d_s);
	wire sda_oen_c = sda_one | (sda_wr & din) | (s_idle & sda_oen);
	wire sda_oen_next = clk_en ? sda_oen_c : sda_oen;

	wire sda_chk_next = clk_en ? (wr_b_s | wr_c_s) : sda_chk;

	always @(posedge clk or negedge nReset)
	  if (!nReset)
	    begin
	        c_state <= #1 idle;
	        cmd_ack <= #1 1'b0;
	        scl_oen <= #1 1'b1;
	        sda_oen <= #1 1'b1;
	        sda_chk <= #1 1'b0;
	    end
	  else if (rst | al)
	    begin
	        c_state <= #1 idle;
	        cmd_ack <= #1 1'b0;
	        scl_oen <= #1 1'b1;
	        sda_oen <= #1 1'b1;
	        sda_chk <= #1 1'b0;
	    end
	  else
	    begin
	        c_state <= #1 c_state_next;
	        cmd_ack <= #1 clk_en & ack_state;
	        scl_oen <= #1 scl_oen_next;
	        sda_oen <= #1 sda_oen_next;
	        sda_chk <= #1 sda_chk_next;
	    end


	assign scl_o = 1'b0;
	assign sda_o = 1'b0;

endmodule


module i2c_master_byte_ctrl (
	clk, rst, nReset, ena, clk_cnt, start, stop, read, write, ack_in, din,
	cmd_ack, ack_out, dout, i2c_busy, i2c_al, scl_i, scl_o, scl_oen, sda_i, sda_o, sda_oen );

	input clk;
	input rst;
	input nReset;
	input ena;

	input [15:0] clk_cnt;

	input       start;
	input       stop;
	input       read;
	input       write;
	input       ack_in;
	input [7:0] din;

	output       cmd_ack;
	reg cmd_ack;
	output       ack_out;
	reg ack_out;
	output       i2c_busy;
	output       i2c_al;
	output [7:0] dout;

	input  scl_i;
	output scl_o;
	output scl_oen;
	input  sda_i;
	output sda_o;
	output sda_oen;

	parameter [4:0] ST_IDLE  = 5'b0_0000;
	parameter [4:0] ST_START = 5'b0_0001;
	parameter [4:0] ST_READ  = 5'b0_0010;
	parameter [4:0] ST_WRITE = 5'b0_0100;
	parameter [4:0] ST_ACK   = 5'b0_1000;
	parameter [4:0] ST_STOP  = 5'b1_0000;

	reg  [3:0] core_cmd;
	reg        core_txd;
	wire       core_ack, core_rxd;

	reg [7:0] sr;
	reg       shift, ld;

	wire       go;
	reg  [2:0] dcnt;
	wire       cnt_done;

	i2c_master_bit_ctrl bit_controller (
		.clk     ( clk      ),
		.rst     ( rst      ),
		.nReset  ( nReset   ),
		.ena     ( ena      ),
		.clk_cnt ( clk_cnt  ),
		.cmd     ( core_cmd ),
		.cmd_ack ( core_ack ),
		.busy    ( i2c_busy ),
		.al      ( i2c_al   ),
		.din     ( core_txd ),
		.dout    ( core_rxd ),
		.scl_i   ( scl_i    ),
		.scl_o   ( scl_o    ),
		.scl_oen ( scl_oen  ),
		.sda_i   ( sda_i    ),
		.sda_o   ( sda_o    ),
		.sda_oen ( sda_oen  )
	);

	assign go = (read | write | stop) & ~cmd_ack;

	assign dout = sr;

	// shared ld/shift selects
	wire sel_ld    = ld;
	wire sel_shift = ~ld & shift;

	always @(posedge clk or negedge nReset)
	  if (!nReset)
	    sr <= #1 8'h0;
	  else if (rst)
	    sr <= #1 8'h0;
	  else if (sel_ld)
	    sr <= #1 din;
	  else if (sel_shift)
	    sr <= #1 {sr[6:0], core_rxd};

	// dcnt-1 with explicit borrow lookahead
	wire [2:0] dcnt_dec;
	assign dcnt_dec[0] = ~dcnt[0];
	assign dcnt_dec[1] = dcnt[1] ^ ~dcnt[0];
	assign dcnt_dec[2] = dcnt[2] ^ (~dcnt[0] & ~dcnt[1]);

	always @(posedge clk or negedge nReset)
	  if (!nReset)
	    dcnt <= #1 3'h0;
	  else if (rst)
	    dcnt <= #1 3'h0;
	  else if (sel_ld)
	    dcnt <= #1 3'h7;
	  else if (sel_shift)
	    dcnt <= #1 dcnt_dec;

	assign cnt_done = ~(|dcnt);

	//
	// state machine (one-hot bit tests)
	//
	reg [4:0] c_state;

	wire st_start = c_state[0];
	wire st_read  = c_state[1];
	wire st_write = c_state[2];
	wire st_ack   = c_state[3];
	wire st_stop  = c_state[4];
	wire st_idle  = ~((c_state[0] | c_state[1]) | (c_state[2] | c_state[3]) | c_state[4]);

	// idle transitions
	wire go_i       = st_idle & go;
	wire idle_start = go_i & start;
	wire idle_read  = go_i & ~start & read;
	wire idle_write = go_i & ~start & ~read & write;
	wire idle_stop  = go_i & ~start & ~read & ~write;

	// core_ack qualified terms
	wire sa = st_start & core_ack;
	wire wa = st_write & core_ack;
	wire ra = st_read  & core_ack;
	wire aa = st_ack   & core_ack;
	wire pa = st_stop  & core_ack;

	wire sa_read  = sa & read;
	wire sa_write = sa & ~read;
	wire wa_done  = wa & cnt_done;
	wire wa_more  = wa & ~cnt_done;
	wire ra_done  = ra & cnt_done;
	wire ra_more  = ra & ~cnt_done;
	wire aa_stop  = aa & stop;
	wire aa_idle  = aa & ~stop;

	// next state bits
	wire n_start = idle_start | (st_start & ~core_ack);
	wire n_read  = idle_read  | sa_read  | (st_read  & ~(core_ack & cnt_done));
	wire n_write = idle_write | sa_write | (st_write & ~(core_ack & cnt_done));
	wire n_ack   = wa_done | ra_done | (st_ack & ~core_ack);
	wire n_stop  = idle_stop | aa_stop | (st_stop & ~core_ack);

	// command encoding terms
	wire c_start = idle_start;
	wire c_read  = idle_read  | sa_read  | ra_more | wa_done;
	wire c_write = idle_write | sa_write | wa_more | ra_done;
	wire c_stop  = idle_stop  | aa_stop;
	wire c_nop   = aa_idle | pa;
	wire c_chg   = (c_start | c_read) | (c_write | c_stop) | c_nop;

	wire [3:0] core_cmd_next;
	assign core_cmd_next[0] = c_start | (core_cmd[0] & ~c_chg);
	assign core_cmd_next[1] = c_stop  | (core_cmd[1] & ~c_chg);
	assign core_cmd_next[2] = c_write | (core_cmd[2] & ~c_chg);
	assign core_cmd_next[3] = c_read  | (core_cmd[3] & ~c_chg);

	wire ld_next      = go_i | sa;
	wire shift_next   = wa_more | ra;
	wire cmd_ack_next = aa_idle | pa;
	wire txd_next     = st_ack ? (core_ack | ack_in) : (ra ? ack_in : sr[7]);

	always @(posedge clk or negedge nReset)
	  if (!nReset)
	    begin
	        core_cmd <= #1 `I2C_CMD_NOP;
	        core_txd <= #1 1'b0;
	        shift    <= #1 1'b0;
	        ld       <= #1 1'b0;
	        cmd_ack  <= #1 1'b0;
	        c_state  <= #1 ST_IDLE;
	        ack_out  <= #1 1'b0;
	    end
	  else if (rst | i2c_al)
	   begin
	       core_cmd <= #1 `I2C_CMD_NOP;
	       core_txd <= #1 1'b0;
	       shift    <= #1 1'b0;
	       ld       <= #1 1'b0;
	       cmd_ack  <= #1 1'b0;
	       c_state  <= #1 ST_IDLE;
	       ack_out  <= #1 1'b0;
	   end
	else
	  begin
	      core_txd <= #1 txd_next;
	      shift    <= #1 shift_next;
	      ld       <= #1 ld_next;
	      cmd_ack  <= #1 cmd_ack_next;
	      core_cmd <= #1 core_cmd_next;
	      c_state  <= #1 {n_stop, n_ack, n_write, n_read, n_start};
	      if (aa)
	        ack_out <= #1 core_rxd;
	  end
endmodule


module i2c_master_top(
	wb_clk_i, wb_rst_i, arst_i, wb_adr_i, wb_dat_i, wb_dat_o,
	wb_we_i, wb_stb_i, wb_cyc_i, wb_ack_o, wb_inta_o,
	scl_pad_i, scl_pad_o, scl_padoen_o, sda_pad_i, sda_pad_o, sda_padoen_o );

	parameter ARST_LVL = 1'b0;

	input        wb_clk_i;
	input        wb_rst_i;
	input        arst_i;
	input  [2:0] wb_adr_i;
	input  [7:0] wb_dat_i;
	output [7:0] wb_dat_o;
	input        wb_we_i;
	input        wb_stb_i;
	input        wb_cyc_i;
	output       wb_ack_o;
	output       wb_inta_o;

	reg [7:0] wb_dat_o;
	reg wb_ack_o;
	reg wb_inta_o;

	input  scl_pad_i;
	output scl_pad_o;
	output scl_padoen_o;

	input  sda_pad_i;
	output sda_pad_o;
	output sda_padoen_o;

	reg  [15:0] prer;
	reg  [ 7:0] ctr;
	reg  [ 7:0] txr;
	wire [ 7:0] rxr;
	reg  [ 7:0] cr;
	wire [ 7:0] sr;

	wire done;

	wire core_en;
	wire ien;

	wire irxack;
	reg  rxack;
	reg  tip;
	reg  irq_flag;
	wire i2c_busy;
	wire i2c_al;
	reg  al;

	wire rst_i = arst_i ^ ARST_LVL;

	wire wb_wacc = wb_cyc_i & wb_stb_i & wb_we_i;

	always @(posedge wb_clk_i)
	  wb_ack_o <= #1 wb_cyc_i & wb_stb_i & ~wb_ack_o;

	always @(posedge wb_clk_i)
	begin
	  case (wb_adr_i)
	    3'b000: wb_dat_o <= #1 prer[ 7:0];
	    3'b001: wb_dat_o <= #1 prer[15:8];
	    3'b010: wb_dat_o <= #1 ctr;
	    3'b011: wb_dat_o <= #1 rxr;
	    3'b100: wb_dat_o <= #1 sr;
	    3'b101: wb_dat_o <= #1 txr;
	    3'b110: wb_dat_o <= #1 cr;
	    3'b111: wb_dat_o <= #1 0;
	  endcase
	end

	always @(posedge wb_clk_i or negedge rst_i)
	  if (!rst_i)
	    begin
	        prer <= #1 16'hffff;
	        ctr  <= #1  8'h0;
	        txr  <= #1  8'h0;
	    end
	  else if (wb_rst_i)
	    begin
	        prer <= #1 16'hffff;
	        ctr  <= #1  8'h0;
	        txr  <= #1  8'h0;
	    end
	  else
	    if (wb_wacc)
	      case (wb_adr_i)
	         3'b000 : prer [ 7:0] <= #1 wb_dat_i;
	         3'b001 : prer [15:8] <= #1 wb_dat_i;
	         3'b010 : ctr         <= #1 wb_dat_i;
	         3'b011 : txr         <= #1 wb_dat_i;
	         default: ;
	      endcase

	always @(posedge wb_clk_i or negedge rst_i)
	  if (~rst_i)
	    cr <= #1 8'h0;
	  else if (wb_rst_i)
	    cr <= #1 8'h0;
	  else if (wb_wacc)
	    begin
	        if (core_en & (wb_adr_i == 3'b100) )
	          cr <= #1 wb_dat_i;
	    end
	  else
	    begin
	        if (done | i2c_al)
	          cr[7:4] <= #1 4'h0;
	        cr[2:1] <= #1 2'b0;
	        cr[0]   <= #1 2'b0;
	    end

	wire sta  = cr[7];
	wire sto  = cr[6];
	wire rd   = cr[5];
	wire wr   = cr[4];
	wire ack  = cr[3];
	wire iack = cr[0];

	assign core_en = ctr[7];
	assign ien = ctr[6];

	i2c_master_byte_ctrl byte_controller (
		.clk      ( wb_clk_i     ),
		.rst      ( wb_rst_i     ),
		.nReset   ( rst_i        ),
		.ena      ( core_en      ),
		.clk_cnt  ( prer         ),
		.start    ( sta          ),
		.stop     ( sto          ),
		.read     ( rd           ),
		.write    ( wr           ),
		.ack_in   ( ack          ),
		.din      ( txr          ),
		.cmd_ack  ( done         ),
		.ack_out  ( irxack       ),
		.dout     ( rxr          ),
		.i2c_busy ( i2c_busy     ),
		.i2c_al   ( i2c_al       ),
		.scl_i    ( scl_pad_i    ),
		.scl_o    ( scl_pad_o    ),
		.scl_oen  ( scl_padoen_o ),
		.sda_i    ( sda_pad_i    ),
		.sda_o    ( sda_pad_o    ),
		.sda_oen  ( sda_padoen_o )
	);

	always @(posedge wb_clk_i or negedge rst_i)
	  if (!rst_i)
	    begin
	        al       <= #1 1'b0;
	        rxack    <= #1 1'b0;
	        tip      <= #1 1'b0;
	        irq_flag <= #1 1'b0;
	    end
	  else if (wb_rst_i)
	    begin
	        al       <= #1 1'b0;
	        rxack    <= #1 1'b0;
	        tip      <= #1 1'b0;
	        irq_flag <= #1 1'b0;
	    end
	  else
	    begin
	        al       <= #1 i2c_al | (al & ~sta);
	        rxack    <= #1 irxack;
	        tip      <= #1 (rd | wr);
	        irq_flag <= #1 (done | i2c_al | irq_flag) & ~iack;
	    end

	always @(posedge wb_clk_i or negedge rst_i)
	  if (!rst_i)
	    wb_inta_o <= #1 1'b0;
	  else if (wb_rst_i)
	    wb_inta_o <= #1 1'b0;
	  else
	    wb_inta_o <= #1 irq_flag && ien;

	assign sr[7]   = rxack;
	assign sr[6]   = i2c_busy;
	assign sr[5]   = al;
	assign sr[4:2] = 3'h0;
	assign sr[1]   = tip;
	assign sr[0]   = irq_flag;

endmodule
