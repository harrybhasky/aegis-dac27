`timescale 1ns / 10ps



`define I2C_CMD_NOP   4'b0000
`define I2C_CMD_START 4'b0001
`define I2C_CMD_STOP  4'b0010
`define I2C_CMD_WRITE 4'b0100
`define I2C_CMD_READ  4'b1000


module i2c_master_bit_ctrl(
	clk, rst, nReset, 
	clk_cnt, ena, cmd, cmd_ack, busy, al, din, dout,
	scl_i, scl_o, scl_oen, sda_i, sda_o, sda_oen
	);

	input clk;
	input rst;
	input nReset;
	input ena;

	input [15:0] clk_cnt;

	input  [3:0] cmd;
	output       cmd_ack;
	reg cmd_ack;
	output       busy;
	reg busy;
	output       al;
	reg al;

	input  din;
	output dout;
	reg dout;

	input  scl_i;
	output scl_o;
	output scl_oen;
	reg scl_oen;
	input  sda_i;
	output sda_o;
	output sda_oen;
	reg sda_oen;

	reg sSCL, sSDA;
	reg dscl_oen;
	reg sda_chk;
	reg clk_en;
	wire slave_wait;
	reg [15:0] cnt;
	reg cnt_zero_r;             // always equals (cnt == 0)

	reg [16:0] c_state; 

	always @(posedge clk)
	  dscl_oen <= #1 scl_oen;

	assign slave_wait = dscl_oen && !sSCL;

	// balanced zero-detect trees
	wire [3:0] clkcnt_or4;
	assign clkcnt_or4[0] = (clk_cnt[0]  | clk_cnt[1])  | (clk_cnt[2]  | clk_cnt[3]);
	assign clkcnt_or4[1] = (clk_cnt[4]  | clk_cnt[5])  | (clk_cnt[6]  | clk_cnt[7]);
	assign clkcnt_or4[2] = (clk_cnt[8]  | clk_cnt[9])  | (clk_cnt[10] | clk_cnt[11]);
	assign clkcnt_or4[3] = (clk_cnt[12] | clk_cnt[13]) | (clk_cnt[14] | clk_cnt[15]);
	wire clk_cnt_zero = ~((clkcnt_or4[0] | clkcnt_or4[1]) | (clkcnt_or4[2] | clkcnt_or4[3]));

	// cnt == 1 : bit0 set, all upper bits clear
	wire [3:0] cnt_hi_or;
	assign cnt_hi_or[0] = (cnt[1]  | cnt[2])  | (cnt[3]  | cnt[4]);
	assign cnt_hi_or[1] = (cnt[5]  | cnt[6])  | (cnt[7]  | cnt[8]);
	assign cnt_hi_or[2] = (cnt[9]  | cnt[10]) | (cnt[11] | cnt[12]);
	assign cnt_hi_or[3] = (cnt[13] | cnt[14]) | cnt[15];
	wire cnt_is_one = cnt[0] & ~((cnt_hi_or[0] | cnt_hi_or[1]) | (cnt_hi_or[2] | cnt_hi_or[3]));

	wire cnt_load_cond = cnt_zero_r | ~ena;

	// generate clk enable signal
	always @(posedge clk or negedge nReset)
	  if(~nReset)
	    begin
	        cnt        <= #1 16'h0;
	        clk_en     <= #1 1'b1;
	        cnt_zero_r <= #1 1'b1;
	    end
	  else if (rst)
	    begin
	        cnt        <= #1 16'h0;
	        clk_en     <= #1 1'b1;
	        cnt_zero_r <= #1 1'b1;
	    end
	  else if (cnt_load_cond)
	    if (~slave_wait)
	      begin
	          cnt        <= #1 clk_cnt;
	          clk_en     <= #1 1'b1;
	          cnt_zero_r <= #1 clk_cnt_zero;
	      end
	    else
	      begin
	          cnt        <= #1 cnt;
	          clk_en     <= #1 1'b0;
	          cnt_zero_r <= #1 cnt_zero_r;
	      end
	  else
	    begin
	        cnt        <= #1 cnt - 16'h1;
	        clk_en     <= #1 1'b0;
	        cnt_zero_r <= #1 cnt_is_one;
	    end


	// generate bus status controller
	reg dSCL, dSDA;
	reg sta_condition;
	reg sto_condition;

	always @(posedge clk or negedge nReset)
	  if (~nReset)
	    begin
	        sSCL <= #1 1'b1;
	        sSDA <= #1 1'b1;
	        dSCL <= #1 1'b1;
	        dSDA <= #1 1'b1;
	    end
	  else if (rst)
	    begin
	        sSCL <= #1 1'b1;
	        sSDA <= #1 1'b1;
	        dSCL <= #1 1'b1;
	        dSDA <= #1 1'b1;
	    end
	  else
	    begin
	        sSCL <= #1 scl_i;
	        sSDA <= #1 sda_i;
	        dSCL <= #1 sSCL;
	        dSDA <= #1 sSDA;
	    end

	always @(posedge clk or negedge nReset)
	  if (~nReset)
	    begin
	        sta_condition <= #1 1'b0;
	        sto_condition <= #1 1'b0;
	    end
	  else if (rst)
	    begin
	        sta_condition <= #1 1'b0;
	        sto_condition <= #1 1'b0;
	    end
	  else
	    begin
	        sta_condition <= #1 ~sSDA &  dSDA & sSCL;
	        sto_condition <= #1  sSDA & ~dSDA & sSCL;
	    end

	always @(posedge clk or negedge nReset)
	  if(!nReset)
	    busy <= #1 1'b0;
	  else if (rst)
	    busy <= #1 1'b0;
	  else
	    busy <= #1 (sta_condition | busy) & ~sto_condition;

	reg cmd_stop;
	always @(posedge clk or negedge nReset)
	  if (~nReset)
	    cmd_stop <= #1 1'b0;
	  else if (rst)
	    cmd_stop <= #1 1'b0;
	  else if (clk_en)
	    cmd_stop <= #1 cmd == `I2C_CMD_STOP;

	// state decode (one-hot bits; idle = all zeros)
	wire s_a = c_state[0];
	wire s_b = c_state[1];
	wire s_c = c_state[2];
	wire s_d = c_state[3];
	wire s_e = c_state[4];
	wire p_a = c_state[5];
	wire p_b = c_state[6];
	wire p_c = c_state[7];
	wire p_d = c_state[8];
	wire r_a = c_state[9];
	wire r_b = c_state[10];
	wire r_c = c_state[11];
	wire r_d = c_state[12];
	wire w_a = c_state[13];
	wire w_b = c_state[14];
	wire w_c = c_state[15];
	wire w_d = c_state[16];

	wire st_or_0 = (c_state[0]  | c_state[1])  | (c_state[2]  | c_state[3]);
	wire st_or_1 = (c_state[4]  | c_state[5])  | (c_state[6]  | c_state[7]);
	wire st_or_2 = (c_state[8]  | c_state[9])  | (c_state[10] | c_state[11]);
	wire st_or_3 = (c_state[12] | c_state[13]) | (c_state[14] | c_state[15]);
	wire st_nonidle = ((st_or_0 | st_or_1) | (st_or_2 | st_or_3)) | c_state[16];
	wire st_idle = ~st_nonidle;

	always @(posedge clk or negedge nReset)
	  if (~nReset)
	    al <= #1 1'b0;
	  else if (rst)
	    al <= #1 1'b0;
	  else
	    al <= #1 (sda_chk & ~sSDA & sda_oen) | (st_nonidle & sto_condition & ~cmd_stop);

	always @(posedge clk)
	  if(sSCL & ~dSCL)
	    dout <= #1 sSDA;

	parameter [16:0] idle    = 17'b0_0000_0000_0000_0000;

	// command decode
	wire cmd_is_start = (cmd == `I2C_CMD_START);
	wire cmd_is_stop  = (cmd == `I2C_CMD_STOP);
	wire cmd_is_write = (cmd == `I2C_CMD_WRITE);
	wire cmd_is_read  = (cmd == `I2C_CMD_READ);

	wire [16:0] nxt_state;
	assign nxt_state[0]  = st_idle & cmd_is_start;
	assign nxt_state[1]  = s_a;
	assign nxt_state[2]  = s_b;
	assign nxt_state[3]  = s_c;
	assign nxt_state[4]  = s_d;
	assign nxt_state[5]  = st_idle & cmd_is_stop;
	assign nxt_state[6]  = p_a;
	assign nxt_state[7]  = p_b;
	assign nxt_state[8]  = p_c;
	assign nxt_state[9]  = st_idle & cmd_is_read;
	assign nxt_state[10] = r_a;
	assign nxt_state[11] = r_b;
	assign nxt_state[12] = r_c;
	assign nxt_state[13] = st_idle & cmd_is_write;
	assign nxt_state[14] = w_a;
	assign nxt_state[15] = w_b;
	assign nxt_state[16] = w_c;

	// output groups
	wire scl_set1 = ((s_b | s_c) | (s_d | p_b)) | ((p_c | p_d) | (r_b | r_c)) | (w_b | w_c);
	wire scl_set0 = ((s_e | p_a) | (r_a | r_d)) | (w_a | w_d);
	wire scl_oen_nxt = scl_set1 | (scl_oen & ~scl_set0);

	wire sda_one1 = ((s_a | s_b) | (p_d | r_a)) | ((r_b | r_c) | r_d);
	wire sda_wr   = (w_a | w_b) | (w_c | w_d);
	wire sda_oen_nxt = sda_one1 | (sda_wr & din) | (sda_oen & st_idle);

	wire ack_st = (s_e | p_d) | (r_d | w_d);

	wire kill = rst | al;

	always @(posedge clk or negedge nReset)
	  if (!nReset)
	    begin
	        c_state <= #1 idle;
	        cmd_ack <= #1 1'b0;
	        scl_oen <= #1 1'b1;
	        sda_oen <= #1 1'b1;
	        sda_chk <= #1 1'b0;
	    end
	  else if (kill)
	    begin
	        c_state <= #1 idle;
	        cmd_ack <= #1 1'b0;
	        scl_oen <= #1 1'b1;
	        sda_oen <= #1 1'b1;
	        sda_chk <= #1 1'b0;
	    end
	  else
	    begin
	        cmd_ack <= #1 clk_en & ack_st;

	        if (clk_en)
	          begin
	              c_state <= #1 nxt_state;
	              scl_oen <= #1 scl_oen_nxt;
	              sda_oen <= #1 sda_oen_nxt;
	              sda_chk <= #1 w_b | w_c;
	          end
	    end

	assign scl_o = 1'b0;
	assign sda_o = 1'b0;

endmodule


module i2c_master_byte_ctrl (
	clk, rst, nReset, ena, clk_cnt, start, stop, read, write, ack_in, din,
	cmd_ack, ack_out, dout, i2c_busy, i2c_al, scl_i, scl_o, scl_oen, sda_i, sda_o, sda_oen );

	input clk;
	input rst;
	input nReset;
	input ena;

	input [15:0] clk_cnt;

	input       start;
	input       stop;
	input       read;
	input       write;
	input       ack_in;
	input [7:0] din;

	output       cmd_ack;
	reg cmd_ack;
	output       ack_out;
	reg ack_out;
	output       i2c_busy;
	output       i2c_al;
	output [7:0] dout;

	input  scl_i;
	output scl_o;
	output scl_oen;
	input  sda_i;
	output sda_o;
	output sda_oen;

	parameter [4:0] ST_IDLE  = 5'b0_0000;
	parameter [4:0] ST_START = 5'b0_0001;
	parameter [4:0] ST_READ  = 5'b0_0010;
	parameter [4:0] ST_WRITE = 5'b0_0100;
	parameter [4:0] ST_ACK   = 5'b0_1000;
	parameter [4:0] ST_STOP  = 5'b1_0000;

	reg  [3:0] core_cmd;
	reg        core_txd;
	wire       core_ack, core_rxd;

	reg [7:0] sr;
	reg       shift, ld;
	reg       shift_s, ld_s;   // duplicates driving sr (fanout split)

	wire       go;
	reg  [2:0] dcnt;
	wire       cnt_done;

	i2c_master_bit_ctrl bit_controller (
		.clk     ( clk      ),
		.rst     ( rst      ),
		.nReset  ( nReset   ),
		.ena     ( ena      ),
		.clk_cnt ( clk_cnt  ),
		.cmd     ( core_cmd ),
		.cmd_ack ( core_ack ),
		.busy    ( i2c_busy ),
		.al      ( i2c_al   ),
		.din     ( core_txd ),
		.dout    ( core_rxd ),
		.scl_i   ( scl_i    ),
		.scl_o   ( scl_o    ),
		.scl_oen ( scl_oen  ),
		.sda_i   ( sda_i    ),
		.sda_o   ( sda_o    ),
		.sda_oen ( sda_oen  )
	);

	assign go = (read | write | stop) & ~cmd_ack;

	assign dout = sr;

	always @(posedge clk or negedge nReset)
	  if (!nReset)
	    sr <= #1 8'h0;
	  else if (rst)
	    sr <= #1 8'h0;
	  else if (ld_s)
	    sr <= #1 din;
	  else if (shift_s)
	    sr <= #1 {sr[6:0], core_rxd};

	always @(posedge clk or negedge nReset)
	  if (!nReset)
	    dcnt <= #1 3'h0;
	  else if (rst)
	    dcnt <= #1 3'h0;
	  else if (ld)
	    dcnt <= #1 3'h7;
	  else if (shift)
	    dcnt <= #1 dcnt - 3'h1;

	assign cnt_done = ~(|dcnt);

	reg [4:0] c_state;

	// one-hot state decode
	wire st_start = c_state[0];
	wire st_read  = c_state[1];
	wire st_write = c_state[2];
	wire st_ack   = c_state[3];
	wire st_stop  = c_state[4];
	wire st_idle  = ~(((c_state[0] | c_state[1]) | (c_state[2] | c_state[3])) | c_state[4]);

	always @(posedge clk or negedge nReset)
	  if (!nReset)
	    begin
	        core_cmd <= #1 `I2C_CMD_NOP;
	        core_txd <= #1 1'b0;
	        shift    <= #1 1'b0;
	        ld       <= #1 1'b0;
	        shift_s  <= #1 1'b0;
	        ld_s     <= #1 1'b0;
	        cmd_ack  <= #1 1'b0;
	        c_state  <= #1 ST_IDLE;
	        ack_out  <= #1 1'b0;
	    end
	  else if (rst | i2c_al)
	   begin
	       core_cmd <= #1 `I2C_CMD_NOP;
	       core_txd <= #1 1'b0;
	       shift    <= #1 1'b0;
	       ld       <= #1 1'b0;
	       shift_s  <= #1 1'b0;
	       ld_s     <= #1 1'b0;
	       cmd_ack  <= #1 1'b0;
	       c_state  <= #1 ST_IDLE;
	       ack_out  <= #1 1'b0;
	   end
	else
	  begin
	      core_txd <= #1 sr[7];
	      shift    <= #1 1'b0;
	      ld       <= #1 1'b0;
	      shift_s  <= #1 1'b0;
	      ld_s     <= #1 1'b0;
	      cmd_ack  <= #1 1'b0;

	      if (st_idle)
	        begin
	          if (go)
	            begin
	                if (start)
	                  begin
	                      c_state  <= #1 ST_START;
	                      core_cmd <= #1 `I2C_CMD_START;
	                  end
	                else if (read)
	                  begin
	                      c_state  <= #1 ST_READ;
	                      core_cmd <= #1 `I2C_CMD_READ;
	                  end
	                else if (write)
	                  begin
	                      c_state  <= #1 ST_WRITE;
	                      core_cmd <= #1 `I2C_CMD_WRITE;
	                  end
	                else
	                  begin
	                      c_state  <= #1 ST_STOP;
	                      core_cmd <= #1 `I2C_CMD_STOP;
	                  end

	                ld   <= #1 1'b1;
	                ld_s <= #1 1'b1;
	            end
	        end

	      if (st_start)
	        begin
	          if (core_ack)
	            begin
	                if (read)
	                  begin
	                      c_state  <= #1 ST_READ;
	                      core_cmd <= #1 `I2C_CMD_READ;
	                  end
	                else
	                  begin
	                      c_state  <= #1 ST_WRITE;
	                      core_cmd <= #1 `I2C_CMD_WRITE;
	                  end

	                ld   <= #1 1'b1;
	                ld_s <= #1 1'b1;
	            end
	        end

	      if (st_write)
	        begin
	          if (core_ack)
	            if (cnt_done)
	              begin
	                  c_state  <= #1 ST_ACK;
	                  core_cmd <= #1 `I2C_CMD_READ;
	              end
	            else
	              begin
	                  c_state  <= #1 ST_WRITE;
	                  core_cmd <= #1 `I2C_CMD_WRITE;
	                  shift    <= #1 1'b1;
	                  shift_s  <= #1 1'b1;
	              end
	        end

	      if (st_read)
	        begin
	          if (core_ack)
	            begin
	                if (cnt_done)
	                  begin
	                      c_state  <= #1 ST_ACK;
	                      core_cmd <= #1 `I2C_CMD_WRITE;
	                  end
	                else
	                  begin
	                      c_state  <= #1 ST_READ;
	                      core_cmd <= #1 `I2C_CMD_READ;
	                  end

	                shift    <= #1 1'b1;
	                shift_s  <= #1 1'b1;
	                core_txd <= #1 ack_in;
	            end
	        end

	      if (st_ack)
	        begin
	          if (core_ack)
	            begin
	               if (stop)
	                 begin
	                     c_state  <= #1 ST_STOP;
	                     core_cmd <= #1 `I2C_CMD_STOP;
	                 end
	               else
	                 begin
	                     c_state  <= #1 ST_IDLE;
	                     core_cmd <= #1 `I2C_CMD_NOP;
	                     cmd_ack  <= #1 1'b1;
	                 end

	                 ack_out  <= #1 core_rxd;
	                 core_txd <= #1 1'b1;
	             end
	           else
	             core_txd <= #1 ack_in;
	        end

	      if (st_stop)
	        begin
	          if (core_ack)
	            begin
	                c_state  <= #1 ST_IDLE;
	                core_cmd <= #1 `I2C_CMD_NOP;
	                cmd_ack  <= #1 1'b1;
	            end
	        end
	  end
endmodule


module i2c_master_top(
	wb_clk_i, wb_rst_i, arst_i, wb_adr_i, wb_dat_i, wb_dat_o,
	wb_we_i, wb_stb_i, wb_cyc_i, wb_ack_o, wb_inta_o,
	scl_pad_i, scl_pad_o, scl_padoen_o, sda_pad_i, sda_pad_o, sda_padoen_o );

	parameter ARST_LVL = 1'b0;

	input        wb_clk_i;
	input        wb_rst_i;
	input        arst_i;
	input  [2:0] wb_adr_i;
	input  [7:0] wb_dat_i;
	output [7:0] wb_dat_o;
	input        wb_we_i;
	input        wb_stb_i;
	input        wb_cyc_i;
	output       wb_ack_o;
	output       wb_inta_o;

	reg [7:0] wb_dat_o;
	reg wb_ack_o;
	reg wb_inta_o;

	input  scl_pad_i;
	output scl_pad_o;
	output scl_padoen_o;

	input  sda_pad_i;
	output sda_pad_o;
	output sda_padoen_o;

	reg  [15:0] prer;
	reg  [ 7:0] ctr;
	reg  [ 7:0] txr;
	wire [ 7:0] rxr;
	reg  [ 7:0] cr;
	wire [ 7:0] sr;

	wire done;

	wire core_en;
	wire ien;

	wire irxack;
	reg  rxack;
	reg  tip;
	reg  irq_flag;
	wire i2c_busy;
	wire i2c_al;
	reg  al;

	wire rst_i = arst_i ^ ARST_LVL;

	wire wb_wacc = wb_cyc_i & wb_stb_i & wb_we_i;

	always @(posedge wb_clk_i)
	  wb_ack_o <= #1 wb_cyc_i & wb_stb_i & ~wb_ack_o;

	always @(posedge wb_clk_i)
	begin
	  case (wb_adr_i)
	    3'b000: wb_dat_o <= #1 prer[ 7:0];
	    3'b001: wb_dat_o <= #1 prer[15:8];
	    3'b010: wb_dat_o <= #1 ctr;
	    3'b011: wb_dat_o <= #1 rxr;
	    3'b100: wb_dat_o <= #1 sr;
	    3'b101: wb_dat_o <= #1 txr;
	    3'b110: wb_dat_o <= #1 cr;
	    3'b111: wb_dat_o <= #1 0;
	  endcase
	end

	always @(posedge wb_clk_i or negedge rst_i)
	  if (!rst_i)
	    begin
	        prer <= #1 16'hffff;
	        ctr  <= #1  8'h0;
	        txr  <= #1  8'h0;
	    end
	  else if (wb_rst_i)
	    begin
	        prer <= #1 16'hffff;
	        ctr  <= #1  8'h0;
	        txr  <= #1  8'h0;
	    end
	  else
	    if (wb_wacc)
	      case (wb_adr_i)
	         3'b000 : prer [ 7:0] <= #1 wb_dat_i;
	         3'b001 : prer [15:8] <= #1 wb_dat_i;
	         3'b010 : ctr         <= #1 wb_dat_i;
	         3'b011 : txr         <= #1 wb_dat_i;
	         default: ;
	      endcase

	always @(posedge wb_clk_i or negedge rst_i)
	  if (~rst_i)
	    cr <= #1 8'h0;
	  else if (wb_rst_i)
	    cr <= #1 8'h0;
	  else if (wb_wacc)
	    begin
	        if (core_en & (wb_adr_i == 3'b100) )
	          cr <= #1 wb_dat_i;
	    end
	  else
	    begin
	        if (done | i2c_al)
	          cr[7:4] <= #1 4'h0;
	        cr[2:1] <= #1 2'b0;
	        cr[0]   <= #1 2'b0;
	    end

	wire sta  = cr[7];
	wire sto  = cr[6];
	wire rd   = cr[5];
	wire wr   = cr[4];
	wire ack  = cr[3];
	wire iack = cr[0];

	assign core_en = ctr[7];
	assign ien = ctr[6];

	i2c_master_byte_ctrl byte_controller (
		.clk      ( wb_clk_i     ),
		.rst      ( wb_rst_i     ),
		.nReset   ( rst_i        ),
		.ena      ( core_en      ),
		.clk_cnt  ( prer         ),
		.start    ( sta          ),
		.stop     ( sto          ),
		.read     ( rd           ),
		.write    ( wr           ),
		.ack_in   ( ack          ),
		.din      ( txr          ),
		.cmd_ack  ( done         ),
		.ack_out  ( irxack       ),
		.dout     ( rxr          ),
		.i2c_busy ( i2c_busy     ),
		.i2c_al   ( i2c_al       ),
		.scl_i    ( scl_pad_i    ),
		.scl_o    ( scl_pad_o    ),
		.scl_oen  ( scl_padoen_o ),
		.sda_i    ( sda_pad_i    ),
		.sda_o    ( sda_pad_o    ),
		.sda_oen  ( sda_padoen_o )
	);

	always @(posedge wb_clk_i or negedge rst_i)
	  if (!rst_i)
	    begin
	        al       <= #1 1'b0;
	        rxack    <= #1 1'b0;
	        tip      <= #1 1'b0;
	        irq_flag <= #1 1'b0;
	    end
	  else if (wb_rst_i)
	    begin
	        al       <= #1 1'b0;
	        rxack    <= #1 1'b0;
	        tip      <= #1 1'b0;
	        irq_flag <= #1 1'b0;
	    end
	  else
	    begin
	        al       <= #1 i2c_al | (al & ~sta);
	        rxack    <= #1 irxack;
	        tip      <= #1 (rd | wr);
	        irq_flag <= #1 (done | i2c_al | irq_flag) & ~iack;
	    end

	always @(posedge wb_clk_i or negedge rst_i)
	  if (!rst_i)
	    wb_inta_o <= #1 1'b0;
	  else if (wb_rst_i)
	    wb_inta_o <= #1 1'b0;
	  else
	    wb_inta_o <= #1 irq_flag && ien;

	assign sr[7]   = rxack;
	assign sr[6]   = i2c_busy;
	assign sr[5]   = al;
	assign sr[4:2] = 3'h0;
	assign sr[1]   = tip;
	assign sr[0]   = irq_flag;

endmodule
