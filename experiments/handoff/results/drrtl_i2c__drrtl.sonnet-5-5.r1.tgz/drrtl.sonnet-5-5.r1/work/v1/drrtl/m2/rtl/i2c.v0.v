`timescale 1ns / 10ps



`define I2C_CMD_NOP   4'b0000
`define I2C_CMD_START 4'b0001
`define I2C_CMD_STOP  4'b0010
`define I2C_CMD_WRITE 4'b0100
`define I2C_CMD_READ  4'b1000


module i2c_master_bit_ctrl(
	clk, rst, nReset, 
	clk_cnt, ena, cmd, cmd_ack, busy, al, din, dout,
	scl_i, scl_o, scl_oen, sda_i, sda_o, sda_oen
	);

	input clk;
	input rst;
	input nReset;
	input ena;

	input [15:0] clk_cnt;

	input  [3:0] cmd;
	output       cmd_ack;
	reg cmd_ack;
	output       busy;
	reg busy;
	output       al;
	reg al;

	input  din;
	output dout;
	reg dout;

	input  scl_i;
	output scl_o;
	output scl_oen;
	reg scl_oen;
	input  sda_i;
	output sda_o;
	output sda_oen;
	reg sda_oen;

	reg sSCL, sSDA;
	reg dscl_oen;
	reg sda_chk;
	reg clk_en;
	wire slave_wait;
	reg [15:0] cnt;

	reg [16:0] c_state; 

	always @(posedge clk)
	  dscl_oen <= #1 scl_oen;

	assign slave_wait = dscl_oen && !sSCL;

	// ------------------------------------------------------------
	// clock divider: balanced zero detect, shared select, lookahead decrement
	// ------------------------------------------------------------
	wire cz0 = ~(|cnt[3:0]);
	wire cz1 = ~(|cnt[7:4]);
	wire cz2 = ~(|cnt[11:8]);
	wire cz3 = ~(|cnt[15:12]);
	wire cnt_zero = (cz0 & cz1) & (cz2 & cz3);

	wire reload_cond = cnt_zero | ~ena;
	wire do_load = reload_cond & ~slave_wait;
	wire do_hold = reload_cond &  slave_wait;

	// low-bits-all-zero (borrow) terms
	wire [15:0] lowz;
	assign lowz[0]  = 1'b1;
	assign lowz[1]  = ~cnt[0];
	assign lowz[2]  = ~(cnt[1] | cnt[0]);
	assign lowz[3]  = ~(|cnt[2:0]);
	assign lowz[4]  = cz0;
	assign lowz[5]  = cz0 & ~cnt[4];
	assign lowz[6]  = cz0 & ~(|cnt[5:4]);
	assign lowz[7]  = cz0 & ~(|cnt[6:4]);
	assign lowz[8]  = cz0 & cz1;
	assign lowz[9]  = (cz0 & cz1) & ~cnt[8];
	assign lowz[10] = (cz0 & cz1) & ~(|cnt[9:8]);
	assign lowz[11] = (cz0 & cz1) & ~(|cnt[10:8]);
	assign lowz[12] = (cz0 & cz1) & cz2;
	assign lowz[13] = ((cz0 & cz1) & cz2) & ~cnt[12];
	assign lowz[14] = ((cz0 & cz1) & cz2) & ~(|cnt[13:12]);
	assign lowz[15] = ((cz0 & cz1) & cz2) & ~(|cnt[14:12]);

	wire [15:0] dec = cnt ^ lowz;
	wire [15:0] cnt_next = do_load ? clk_cnt : (do_hold ? cnt : dec);

	always @(posedge clk or negedge nReset)
	  if(~nReset)
	    begin
	        cnt    <= #1 16'h0;
	        clk_en <= #1 1'b1;
	    end
	  else if (rst)
	    begin
	        cnt    <= #1 16'h0;
	        clk_en <= #1 1'b1;
	    end
	  else
	    begin
	        cnt    <= #1 cnt_next;
	        clk_en <= #1 do_load;
	    end


	reg dSCL, dSDA;
	reg sta_condition;
	reg sto_condition;

	always @(posedge clk or negedge nReset)
	  if (~nReset)
	    begin
	        sSCL <= #1 1'b1;
	        sSDA <= #1 1'b1;

	        dSCL <= #1 1'b1;
	        dSDA <= #1 1'b1;
	    end
	  else if (rst)
	    begin
	        sSCL <= #1 1'b1;
	        sSDA <= #1 1'b1;

	        dSCL <= #1 1'b1;
	        dSDA <= #1 1'b1;
	    end
	  else
	    begin
	        sSCL <= #1 scl_i;
	        sSDA <= #1 sda_i;

	        dSCL <= #1 sSCL;
	        dSDA <= #1 sSDA;
	    end

	always @(posedge clk or negedge nReset)
	  if (~nReset)
	    begin
	        sta_condition <= #1 1'b0;
	        sto_condition <= #1 1'b0;
	    end
	  else if (rst)
	    begin
	        sta_condition <= #1 1'b0;
	        sto_condition <= #1 1'b0;
	    end
	  else
	    begin
	        sta_condition <= #1 ~sSDA &  dSDA & sSCL;
	        sto_condition <= #1  sSDA & ~dSDA & sSCL;
	    end

	always @(posedge clk or negedge nReset)
	  if(!nReset)
	    busy <= #1 1'b0;
	  else if (rst)
	    busy <= #1 1'b0;
	  else
	    busy <= #1 (sta_condition | busy) & ~sto_condition;

	reg cmd_stop;
	always @(posedge clk or negedge nReset)
	  if (~nReset)
	    cmd_stop <= #1 1'b0;
	  else if (rst)
	    cmd_stop <= #1 1'b0;
	  else if (clk_en)
	    cmd_stop <= #1 cmd == `I2C_CMD_STOP;

	// shared balanced idle detect
	wire sz0 = ~(|c_state[3:0]);
	wire sz1 = ~(|c_state[7:4]);
	wire sz2 = ~(|c_state[11:8]);
	wire sz3 = ~(|c_state[16:12]);
	wire st_idle = (sz0 & sz1) & (sz2 & sz3);
	wire st_busy = ~st_idle;

	always @(posedge clk or negedge nReset)
	  if (~nReset)
	    al <= #1 1'b0;
	  else if (rst)
	    al <= #1 1'b0;
	  else
	    al <= #1 (sda_chk & ~sSDA & sda_oen) | (st_busy & sto_condition & ~cmd_stop);


	always @(posedge clk)
	  if(sSCL & ~dSCL)
	    dout <= #1 sSDA;

	// state indices
	parameter [16:0] idle    = 17'b0_0000_0000_0000_0000;
	parameter [16:0] start_a = 17'b0_0000_0000_0000_0001;
	parameter [16:0] start_b = 17'b0_0000_0000_0000_0010;
	parameter [16:0] start_c = 17'b0_0000_0000_0000_0100;
	parameter [16:0] start_d = 17'b0_0000_0000_0000_1000;
	parameter [16:0] start_e = 17'b0_0000_0000_0001_0000;
	parameter [16:0] stop_a  = 17'b0_0000_0000_0010_0000;
	parameter [16:0] stop_b  = 17'b0_0000_0000_0100_0000;
	parameter [16:0] stop_c  = 17'b0_0000_0000_1000_0000;
	parameter [16:0] stop_d  = 17'b0_0000_0001_0000_0000;
	parameter [16:0] rd_a    = 17'b0_0000_0010_0000_0000;
	parameter [16:0] rd_b    = 17'b0_0000_0100_0000_0000;
	parameter [16:0] rd_c    = 17'b0_0000_1000_0000_0000;
	parameter [16:0] rd_d    = 17'b0_0001_0000_0000_0000;
	parameter [16:0] wr_a    = 17'b0_0010_0000_0000_0000;
	parameter [16:0] wr_b    = 17'b0_0100_0000_0000_0000;
	parameter [16:0] wr_c    = 17'b0_1000_0000_0000_0000;
	parameter [16:0] wr_d    = 17'b1_0000_0000_0000_0000;

	// pre-decoded command wires
	wire cmd_is_start = (cmd == `I2C_CMD_START);
	wire cmd_is_stop  = (cmd == `I2C_CMD_STOP);
	wire cmd_is_write = (cmd == `I2C_CMD_WRITE);
	wire cmd_is_read  = (cmd == `I2C_CMD_READ);

	wire clr = rst | al;

	// next-state equations (one-hot)
	wire [16:0] n_state;
	assign n_state[0]  = st_idle & cmd_is_start;
	assign n_state[1]  = c_state[0];
	assign n_state[2]  = c_state[1];
	assign n_state[3]  = c_state[2];
	assign n_state[4]  = c_state[3];
	assign n_state[5]  = st_idle & cmd_is_stop;
	assign n_state[6]  = c_state[5];
	assign n_state[7]  = c_state[6];
	assign n_state[8]  = c_state[7];
	assign n_state[9]  = st_idle & cmd_is_read;
	assign n_state[10] = c_state[9];
	assign n_state[11] = c_state[10];
	assign n_state[12] = c_state[11];
	assign n_state[13] = st_idle & cmd_is_write;
	assign n_state[14] = c_state[13];
	assign n_state[15] = c_state[14];
	assign n_state[16] = c_state[15];

	// output group decodes
	wire ack_grp  = (c_state[4] | c_state[8]) | (c_state[12] | c_state[16]);

	wire scl_set1 = ((c_state[1] | c_state[2]) | (c_state[3] | c_state[6])) |
	                ((c_state[7] | c_state[8]) | (c_state[10] | c_state[11])) |
	                (c_state[14] | c_state[15]);
	wire scl_hold = st_idle | c_state[0];
	wire scl_next = scl_set1 | (scl_hold & scl_oen);

	wire sda_set1 = ((c_state[0] | c_state[1]) | (c_state[8] | c_state[9])) |
	                ((c_state[10] | c_state[11]) | c_state[12]);
	wire sda_din  = (c_state[13] | c_state[14]) | (c_state[15] | c_state[16]);
	wire sda_next = sda_set1 | (sda_din & din) | (st_idle & sda_oen);

	wire chk_next = c_state[14] | c_state[15];

	always @(posedge clk or negedge nReset)
	  if (!nReset)
	    begin
	        c_state <= #1 idle;
	        cmd_ack <= #1 1'b0;
	        scl_oen <= #1 1'b1;
	        sda_oen <= #1 1'b1;
	        sda_chk <= #1 1'b0;
	    end
	  else if (clr)
	    begin
	        c_state <= #1 idle;
	        cmd_ack <= #1 1'b0;
	        scl_oen <= #1 1'b1;
	        sda_oen <= #1 1'b1;
	        sda_chk <= #1 1'b0;
	    end
	  else
	    begin
	        cmd_ack <= #1 clk_en & ack_grp;
	        if (clk_en)
	          begin
	              c_state <= #1 n_state;
	              scl_oen <= #1 scl_next;
	              sda_oen <= #1 sda_next;
	              sda_chk <= #1 chk_next;
	          end
	    end

	assign scl_o = 1'b0;
	assign sda_o = 1'b0;

endmodule


module i2c_master_byte_ctrl (
	clk, rst, nReset, ena, clk_cnt, start, stop, read, write, ack_in, din,
	cmd_ack, ack_out, dout, i2c_busy, i2c_al, scl_i, scl_o, scl_oen, sda_i, sda_o, sda_oen );

	input clk;
	input rst;
	input nReset;
	input ena;

	input [15:0] clk_cnt;

	input       start;
	input       stop;
	input       read;
	input       write;
	input       ack_in;
	input [7:0] din;

	output       cmd_ack;
	reg cmd_ack;
	output       ack_out;
	reg ack_out;
	output       i2c_busy;
	output       i2c_al;
	output [7:0] dout;

	input  scl_i;
	output scl_o;
	output scl_oen;
	input  sda_i;
	output sda_o;
	output sda_oen;

	parameter [4:0] ST_IDLE  = 5'b0_0000;
	parameter [4:0] ST_START = 5'b0_0001;
	parameter [4:0] ST_READ  = 5'b0_0010;
	parameter [4:0] ST_WRITE = 5'b0_0100;
	parameter [4:0] ST_ACK   = 5'b0_1000;
	parameter [4:0] ST_STOP  = 5'b1_0000;

	reg  [3:0] core_cmd;
	reg        core_txd;
	wire       core_ack, core_rxd;

	reg [7:0] sr;
	reg       shift, ld;
	reg       shift_d, ld_d;   // duplicated copies for dcnt fanout split

	wire       go;
	reg  [2:0] dcnt;
	wire       cnt_done;

	i2c_master_bit_ctrl bit_controller (
		.clk     ( clk      ),
		.rst     ( rst      ),
		.nReset  ( nReset   ),
		.ena     ( ena      ),
		.clk_cnt ( clk_cnt  ),
		.cmd     ( core_cmd ),
		.cmd_ack ( core_ack ),
		.busy    ( i2c_busy ),
		.al      ( i2c_al   ),
		.din     ( core_txd ),
		.dout    ( core_rxd ),
		.scl_i   ( scl_i    ),
		.scl_o   ( scl_o    ),
		.scl_oen ( scl_oen  ),
		.sda_i   ( sda_i    ),
		.sda_o   ( sda_o    ),
		.sda_oen ( sda_oen  )
	);

	assign go = (read | write | stop) & ~cmd_ack;

	assign dout = sr;

	always @(posedge clk or negedge nReset)
	  if (!nReset)
	    sr <= #1 8'h0;
	  else if (rst)
	    sr <= #1 8'h0;
	  else if (ld)
	    sr <= #1 din;
	  else if (shift)
	    sr <= #1 {sr[6:0], core_rxd};

	always @(posedge clk or negedge nReset)
	  if (!nReset)
	    dcnt <= #1 3'h0;
	  else if (rst)
	    dcnt <= #1 3'h0;
	  else if (ld_d)
	    dcnt <= #1 3'h7;
	  else if (shift_d)
	    dcnt <= #1 dcnt - 3'h1;

	assign cnt_done = ~(|dcnt);

	reg [4:0] c_state;

	// one-hot pre-decode
	wire st_idle  = ~(|c_state);
	wire st_start = c_state[0];
	wire st_read  = c_state[1];
	wire st_write = c_state[2];
	wire st_ack   = c_state[3];
	wire st_stop  = c_state[4];

	wire clr_b = rst | i2c_al;

	wire go_idle  = st_idle & go;
	wire gi_start = go_idle & start;
	wire gi_read  = go_idle & ~start & read;
	wire gi_write = go_idle & ~start & ~read & write;
	wire gi_stop  = go_idle & ~start & ~read & ~write;

	wire s_ack      = st_start & core_ack;   // START done
	wire r_ack      = st_read  & core_ack;
	wire w_ack      = st_write & core_ack;
	wire a_ack      = st_ack   & core_ack;
	wire p_ack      = st_stop  & core_ack;

	// next one-hot state
	wire n0 = gi_start | (st_start & ~core_ack);
	wire n1 = gi_read | (s_ack & read) | (r_ack & ~cnt_done) | (st_read & ~core_ack);
	wire n2 = gi_write | (s_ack & ~read) | (w_ack & ~cnt_done) | (st_write & ~core_ack);
	wire n3 = (w_ack & cnt_done) | (r_ack & cnt_done) | (st_ack & ~core_ack);
	wire n4 = gi_stop | (a_ack & stop) | (st_stop & ~core_ack);

	// core_cmd update
	wire cmd_upd = go_idle | (core_ack & ~st_idle);
	wire cv0 = gi_start;
	wire cv1 = gi_stop | (st_ack & stop);
	wire cv2 = gi_write | (st_start & ~read) | (st_write & ~cnt_done) | (st_read & cnt_done);
	wire cv3 = gi_read | (st_start & read) | (st_write & cnt_done) | (st_read & ~cnt_done);

	wire ld_n    = go_idle | s_ack;
	wire shift_n = (w_ack & ~cnt_done) | r_ack;
	wire cack_n  = (a_ack & ~stop) | p_ack;

	wire txd_n = st_ack ? (ack_in | core_ack) :
	             (r_ack ? ack_in : sr[7]);

	always @(posedge clk or negedge nReset)
	  if (!nReset)
	    begin
	        core_cmd <= #1 `I2C_CMD_NOP;
	        core_txd <= #1 1'b0;
	        shift    <= #1 1'b0;
	        ld       <= #1 1'b0;
	        shift_d  <= #1 1'b0;
	        ld_d     <= #1 1'b0;
	        cmd_ack  <= #1 1'b0;
	        c_state  <= #1 ST_IDLE;
	        ack_out  <= #1 1'b0;
	    end
	  else if (clr_b)
	   begin
	       core_cmd <= #1 `I2C_CMD_NOP;
	       core_txd <= #1 1'b0;
	       shift    <= #1 1'b0;
	       ld       <= #1 1'b0;
	       shift_d  <= #1 1'b0;
	       ld_d     <= #1 1'b0;
	       cmd_ack  <= #1 1'b0;
	       c_state  <= #1 ST_IDLE;
	       ack_out  <= #1 1'b0;
	   end
	else
	  begin
	      core_txd <= #1 txd_n;
	      shift    <= #1 shift_n;
	      shift_d  <= #1 shift_n;
	      ld       <= #1 ld_n;
	      ld_d     <= #1 ld_n;
	      cmd_ack  <= #1 cack_n;
	      c_state  <= #1 {n4, n3, n2, n1, n0};
	      if (cmd_upd)
	        core_cmd <= #1 {cv3, cv2, cv1, cv0};
	      if (a_ack)
	        ack_out <= #1 core_rxd;
	  end
endmodule


module i2c_master_top(
	wb_clk_i, wb_rst_i, arst_i, wb_adr_i, wb_dat_i, wb_dat_o,
	wb_we_i, wb_stb_i, wb_cyc_i, wb_ack_o, wb_inta_o,
	scl_pad_i, scl_pad_o, scl_padoen_o, sda_pad_i, sda_pad_o, sda_padoen_o );

	parameter ARST_LVL = 1'b0;

	input        wb_clk_i;
	input        wb_rst_i;
	input        arst_i;
	input  [2:0] wb_adr_i;
	input  [7:0] wb_dat_i;
	output [7:0] wb_dat_o;
	input        wb_we_i;
	input        wb_stb_i;
	input        wb_cyc_i;
	output       wb_ack_o;
	output       wb_inta_o;

	reg [7:0] wb_dat_o;
	reg wb_ack_o;
	reg wb_inta_o;

	input  scl_pad_i;
	output scl_pad_o;
	output scl_padoen_o;

	input  sda_pad_i;
	output sda_pad_o;
	output sda_padoen_o;

	reg  [15:0] prer;
	reg  [ 7:0] ctr;
	reg  [ 7:0] txr;
	wire [ 7:0] rxr;
	reg  [ 7:0] cr;
	wire [ 7:0] sr;

	wire done;

	wire core_en;
	wire ien;

	wire irxack;
	reg  rxack;
	reg  tip;
	reg  irq_flag;
	wire i2c_busy;
	wire i2c_al;
	reg  al;

	wire rst_i = arst_i ^ ARST_LVL;

	wire wb_wacc = wb_cyc_i & wb_stb_i & wb_we_i;

	always @(posedge wb_clk_i)
	  wb_ack_o <= #1 wb_cyc_i & wb_stb_i & ~wb_ack_o;

	always @(posedge wb_clk_i)
	begin
	  case (wb_adr_i)
	    3'b000: wb_dat_o <= #1 prer[ 7:0];
	    3'b001: wb_dat_o <= #1 prer[15:8];
	    3'b010: wb_dat_o <= #1 ctr;
	    3'b011: wb_dat_o <= #1 rxr;
	    3'b100: wb_dat_o <= #1 sr;
	    3'b101: wb_dat_o <= #1 txr;
	    3'b110: wb_dat_o <= #1 cr;
	    3'b111: wb_dat_o <= #1 0;
	  endcase
	end

	always @(posedge wb_clk_i or negedge rst_i)
	  if (!rst_i)
	    begin
	        prer <= #1 16'hffff;
	        ctr  <= #1  8'h0;
	        txr  <= #1  8'h0;
	    end
	  else if (wb_rst_i)
	    begin
	        prer <= #1 16'hffff;
	        ctr  <= #1  8'h0;
	        txr  <= #1  8'h0;
	    end
	  else
	    if (wb_wacc)
	      case (wb_adr_i)
	         3'b000 : prer [ 7:0] <= #1 wb_dat_i;
	         3'b001 : prer [15:8] <= #1 wb_dat_i;
	         3'b010 : ctr         <= #1 wb_dat_i;
	         3'b011 : txr         <= #1 wb_dat_i;
	         default: ;
	      endcase

	always @(posedge wb_clk_i or negedge rst_i)
	  if (~rst_i)
	    cr <= #1 8'h0;
	  else if (wb_rst_i)
	    cr <= #1 8'h0;
	  else if (wb_wacc)
	    begin
	        if (core_en & (wb_adr_i == 3'b100) )
	          cr <= #1 wb_dat_i;
	    end
	  else
	    begin
	        if (done | i2c_al)
	          cr[7:4] <= #1 4'h0;
	        cr[2:1] <= #1 2'b0;
	        cr[0]   <= #1 2'b0;
	    end

	wire sta  = cr[7];
	wire sto  = cr[6];
	wire rd   = cr[5];
	wire wr   = cr[4];
	wire ack  = cr[3];
	wire iack = cr[0];

	assign core_en = ctr[7];
	assign ien = ctr[6];

	i2c_master_byte_ctrl byte_controller (
		.clk      ( wb_clk_i     ),
		.rst      ( wb_rst_i     ),
		.nReset   ( rst_i        ),
		.ena      ( core_en      ),
		.clk_cnt  ( prer         ),
		.start    ( sta          ),
		.stop     ( sto          ),
		.read     ( rd           ),
		.write    ( wr           ),
		.ack_in   ( ack          ),
		.din      ( txr          ),
		.cmd_ack  ( done         ),
		.ack_out  ( irxack       ),
		.dout     ( rxr          ),
		.i2c_busy ( i2c_busy     ),
		.i2c_al   ( i2c_al       ),
		.scl_i    ( scl_pad_i    ),
		.scl_o    ( scl_pad_o    ),
		.scl_oen  ( scl_padoen_o ),
		.sda_i    ( sda_pad_i    ),
		.sda_o    ( sda_pad_o    ),
		.sda_oen  ( sda_padoen_o )
	);

	always @(posedge wb_clk_i or negedge rst_i)
	  if (!rst_i)
	    begin
	        al       <= #1 1'b0;
	        rxack    <= #1 1'b0;
	        tip      <= #1 1'b0;
	        irq_flag <= #1 1'b0;
	    end
	  else if (wb_rst_i)
	    begin
	        al       <= #1 1'b0;
	        rxack    <= #1 1'b0;
	        tip      <= #1 1'b0;
	        irq_flag <= #1 1'b0;
	    end
	  else
	    begin
	        al       <= #1 i2c_al | (al & ~sta);
	        rxack    <= #1 irxack;
	        tip      <= #1 (rd | wr);
	        irq_flag <= #1 (done | i2c_al | irq_flag) & ~iack;
	    end

	always @(posedge wb_clk_i or negedge rst_i)
	  if (!rst_i)
	    wb_inta_o <= #1 1'b0;
	  else if (wb_rst_i)
	    wb_inta_o <= #1 1'b0;
	  else
	    wb_inta_o <= #1 irq_flag && ien;

	assign sr[7]   = rxack;
	assign sr[6]   = i2c_busy;
	assign sr[5]   = al;
	assign sr[4:2] = 3'h0;
	assign sr[1]   = tip;
	assign sr[0]   = irq_flag;

endmodule
