`timescale 1ns / 10ps



`define I2C_CMD_NOP   4'b0000
`define I2C_CMD_START 4'b0001
`define I2C_CMD_STOP  4'b0010
`define I2C_CMD_WRITE 4'b0100
`define I2C_CMD_READ  4'b1000


module i2c_master_bit_ctrl(
	clk, rst, nReset, 
	clk_cnt, ena, cmd, cmd_ack, busy, al, din, dout,
	scl_i, scl_o, scl_oen, sda_i, sda_o, sda_oen
	);

	input clk;
	input rst;
	input nReset;
	input ena;

	input [15:0] clk_cnt;

	input  [3:0] cmd;
	output       cmd_ack;
	reg cmd_ack;
	output       busy;
	reg busy;
	output       al;
	reg al;

	input  din;
	output dout;
	reg dout;

	input  scl_i;
	output scl_o;
	output scl_oen;
	reg scl_oen;
	input  sda_i;
	output sda_o;
	output sda_oen;
	reg sda_oen;

	reg sSCL, sSDA;
	reg dscl_oen;
	reg sda_chk;
	reg clk_en;
	wire slave_wait;
	reg [15:0] cnt;

	reg [16:0] c_state; 

	always @(posedge clk)
	  dscl_oen <= #1 scl_oen;

	assign slave_wait = dscl_oen && !sSCL;

	// ---------------------------------------------------------------
	// clock divider: balanced zero detect, lookahead borrow, shared selects
	// ---------------------------------------------------------------
	wire z0 = ~|cnt[3:0];
	wire z1 = ~|cnt[7:4];
	wire z2 = ~|cnt[11:8];
	wire z3 = ~|cnt[15:12];
	wire z01 = z0 & z1;
	wire z23 = z2 & z3;
	wire cnt_zero = z01 & z23;

	wire load_cond = cnt_zero | ~ena;
	wire do_load   = load_cond & ~slave_wait;
	wire do_hold   = load_cond &  slave_wait;

	// duplicated selects for low / high halves
	wire do_load_lo = load_cond & ~slave_wait;
	wire do_hold_lo = load_cond &  slave_wait;
	wire do_load_hi = load_cond & ~slave_wait;
	wire do_hold_hi = load_cond &  slave_wait;

	// group prefix: all lower groups zero
	wire [3:0] gpre;
	assign gpre[0] = 1'b1;
	assign gpre[1] = z0;
	assign gpre[2] = z01;
	assign gpre[3] = z01 & z2;

	wire [15:0] bor;
	assign bor[0]  = gpre[0];
	assign bor[1]  = gpre[0] & ~cnt[0];
	assign bor[2]  = gpre[0] & ~|cnt[1:0];
	assign bor[3]  = gpre[0] & ~|cnt[2:0];
	assign bor[4]  = gpre[1];
	assign bor[5]  = gpre[1] & ~cnt[4];
	assign bor[6]  = gpre[1] & ~|cnt[5:4];
	assign bor[7]  = gpre[1] & ~|cnt[6:4];
	assign bor[8]  = gpre[2];
	assign bor[9]  = gpre[2] & ~cnt[8];
	assign bor[10] = gpre[2] & ~|cnt[9:8];
	assign bor[11] = gpre[2] & ~|cnt[10:8];
	assign bor[12] = gpre[3];
	assign bor[13] = gpre[3] & ~cnt[12];
	assign bor[14] = gpre[3] & ~|cnt[13:12];
	assign bor[15] = gpre[3] & ~|cnt[14:12];

	wire [15:0] cnt_dec = cnt ^ bor;

	wire [7:0] cnt_nxt_lo = do_load_lo ? clk_cnt[7:0] :
	                        do_hold_lo ? cnt[7:0]     : cnt_dec[7:0];
	wire [7:0] cnt_nxt_hi = do_load_hi ? clk_cnt[15:8] :
	                        do_hold_hi ? cnt[15:8]     : cnt_dec[15:8];

	always @(posedge clk or negedge nReset)
	  if(~nReset)
	    begin
	        cnt    <= #1 16'h0;
	        clk_en <= #1 1'b1;
	    end
	  else if (rst)
	    begin
	        cnt    <= #1 16'h0;
	        clk_en <= #1 1'b1;
	    end
	  else
	    begin
	        cnt    <= #1 {cnt_nxt_hi, cnt_nxt_lo};
	        clk_en <= #1 do_load;
	    end


	// generate bus status controller
	reg dSCL, dSDA;
	reg sta_condition;
	reg sto_condition;

	always @(posedge clk or negedge nReset)
	  if (~nReset)
	    begin
	        sSCL <= #1 1'b1;
	        sSDA <= #1 1'b1;

	        dSCL <= #1 1'b1;
	        dSDA <= #1 1'b1;
	    end
	  else if (rst)
	    begin
	        sSCL <= #1 1'b1;
	        sSDA <= #1 1'b1;

	        dSCL <= #1 1'b1;
	        dSDA <= #1 1'b1;
	    end
	  else
	    begin
	        sSCL <= #1 scl_i;
	        sSDA <= #1 sda_i;

	        dSCL <= #1 sSCL;
	        dSDA <= #1 sSDA;
	    end

	always @(posedge clk or negedge nReset)
	  if (~nReset)
	    begin
	        sta_condition <= #1 1'b0;
	        sto_condition <= #1 1'b0;
	    end
	  else if (rst)
	    begin
	        sta_condition <= #1 1'b0;
	        sto_condition <= #1 1'b0;
	    end
	  else
	    begin
	        sta_condition <= #1 ~sSDA &  dSDA & sSCL;
	        sto_condition <= #1  sSDA & ~dSDA & sSCL;
	    end

	always @(posedge clk or negedge nReset)
	  if(!nReset)
	    busy <= #1 1'b0;
	  else if (rst)
	    busy <= #1 1'b0;
	  else
	    busy <= #1 (sta_condition | busy) & ~sto_condition;

	reg cmd_stop;
	always @(posedge clk or negedge nReset)
	  if (~nReset)
	    cmd_stop <= #1 1'b0;
	  else if (rst)
	    cmd_stop <= #1 1'b0;
	  else if (clk_en)
	    cmd_stop <= #1 cmd == `I2C_CMD_STOP;

	// balanced non-idle detect (shared with idle decode)
	wire st_nz_a = |c_state[7:0];
	wire st_nz_b = |c_state[15:8];
	wire st_nz   = (st_nz_a | st_nz_b) | c_state[16];
	wire s_idle  = ~st_nz;

	always @(posedge clk or negedge nReset)
	  if (~nReset)
	    al <= #1 1'b0;
	  else if (rst)
	    al <= #1 1'b0;
	  else
	    al <= #1 (sda_chk & ~sSDA & sda_oen) | (st_nz & sto_condition & ~cmd_stop);

	always @(posedge clk)
	  if(sSCL & ~dSCL)
	    dout <= #1 sSDA;

	// state machine

	parameter [16:0] idle    = 17'b0_0000_0000_0000_0000;
	parameter [16:0] start_a = 17'b0_0000_0000_0000_0001;
	parameter [16:0] start_b = 17'b0_0000_0000_0000_0010;
	parameter [16:0] start_c = 17'b0_0000_0000_0000_0100;
	parameter [16:0] start_d = 17'b0_0000_0000_0000_1000;
	parameter [16:0] start_e = 17'b0_0000_0000_0001_0000;
	parameter [16:0] stop_a  = 17'b0_0000_0000_0010_0000;
	parameter [16:0] stop_b  = 17'b0_0000_0000_0100_0000;
	parameter [16:0] stop_c  = 17'b0_0000_0000_1000_0000;
	parameter [16:0] stop_d  = 17'b0_0000_0001_0000_0000;
	parameter [16:0] rd_a    = 17'b0_0000_0010_0000_0000;
	parameter [16:0] rd_b    = 17'b0_0000_0100_0000_0000;
	parameter [16:0] rd_c    = 17'b0_0000_1000_0000_0000;
	parameter [16:0] rd_d    = 17'b0_0001_0000_0000_0000;
	parameter [16:0] wr_a    = 17'b0_0010_0000_0000_0000;
	parameter [16:0] wr_b    = 17'b0_0100_0000_0000_0000;
	parameter [16:0] wr_c    = 17'b0_1000_0000_0000_0000;
	parameter [16:0] wr_d    = 17'b1_0000_0000_0000_0000;

	// one-hot direct state bits
	wire s_sa   = c_state[0];
	wire s_sb   = c_state[1];
	wire s_sc   = c_state[2];
	wire s_sd   = c_state[3];
	wire s_se   = c_state[4];
	wire s_pa   = c_state[5];
	wire s_pb   = c_state[6];
	wire s_pc   = c_state[7];
	wire s_pd   = c_state[8];
	wire s_ra   = c_state[9];
	wire s_rb   = c_state[10];
	wire s_rc   = c_state[11];
	wire s_rd   = c_state[12];
	wire s_wa   = c_state[13];
	wire s_wb   = c_state[14];
	wire s_wc   = c_state[15];
	wire s_wd   = c_state[16];

	// command decode
	wire cmd_is_start = (cmd == `I2C_CMD_START);
	wire cmd_is_stop  = (cmd == `I2C_CMD_STOP);
	wire cmd_is_write = (cmd == `I2C_CMD_WRITE);
	wire cmd_is_read  = (cmd == `I2C_CMD_READ);

	// next state
	wire [16:0] nxt;
	assign nxt[0]  = s_idle & cmd_is_start;
	assign nxt[1]  = s_sa;
	assign nxt[2]  = s_sb;
	assign nxt[3]  = s_sc;
	assign nxt[4]  = s_sd;
	assign nxt[5]  = s_idle & cmd_is_stop;
	assign nxt[6]  = s_pa;
	assign nxt[7]  = s_pb;
	assign nxt[8]  = s_pc;
	assign nxt[9]  = s_idle & cmd_is_read;
	assign nxt[10] = s_ra;
	assign nxt[11] = s_rb;
	assign nxt[12] = s_rc;
	assign nxt[13] = s_idle & cmd_is_write;
	assign nxt[14] = s_wa;
	assign nxt[15] = s_wb;
	assign nxt[16] = s_wc;

	// state groups
	wire ack_grp  = (s_se | s_pd) | (s_rd | s_wd);
	wire set1_grp = ((s_sb | s_sc) | (s_sd | s_pb)) | ((s_pc | s_pd) | (s_rb | s_rc)) | (s_wb | s_wc);
	wire set0_grp = ((s_se | s_pa) | (s_ra | s_rd)) | (s_wa | s_wd);
	wire sda1_grp = ((s_sa | s_sb) | (s_pd | s_ra)) | ((s_rb | s_rc) | s_rd);
	wire wr_grp   = (s_wa | s_wb) | (s_wc | s_wd);
	wire chk_grp  = s_wb | s_wc;

	wire scl_nxt = set1_grp | (scl_oen & ~set0_grp);
	wire sda_nxt = sda1_grp | (wr_grp & din) | (s_idle & sda_oen);

	always @(posedge clk or negedge nReset)
	  if (!nReset)
	    begin
	        c_state <= #1 idle;
	        cmd_ack <= #1 1'b0;
	        scl_oen <= #1 1'b1;
	        sda_oen <= #1 1'b1;
	        sda_chk <= #1 1'b0;
	    end
	  else if (rst | al)
	    begin
	        c_state <= #1 idle;
	        cmd_ack <= #1 1'b0;
	        scl_oen <= #1 1'b1;
	        sda_oen <= #1 1'b1;
	        sda_chk <= #1 1'b0;
	    end
	  else
	    begin
	        cmd_ack <= #1 clk_en & ack_grp;
	        if (clk_en)
	          begin
	              c_state <= #1 nxt;
	              scl_oen <= #1 scl_nxt;
	              sda_oen <= #1 sda_nxt;
	              sda_chk <= #1 chk_grp;
	          end
	    end

	assign scl_o = 1'b0;
	assign sda_o = 1'b0;

endmodule


module i2c_master_byte_ctrl (
	clk, rst, nReset, ena, clk_cnt, start, stop, read, write, ack_in, din,
	cmd_ack, ack_out, dout, i2c_busy, i2c_al, scl_i, scl_o, scl_oen, sda_i, sda_o, sda_oen );

	input clk;
	input rst;
	input nReset;
	input ena;

	input [15:0] clk_cnt;

	input       start;
	input       stop;
	input       read;
	input       write;
	input       ack_in;
	input [7:0] din;

	output       cmd_ack;
	reg cmd_ack;
	output       ack_out;
	reg ack_out;
	output       i2c_busy;
	output       i2c_al;
	output [7:0] dout;

	input  scl_i;
	output scl_o;
	output scl_oen;
	input  sda_i;
	output sda_o;
	output sda_oen;

	parameter [4:0] ST_IDLE  = 5'b0_0000;
	parameter [4:0] ST_START = 5'b0_0001;
	parameter [4:0] ST_READ  = 5'b0_0010;
	parameter [4:0] ST_WRITE = 5'b0_0100;
	parameter [4:0] ST_ACK   = 5'b0_1000;
	parameter [4:0] ST_STOP  = 5'b1_0000;

	reg  [3:0] core_cmd;
	reg        core_txd;
	wire       core_ack, core_rxd;

	reg [7:0] sr;
	reg       shift, ld;
	reg       ld_c;   // duplicate of ld for dcnt loads

	wire       go;
	reg  [2:0] dcnt;
	wire       cnt_done;

	i2c_master_bit_ctrl bit_controller (
		.clk     ( clk      ),
		.rst     ( rst      ),
		.nReset  ( nReset   ),
		.ena     ( ena      ),
		.clk_cnt ( clk_cnt  ),
		.cmd     ( core_cmd ),
		.cmd_ack ( core_ack ),
		.busy    ( i2c_busy ),
		.al      ( i2c_al   ),
		.din     ( core_txd ),
		.dout    ( core_rxd ),
		.scl_i   ( scl_i    ),
		.scl_o   ( scl_o    ),
		.scl_oen ( scl_oen  ),
		.sda_i   ( sda_i    ),
		.sda_o   ( sda_o    ),
		.sda_oen ( sda_oen  )
	);

	assign go = (read | write | stop) & ~cmd_ack;

	assign dout = sr;

	always @(posedge clk or negedge nReset)
	  if (!nReset)
	    sr <= #1 8'h0;
	  else if (rst)
	    sr <= #1 8'h0;
	  else if (ld)
	    sr <= #1 din;
	  else if (shift)
	    sr <= #1 {sr[6:0], core_rxd};

	always @(posedge clk or negedge nReset)
	  if (!nReset)
	    dcnt <= #1 3'h0;
	  else if (rst)
	    dcnt <= #1 3'h0;
	  else if (ld_c)
	    dcnt <= #1 3'h7;
	  else if (shift)
	    dcnt <= #1 dcnt - 3'h1;

	assign cnt_done = ~(|dcnt);

	reg [4:0] c_state;

	// one-hot direct state decode (idle = all zero)
	wire st_idle  = ~(|c_state);
	wire st_start = c_state[0];
	wire st_read  = c_state[1];
	wire st_write = c_state[2];
	wire st_ack   = c_state[3];
	wire st_stop  = c_state[4];

	// event pre-decode
	wire e_idle  = st_idle  & go;
	wire e_start = st_start & core_ack;
	wire e_read  = st_read  & core_ack;
	wire e_write = st_write & core_ack;
	wire e_ack   = st_ack   & core_ack;
	wire e_stop  = st_stop  & core_ack;

	wire change = ((e_idle | e_start) | (e_read | e_write)) | (e_ack | e_stop);

	wire to_start   = e_idle & start;
	wire to_read_i  = e_idle & ~start & read;
	wire to_write_i = e_idle & ~start & ~read & write;
	wire to_stop_i  = e_idle & ~start & ~read & ~write;

	wire n_start = to_start;
	wire n_read  = to_read_i  | (e_start & read)  | (e_read  & ~cnt_done);
	wire n_write = to_write_i | (e_start & ~read) | (e_write & ~cnt_done);
	wire n_ack   = (e_write | e_read) & cnt_done;
	wire n_stop  = to_stop_i | (e_ack & stop);

	wire [4:0] nxt_state = {n_stop, n_ack, n_write, n_read, n_start};

	wire [3:0] nxt_cmd;
	assign nxt_cmd[0] = to_start;
	assign nxt_cmd[1] = n_stop;
	assign nxt_cmd[2] = n_write | (e_read  & cnt_done);
	assign nxt_cmd[3] = n_read  | (e_write & cnt_done);

	wire ld_n    = e_idle | e_start;
	wire shift_n = (e_write & ~cnt_done) | e_read;
	wire cmdack_n = (e_ack & ~stop) | e_stop;
	wire txd_n   = e_read ? ack_in :
	               st_ack ? (core_ack ? 1'b1 : ack_in) : sr[7];

	always @(posedge clk or negedge nReset)
	  if (!nReset)
	    begin
	        core_cmd <= #1 `I2C_CMD_NOP;
	        core_txd <= #1 1'b0;
	        shift    <= #1 1'b0;
	        ld       <= #1 1'b0;
	        ld_c     <= #1 1'b0;
	        cmd_ack  <= #1 1'b0;
	        c_state  <= #1 ST_IDLE;
	        ack_out  <= #1 1'b0;
	    end
	  else if (rst | i2c_al)
	   begin
	       core_cmd <= #1 `I2C_CMD_NOP;
	       core_txd <= #1 1'b0;
	       shift    <= #1 1'b0;
	       ld       <= #1 1'b0;
	       ld_c     <= #1 1'b0;
	       cmd_ack  <= #1 1'b0;
	       c_state  <= #1 ST_IDLE;
	       ack_out  <= #1 1'b0;
	   end
	else
	  begin
	      core_txd <= #1 txd_n;
	      shift    <= #1 shift_n;
	      ld       <= #1 ld_n;
	      ld_c     <= #1 ld_n;
	      cmd_ack  <= #1 cmdack_n;

	      if (change)
	        begin
	            c_state  <= #1 nxt_state;
	            core_cmd <= #1 nxt_cmd;
	        end

	      if (e_ack)
	        ack_out <= #1 core_rxd;
	  end
endmodule


module i2c_master_top(
	wb_clk_i, wb_rst_i, arst_i, wb_adr_i, wb_dat_i, wb_dat_o,
	wb_we_i, wb_stb_i, wb_cyc_i, wb_ack_o, wb_inta_o,
	scl_pad_i, scl_pad_o, scl_padoen_o, sda_pad_i, sda_pad_o, sda_padoen_o );

	parameter ARST_LVL = 1'b0;

	input        wb_clk_i;
	input        wb_rst_i;
	input        arst_i;
	input  [2:0] wb_adr_i;
	input  [7:0] wb_dat_i;
	output [7:0] wb_dat_o;
	input        wb_we_i;
	input        wb_stb_i;
	input        wb_cyc_i;
	output       wb_ack_o;
	output       wb_inta_o;

	reg [7:0] wb_dat_o;
	reg wb_ack_o;
	reg wb_inta_o;

	input  scl_pad_i;
	output scl_pad_o;
	output scl_padoen_o;

	input  sda_pad_i;
	output sda_pad_o;
	output sda_padoen_o;

	reg  [15:0] prer;
	reg  [ 7:0] ctr;
	reg  [ 7:0] txr;
	wire [ 7:0] rxr;
	reg  [ 7:0] cr;
	wire [ 7:0] sr;

	wire done;

	wire core_en;
	wire ien;

	wire irxack;
	reg  rxack;
	reg  tip;
	reg  irq_flag;
	wire i2c_busy;
	wire i2c_al;
	reg  al;

	wire rst_i = arst_i ^ ARST_LVL;

	wire wb_wacc = wb_cyc_i & wb_stb_i & wb_we_i;

	always @(posedge wb_clk_i)
	  wb_ack_o <= #1 wb_cyc_i & wb_stb_i & ~wb_ack_o;

	always @(posedge wb_clk_i)
	begin
	  case (wb_adr_i) // synopsis parallel_case
	    3'b000: wb_dat_o <= #1 prer[ 7:0];
	    3'b001: wb_dat_o <= #1 prer[15:8];
	    3'b010: wb_dat_o <= #1 ctr;
	    3'b011: wb_dat_o <= #1 rxr;
	    3'b100: wb_dat_o <= #1 sr;
	    3'b101: wb_dat_o <= #1 txr;
	    3'b110: wb_dat_o <= #1 cr;
	    3'b111: wb_dat_o <= #1 0;
	  endcase
	end

	always @(posedge wb_clk_i or negedge rst_i)
	  if (!rst_i)
	    begin
	        prer <= #1 16'hffff;
	        ctr  <= #1  8'h0;
	        txr  <= #1  8'h0;
	    end
	  else if (wb_rst_i)
	    begin
	        prer <= #1 16'hffff;
	        ctr  <= #1  8'h0;
	        txr  <= #1  8'h0;
	    end
	  else
	    if (wb_wacc)
	      case (wb_adr_i) // synopsis parallel_case
	         3'b000 : prer [ 7:0] <= #1 wb_dat_i;
	         3'b001 : prer [15:8] <= #1 wb_dat_i;
	         3'b010 : ctr         <= #1 wb_dat_i;
	         3'b011 : txr         <= #1 wb_dat_i;
	         default: ;
	      endcase

	always @(posedge wb_clk_i or negedge rst_i)
	  if (~rst_i)
	    cr <= #1 8'h0;
	  else if (wb_rst_i)
	    cr <= #1 8'h0;
	  else if (wb_wacc)
	    begin
	        if (core_en & (wb_adr_i == 3'b100) )
	          cr <= #1 wb_dat_i;
	    end
	  else
	    begin
	        if (done | i2c_al)
	          cr[7:4] <= #1 4'h0;
	        cr[2:1] <= #1 2'b0;
	        cr[0]   <= #1 2'b0;
	    end

	wire sta  = cr[7];
	wire sto  = cr[6];
	wire rd   = cr[5];
	wire wr   = cr[4];
	wire ack  = cr[3];
	wire iack = cr[0];

	assign core_en = ctr[7];
	assign ien = ctr[6];

	i2c_master_byte_ctrl byte_controller (
		.clk      ( wb_clk_i     ),
		.rst      ( wb_rst_i     ),
		.nReset   ( rst_i        ),
		.ena      ( core_en      ),
		.clk_cnt  ( prer         ),
		.start    ( sta          ),
		.stop     ( sto          ),
		.read     ( rd           ),
		.write    ( wr           ),
		.ack_in   ( ack          ),
		.din      ( txr          ),
		.cmd_ack  ( done         ),
		.ack_out  ( irxack       ),
		.dout     ( rxr          ),
		.i2c_busy ( i2c_busy     ),
		.i2c_al   ( i2c_al       ),
		.scl_i    ( scl_pad_i    ),
		.scl_o    ( scl_pad_o    ),
		.scl_oen  ( scl_padoen_o ),
		.sda_i    ( sda_pad_i    ),
		.sda_o    ( sda_pad_o    ),
		.sda_oen  ( sda_padoen_o )
	);

	always @(posedge wb_clk_i or negedge rst_i)
	  if (!rst_i)
	    begin
	        al       <= #1 1'b0;
	        rxack    <= #1 1'b0;
	        tip      <= #1 1'b0;
	        irq_flag <= #1 1'b0;
	    end
	  else if (wb_rst_i)
	    begin
	        al       <= #1 1'b0;
	        rxack    <= #1 1'b0;
	        tip      <= #1 1'b0;
	        irq_flag <= #1 1'b0;
	    end
	  else
	    begin
	        al       <= #1 i2c_al | (al & ~sta);
	        rxack    <= #1 irxack;
	        tip      <= #1 (rd | wr);
	        irq_flag <= #1 (done | i2c_al | irq_flag) & ~iack;
	    end

	always @(posedge wb_clk_i or negedge rst_i)
	  if (!rst_i)
	    wb_inta_o <= #1 1'b0;
	  else if (wb_rst_i)
	    wb_inta_o <= #1 1'b0;
	  else
	    wb_inta_o <= #1 irq_flag && ien;

	assign sr[7]   = rxack;
	assign sr[6]   = i2c_busy;
	assign sr[5]   = al;
	assign sr[4:2] = 3'h0;
	assign sr[1]   = tip;
	assign sr[0]   = irq_flag;

endmodule
