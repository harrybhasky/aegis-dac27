`timescale 1ns / 10ps



`define I2C_CMD_NOP   4'b0000
`define I2C_CMD_START 4'b0001
`define I2C_CMD_STOP  4'b0010
`define I2C_CMD_WRITE 4'b0100
`define I2C_CMD_READ  4'b1000


module i2c_master_bit_ctrl(
	clk, rst, nReset, 
	clk_cnt, ena, cmd, cmd_ack, busy, al, din, dout,
	scl_i, scl_o, scl_oen, sda_i, sda_o, sda_oen
	);

	//
	// inputs & outputs
	//
	input clk;
	input rst;
	input nReset;
	input ena;            // core enable signal

	input [15:0] clk_cnt; // clock prescale value

	input  [3:0] cmd;
	output       cmd_ack; // command complete acknowledge
	reg cmd_ack;
	output       busy;    // i2c bus busy
	reg busy;
	output       al;      // i2c bus arbitration lost
	reg al;

	input  din;
	output dout;
	reg dout;

	// I2C lines
	input  scl_i;         // i2c clock line input
	output scl_o;         // i2c clock line output
	output scl_oen;       // i2c clock line output enable (active low)
	reg scl_oen;
	input  sda_i;         // i2c data line input
	output sda_o;         // i2c data line output
	output sda_oen;       // i2c data line output enable (active low)
	reg sda_oen;


	//
	// variable declarations
	//

	reg sSCL, sSDA;             // synchronized SCL and SDA inputs
	reg dscl_oen;               // delayed scl_oen
	reg sda_chk;                // check SDA output (Multi-master arbitration)
	reg clk_en;                 // clock generation signals
	wire slave_wait;
	reg [15:0] cnt;             // clock divider counter (synthesis)

	// state machine variable (one-hot, idle = all zero)
	reg [16:0] c_state; 

	//
	// module body
	//

	// delay scl_oen
	always @(posedge clk)
	  dscl_oen <= #1 scl_oen;

	assign slave_wait = dscl_oen && !sSCL;


	// ---------------------------------------------------------------
	// clock enable / divider counter
	// ---------------------------------------------------------------
	// balanced zero detect
	wire nz0 = |cnt[3:0];
	wire nz1 = |cnt[7:4];
	wire nz2 = |cnt[11:8];
	wire nz3 = |cnt[15:12];
	wire cnt_zero = ~((nz0 | nz1) | (nz2 | nz3));

	wire reload = cnt_zero | ~ena;

	// flat, mutually exclusive selects (rst folded in), duplicated per half
	wire sel_load_lo = reload & ~slave_wait & ~rst;
	wire sel_hold_lo = reload &  slave_wait & ~rst;
	wire sel_dec_lo  = ~reload & ~rst;
	wire sel_load_hi = reload & ~slave_wait & ~rst;
	wire sel_hold_hi = reload &  slave_wait & ~rst;
	wire sel_dec_hi  = ~reload & ~rst;

	// decrement with borrow lookahead
	wire [15:0] borrow;
	wire [15:0] cnt_dec;
	genvar gi;
	generate
	  for (gi = 0; gi < 16; gi = gi + 1) begin : g_dec
	    if (gi == 0) begin : g_b0
	      assign borrow[gi] = 1'b1;
	    end else begin : g_bn
	      assign borrow[gi] = ~(|cnt[gi-1:0]);
	    end
	    assign cnt_dec[gi] = cnt[gi] ^ borrow[gi];
	  end
	endgenerate

	wire [15:0] cnt_n;
	assign cnt_n[7:0]  = ({8{sel_load_lo}} & clk_cnt[7:0])
	                   | ({8{sel_hold_lo}} & cnt[7:0])
	                   | ({8{sel_dec_lo}}  & cnt_dec[7:0]);
	assign cnt_n[15:8] = ({8{sel_load_hi}} & clk_cnt[15:8])
	                   | ({8{sel_hold_hi}} & cnt[15:8])
	                   | ({8{sel_dec_hi}}  & cnt_dec[15:8]);

	wire clk_en_n = rst | (reload & ~slave_wait);

	always @(posedge clk or negedge nReset)
	  if(~nReset)
	    begin
	        cnt    <= 16'h0;
	        clk_en <= 1'b1;
	    end
	  else
	    begin
	        cnt    <= cnt_n;
	        clk_en <= clk_en_n;
	    end


	// generate bus status controller
	reg dSCL, dSDA;
	reg sta_condition;
	reg sto_condition;

	always @(posedge clk or negedge nReset)
	  if (~nReset)
	    begin
	        sSCL <= #1 1'b1;
	        sSDA <= #1 1'b1;

	        dSCL <= #1 1'b1;
	        dSDA <= #1 1'b1;
	    end
	  else if (rst)
	    begin
	        sSCL <= #1 1'b1;
	        sSDA <= #1 1'b1;

	        dSCL <= #1 1'b1;
	        dSDA <= #1 1'b1;
	    end
	  else
	    begin
	        sSCL <= #1 scl_i;
	        sSDA <= #1 sda_i;

	        dSCL <= #1 sSCL;
	        dSDA <= #1 sSDA;
	    end

	always @(posedge clk or negedge nReset)
	  if (~nReset)
	    begin
	        sta_condition <= #1 1'b0;
	        sto_condition <= #1 1'b0;
	    end
	  else if (rst)
	    begin
	        sta_condition <= #1 1'b0;
	        sto_condition <= #1 1'b0;
	    end
	  else
	    begin
	        sta_condition <= #1 ~sSDA &  dSDA & sSCL;
	        sto_condition <= #1  sSDA & ~dSDA & sSCL;
	    end

	always @(posedge clk or negedge nReset)
	  if(!nReset)
	    busy <= #1 1'b0;
	  else if (rst)
	    busy <= #1 1'b0;
	  else
	    busy <= #1 (sta_condition | busy) & ~sto_condition;

	reg cmd_stop;
	always @(posedge clk or negedge nReset)
	  if (~nReset)
	    cmd_stop <= #1 1'b0;
	  else if (rst)
	    cmd_stop <= #1 1'b0;
	  else if (clk_en)
	    cmd_stop <= #1 cmd == `I2C_CMD_STOP;

	// shared balanced idle detect (idle = all-zero state)
	wire [3:0] cs_or;
	assign cs_or[0] = |c_state[3:0];
	assign cs_or[1] = |c_state[7:4];
	assign cs_or[2] = |c_state[11:8];
	assign cs_or[3] = |c_state[16:12];
	wire not_idle = (cs_or[0] | cs_or[1]) | (cs_or[2] | cs_or[3]);
	wire idle_w   = ~not_idle;

	always @(posedge clk or negedge nReset)
	  if (~nReset)
	    al <= #1 1'b0;
	  else if (rst)
	    al <= #1 1'b0;
	  else
	    al <= #1 (sda_chk & ~sSDA & sda_oen) | (not_idle & sto_condition & ~cmd_stop);


	// generate dout signal (store SDA on rising edge of SCL)
	always @(posedge clk)
	  if(sSCL & ~dSCL)
	    dout <= #1 sSDA;

	// ---------------------------------------------------------------
	// state machine: one-hot decode, explicit equations
	// ---------------------------------------------------------------
	wire clr = rst | al;

	wire cmd_is_start = (cmd == `I2C_CMD_START);
	wire cmd_is_stop  = (cmd == `I2C_CMD_STOP);
	wire cmd_is_write = (cmd == `I2C_CMD_WRITE);
	wire cmd_is_read  = (cmd == `I2C_CMD_READ);

	wire [16:0] nxt;
	assign nxt[0]  = idle_w & cmd_is_start;   // start_a
	assign nxt[1]  = c_state[0];              // start_b
	assign nxt[2]  = c_state[1];              // start_c
	assign nxt[3]  = c_state[2];              // start_d
	assign nxt[4]  = c_state[3];              // start_e
	assign nxt[5]  = idle_w & cmd_is_stop;    // stop_a
	assign nxt[6]  = c_state[5];              // stop_b
	assign nxt[7]  = c_state[6];              // stop_c
	assign nxt[8]  = c_state[7];              // stop_d
	assign nxt[9]  = idle_w & cmd_is_read;    // rd_a
	assign nxt[10] = c_state[9];              // rd_b
	assign nxt[11] = c_state[10];             // rd_c
	assign nxt[12] = c_state[11];             // rd_d
	assign nxt[13] = idle_w & cmd_is_write;   // wr_a
	assign nxt[14] = c_state[13];             // wr_b
	assign nxt[15] = c_state[14];             // wr_c
	assign nxt[16] = c_state[15];             // wr_d

	// scl_oen: hold in idle/start_a, 1 in listed states, 0 otherwise
	wire scl_hold_st = idle_w | c_state[0];
	wire scl_one_st  = ((c_state[1] | c_state[2]) | (c_state[3] | c_state[6]))
	                 | ((c_state[7] | c_state[8]) | (c_state[10] | c_state[11]))
	                 | (c_state[14] | c_state[15]);
	wire scl_oen_n   = scl_one_st | (scl_hold_st & scl_oen);

	// sda_oen: hold in idle, 1 in listed states, din in write states, 0 otherwise
	wire sda_one_st = ((c_state[0] | c_state[1]) | (c_state[8] | c_state[9]))
	                | (c_state[10] | c_state[11] | c_state[12]);
	wire sda_din_st = (c_state[13] | c_state[14]) | (c_state[15] | c_state[16]);
	wire sda_oen_n  = sda_one_st | (sda_din_st & din) | (idle_w & sda_oen);

	wire sda_chk_n  = c_state[14] | c_state[15];
	wire done_st    = (c_state[4] | c_state[8]) | (c_state[12] | c_state[16]);

	always @(posedge clk or negedge nReset)
	  if (!nReset)
	    begin
	        c_state <= 17'b0;
	        cmd_ack <= 1'b0;
	        scl_oen <= 1'b1;
	        sda_oen <= 1'b1;
	        sda_chk <= 1'b0;
	    end
	  else if (clr)
	    begin
	        c_state <= 17'b0;
	        cmd_ack <= 1'b0;
	        scl_oen <= 1'b1;
	        sda_oen <= 1'b1;
	        sda_chk <= 1'b0;
	    end
	  else
	    begin
	        cmd_ack <= clk_en & done_st;
	        if (clk_en)
	          begin
	              c_state <= nxt;
	              scl_oen <= scl_oen_n;
	              sda_oen <= sda_oen_n;
	              sda_chk <= sda_chk_n;
	          end
	    end


	// assign scl and sda output (always gnd)
	assign scl_o = 1'b0;
	assign sda_o = 1'b0;

endmodule


module i2c_master_byte_ctrl (
	clk, rst, nReset, ena, clk_cnt, start, stop, read, write, ack_in, din,
	cmd_ack, ack_out, dout, i2c_busy, i2c_al, scl_i, scl_o, scl_oen, sda_i, sda_o, sda_oen );

	//
	// inputs & outputs
	//
	input clk;     // master clock
	input rst;     // synchronous active high reset
	input nReset;  // asynchronous active low reset
	input ena;     // core enable signal

	input [15:0] clk_cnt; // 4x SCL

	// control inputs
	input       start;
	input       stop;
	input       read;
	input       write;
	input       ack_in;
	input [7:0] din;

	// status outputs
	output       cmd_ack;
	reg cmd_ack;
	output       ack_out;
	reg ack_out;
	output       i2c_busy;
	output       i2c_al;
	output [7:0] dout;

	// I2C signals
	input  scl_i;
	output scl_o;
	output scl_oen;
	input  sda_i;
	output sda_o;
	output sda_oen;


	//
	// Variable declarations
	//

	// statemachine (one-hot, idle = all zero)
	parameter [4:0] ST_IDLE  = 5'b0_0000;
	parameter [4:0] ST_START = 5'b0_0001;
	parameter [4:0] ST_READ  = 5'b0_0010;
	parameter [4:0] ST_WRITE = 5'b0_0100;
	parameter [4:0] ST_ACK   = 5'b0_1000;
	parameter [4:0] ST_STOP  = 5'b1_0000;

	// signals for bit_controller
	reg  [3:0] core_cmd;
	reg        core_txd;
	wire       core_ack, core_rxd;

	// signals for shift register
	reg [7:0] sr; //8bit shift register
	reg       shift, ld;

	// signals for state machine
	wire       go;
	reg  [2:0] dcnt;
	wire       cnt_done;

	//
	// Module body
	//

	// hookup bit_controller
	i2c_master_bit_ctrl bit_controller (
		.clk     ( clk      ),
		.rst     ( rst      ),
		.nReset  ( nReset   ),
		.ena     ( ena      ),
		.clk_cnt ( clk_cnt  ),
		.cmd     ( core_cmd ),
		.cmd_ack ( core_ack ),
		.busy    ( i2c_busy ),
		.al      ( i2c_al   ),
		.din     ( core_txd ),
		.dout    ( core_rxd ),
		.scl_i   ( scl_i    ),
		.scl_o   ( scl_o    ),
		.scl_oen ( scl_oen  ),
		.sda_i   ( sda_i    ),
		.sda_o   ( sda_o    ),
		.sda_oen ( sda_oen  )
	);

	// generate go-signal
	assign go = (read | write | stop) & ~cmd_ack;

	// assign dout output to shift-register
	assign dout = sr;

	// generate shift register
	always @(posedge clk or negedge nReset)
	  if (!nReset)
	    sr <= #1 8'h0;
	  else if (rst)
	    sr <= #1 8'h0;
	  else if (ld)
	    sr <= #1 din;
	  else if (shift)
	    sr <= #1 {sr[6:0], core_rxd};

	// generate counter
	always @(posedge clk or negedge nReset)
	  if (!nReset)
	    dcnt <= #1 3'h0;
	  else if (rst)
	    dcnt <= #1 3'h0;
	  else if (ld)
	    dcnt <= #1 3'h7;
	  else if (shift)
	    dcnt <= #1 dcnt - 3'h1;

	assign cnt_done = ~(|dcnt);

	//
	// state machine
	//
	reg [4:0] c_state;

	// one-hot state decode (single-bit tests)
	wire s_start = c_state[0];
	wire s_read  = c_state[1];
	wire s_write = c_state[2];
	wire s_ack   = c_state[3];
	wire s_stop  = c_state[4];
	wire s_idle  = ~((c_state[0] | c_state[1]) | (c_state[2] | c_state[3]) | c_state[4]);

	// per-state firing conditions (mutually exclusive)
	wire f_idle        = s_idle  & go;
	wire f_idle_start  = f_idle  & start;
	wire f_idle_read   = f_idle  & ~start & read;
	wire f_idle_write  = f_idle  & ~start & ~read & write;
	wire f_idle_stop   = f_idle  & ~start & ~read & ~write;
	wire f_start       = s_start & core_ack;
	wire f_start_read  = f_start & read;
	wire f_start_write = f_start & ~read;
	wire f_write       = s_write & core_ack;
	wire f_write_done  = f_write &  cnt_done;
	wire f_write_more  = f_write & ~cnt_done;
	wire f_read        = s_read  & core_ack;
	wire f_read_done   = f_read  &  cnt_done;
	wire f_read_more   = f_read  & ~cnt_done;
	wire f_ack         = s_ack   & core_ack;
	wire f_ack_stop    = f_ack   & stop;
	wire f_ack_idle    = f_ack   & ~stop;
	wire f_stop        = s_stop  & core_ack;

	always @(posedge clk or negedge nReset)
	  if (!nReset)
	    begin
	        core_cmd <= #1 `I2C_CMD_NOP;
	        core_txd <= #1 1'b0;
	        shift    <= #1 1'b0;
	        ld       <= #1 1'b0;
	        cmd_ack  <= #1 1'b0;
	        c_state  <= #1 ST_IDLE;
	        ack_out  <= #1 1'b0;
	    end
	  else if (rst | i2c_al)
	   begin
	       core_cmd <= #1 `I2C_CMD_NOP;
	       core_txd <= #1 1'b0;
	       shift    <= #1 1'b0;
	       ld       <= #1 1'b0;
	       cmd_ack  <= #1 1'b0;
	       c_state  <= #1 ST_IDLE;
	       ack_out  <= #1 1'b0;
	   end
	else
	  begin
	      // defaults
	      core_txd <= #1 sr[7];
	      shift    <= #1 1'b0;
	      ld       <= #1 1'b0;
	      cmd_ack  <= #1 1'b0;

	      // exclusive conditions: state transitions
	      if (f_idle_start)  begin c_state <= #1 ST_START; core_cmd <= #1 `I2C_CMD_START; end
	      if (f_idle_read)   begin c_state <= #1 ST_READ;  core_cmd <= #1 `I2C_CMD_READ;  end
	      if (f_idle_write)  begin c_state <= #1 ST_WRITE; core_cmd <= #1 `I2C_CMD_WRITE; end
	      if (f_idle_stop)   begin c_state <= #1 ST_STOP;  core_cmd <= #1 `I2C_CMD_STOP;  end
	      if (f_idle)        ld <= #1 1'b1;

	      if (f_start_read)  begin c_state <= #1 ST_READ;  core_cmd <= #1 `I2C_CMD_READ;  end
	      if (f_start_write) begin c_state <= #1 ST_WRITE; core_cmd <= #1 `I2C_CMD_WRITE; end
	      if (f_start)       ld <= #1 1'b1;

	      if (f_write_done)  begin c_state <= #1 ST_ACK;   core_cmd <= #1 `I2C_CMD_READ;  end
	      if (f_write_more)  begin c_state <= #1 ST_WRITE; core_cmd <= #1 `I2C_CMD_WRITE; shift <= #1 1'b1; end

	      if (f_read_done)   begin c_state <= #1 ST_ACK;   core_cmd <= #1 `I2C_CMD_WRITE; end
	      if (f_read_more)   begin c_state <= #1 ST_READ;  core_cmd <= #1 `I2C_CMD_READ;  end
	      if (f_read)        begin shift <= #1 1'b1; core_txd <= #1 ack_in; end

	      if (f_ack_stop)    begin c_state <= #1 ST_STOP;  core_cmd <= #1 `I2C_CMD_STOP;  end
	      if (f_ack_idle)    begin c_state <= #1 ST_IDLE;  core_cmd <= #1 `I2C_CMD_NOP; cmd_ack <= #1 1'b1; end
	      if (f_ack)         begin ack_out <= #1 core_rxd; core_txd <= #1 1'b1; end
	      if (s_ack & ~core_ack) core_txd <= #1 ack_in;

	      if (f_stop)        begin c_state <= #1 ST_IDLE;  core_cmd <= #1 `I2C_CMD_NOP; cmd_ack <= #1 1'b1; end
	  end
endmodule


module i2c_master_top(
	wb_clk_i, wb_rst_i, arst_i, wb_adr_i, wb_dat_i, wb_dat_o,
	wb_we_i, wb_stb_i, wb_cyc_i, wb_ack_o, wb_inta_o,
	scl_pad_i, scl_pad_o, scl_padoen_o, sda_pad_i, sda_pad_o, sda_padoen_o );

	// parameters
	parameter ARST_LVL = 1'b0; // asynchronous reset level

	//
	// inputs & outputs
	//

	// wishbone signals
	input        wb_clk_i;     // master clock input
	input        wb_rst_i;     // synchronous active high reset
	input        arst_i;       // asynchronous reset
	input  [2:0] wb_adr_i;     // lower address bits
	input  [7:0] wb_dat_i;     // databus input
	output [7:0] wb_dat_o;     // databus output
	input        wb_we_i;      // write enable input
	input        wb_stb_i;     // stobe/core select signal
	input        wb_cyc_i;     // valid bus cycle input
	output       wb_ack_o;     // bus cycle acknowledge output
	output       wb_inta_o;    // interrupt request signal output

	reg [7:0] wb_dat_o;
	reg wb_ack_o;
	reg wb_inta_o;

	// I2C signals
	// i2c clock line
	input  scl_pad_i;       // SCL-line input
	output scl_pad_o;       // SCL-line output (always 1'b0)
	output scl_padoen_o;    // SCL-line output enable (active low)

	// i2c data line
	input  sda_pad_i;       // SDA-line input
	output sda_pad_o;       // SDA-line output (always 1'b0)
	output sda_padoen_o;    // SDA-line output enable (active low)


	//
	// variable declarations
	//

	// registers
	reg  [15:0] prer; // clock prescale register
	reg  [ 7:0] ctr;  // control register
	reg  [ 7:0] txr;  // transmit register
	wire [ 7:0] rxr;  // receive register
	reg  [ 7:0] cr;   // command register
	wire [ 7:0] sr;   // status register

	// done signal: command completed, clear command register
	wire done;

	// core enable signal
	wire core_en;
	wire ien;

	// status register signals
	wire irxack;
	reg  rxack;       // received aknowledge from slave
	reg  tip;         // transfer in progress
	reg  irq_flag;    // interrupt pending flag
	wire i2c_busy;    // bus busy (start signal detected)
	wire i2c_al;      // i2c bus arbitration lost
	reg  al;          // status register arbitration lost bit

	//
	// module body
	//

	// generate internal reset
	wire rst_i = arst_i ^ ARST_LVL;

	// generate wishbone signals
	wire wb_wacc = wb_cyc_i & wb_stb_i & wb_we_i;

	// generate acknowledge output signal
	always @(posedge wb_clk_i)
	  wb_ack_o <= #1 wb_cyc_i & wb_stb_i & ~wb_ack_o; // because timing is always honored

	// assign DAT_O
	always @(posedge wb_clk_i)
	begin
	  case (wb_adr_i) // synopsis parallel_case
	    3'b000: wb_dat_o <= #1 prer[ 7:0];
	    3'b001: wb_dat_o <= #1 prer[15:8];
	    3'b010: wb_dat_o <= #1 ctr;
	    3'b011: wb_dat_o <= #1 rxr; // write is transmit register (txr)
	    3'b100: wb_dat_o <= #1 sr;  // write is command register (cr)
	    3'b101: wb_dat_o <= #1 txr;
	    3'b110: wb_dat_o <= #1 cr;
	    3'b111: wb_dat_o <= #1 0;   // reserved
	  endcase
	end

	// generate registers
	always @(posedge wb_clk_i or negedge rst_i)
	  if (!rst_i)
	    begin
	        prer <= #1 16'hffff;
	        ctr  <= #1  8'h0;
	        txr  <= #1  8'h0;
	    end
	  else if (wb_rst_i)
	    begin
	        prer <= #1 16'hffff;
	        ctr  <= #1  8'h0;
	        txr  <= #1  8'h0;
	    end
	  else
	    if (wb_wacc)
	      case (wb_adr_i) // synopsis parallel_case
	         3'b000 : prer [ 7:0] <= #1 wb_dat_i;
	         3'b001 : prer [15:8] <= #1 wb_dat_i;
	         3'b010 : ctr         <= #1 wb_dat_i;
	         3'b011 : txr         <= #1 wb_dat_i;
	         default: ;
	      endcase

	// generate command register (special case)
	always @(posedge wb_clk_i or negedge rst_i)
	  if (~rst_i)
	    cr <= #1 8'h0;
	  else if (wb_rst_i)
	    cr <= #1 8'h0;
	  else if (wb_wacc)
	    begin
	        if (core_en & (wb_adr_i == 3'b100) )
	          cr <= #1 wb_dat_i;
	    end
	  else
	    begin
	        if (done | i2c_al)
	          cr[7:4] <= #1 4'h0;           // clear command bits when done
	                                        // or when aribitration lost
	        cr[2:1] <= #1 2'b0;             // reserved bits
	        cr[0]   <= #1 2'b0;             // clear IRQ_ACK bit
	    end


	// decode command register
	wire sta  = cr[7];
	wire sto  = cr[6];
	wire rd   = cr[5];
	wire wr   = cr[4];
	wire ack  = cr[3];
	wire iack = cr[0];

	// decode control register
	assign core_en = ctr[7];
	assign ien = ctr[6];

	// hookup byte controller block
	i2c_master_byte_ctrl byte_controller (
		.clk      ( wb_clk_i     ),
		.rst      ( wb_rst_i     ),
		.nReset   ( rst_i        ),
		.ena      ( core_en      ),
		.clk_cnt  ( prer         ),
		.start    ( sta          ),
		.stop     ( sto          ),
		.read     ( rd           ),
		.write    ( wr           ),
		.ack_in   ( ack          ),
		.din      ( txr          ),
		.cmd_ack  ( done         ),
		.ack_out  ( irxack       ),
		.dout     ( rxr          ),
		.i2c_busy ( i2c_busy     ),
		.i2c_al   ( i2c_al       ),
		.scl_i    ( scl_pad_i    ),
		.scl_o    ( scl_pad_o    ),
		.scl_oen  ( scl_padoen_o ),
		.sda_i    ( sda_pad_i    ),
		.sda_o    ( sda_pad_o    ),
		.sda_oen  ( sda_padoen_o )
	);

	// status register block + interrupt request signal
	always @(posedge wb_clk_i or negedge rst_i)
	  if (!rst_i)
	    begin
	        al       <= #1 1'b0;
	        rxack    <= #1 1'b0;
	        tip      <= #1 1'b0;
	        irq_flag <= #1 1'b0;
	    end
	  else if (wb_rst_i)
	    begin
	        al       <= #1 1'b0;
	        rxack    <= #1 1'b0;
	        tip      <= #1 1'b0;
	        irq_flag <= #1 1'b0;
	    end
	  else
	    begin
	        al       <= #1 i2c_al | (al & ~sta);
	        rxack    <= #1 irxack;
	        tip      <= #1 (rd | wr);
	        irq_flag <= #1 (done | i2c_al | irq_flag) & ~iack; // interrupt request flag is always generated
	    end

	// generate interrupt request signals
	always @(posedge wb_clk_i or negedge rst_i)
	  if (!rst_i)
	    wb_inta_o <= #1 1'b0;
	  else if (wb_rst_i)
	    wb_inta_o <= #1 1'b0;
	  else
	    wb_inta_o <= #1 irq_flag && ien; // interrupt signal is only generated when IEN (interrupt enable bit is set)

	// assign status register bits
	assign sr[7]   = rxack;
	assign sr[6]   = i2c_busy;
	assign sr[5]   = al;
	assign sr[4:2] = 3'h0; // reserved
	assign sr[1]   = tip;
	assign sr[0]   = irq_flag;

endmodule
