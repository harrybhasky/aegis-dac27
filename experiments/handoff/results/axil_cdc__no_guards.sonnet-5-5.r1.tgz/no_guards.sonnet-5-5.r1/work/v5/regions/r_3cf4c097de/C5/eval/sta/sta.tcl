read_liberty /home/lalit/Documents/dev/aegis-dac27/aegis_agents/pdk/nangate45.lib
read_verilog /home/lalit/Documents/dev/aegis-dac27/aegis_agents/flow/runs/axil_cdc/no_guards.sonnet-5-5.r1/work/v5/regions/r_3cf4c097de/C5/eval/sta/netlist.v
link_design axil_cdc
read_sdc /home/lalit/Documents/dev/aegis-dac27/aegis_agents/flow/designs/axil_cdc/axil_cdc.sdc
set ::env(AEGIS_MARGIN) 0.05
set ::env(AEGIS_STA_RPT) /home/lalit/Documents/dev/aegis-dac27/aegis_agents/flow/runs/axil_cdc/no_guards.sonnet-5-5.r1/work/v5/regions/r_3cf4c097de/C5/eval/sta/endpoints.rpt
source /home/lalit/Documents/dev/aegis-dac27/aegis_agents/tools/sta_endpoints.tcl
report_checks -path_delay max -format full -group_path_count 1 > /home/lalit/Documents/dev/aegis-dac27/aegis_agents/flow/runs/axil_cdc/no_guards.sonnet-5-5.r1/work/v5/regions/r_3cf4c097de/C5/eval/sta/groups.rpt
report_checks -unconstrained -path_delay max -format end -group_path_count 5 > /home/lalit/Documents/dev/aegis-dac27/aegis_agents/flow/runs/axil_cdc/no_guards.sonnet-5-5.r1/work/v5/regions/r_3cf4c097de/C5/eval/sta/unconstrained.rpt
exit