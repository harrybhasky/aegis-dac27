/*

Copyright (c) 2019 Alex Forencich

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

*/

// Language: Verilog 2001

`resetall
`timescale 1ns / 1ps
`default_nettype none
module axil_cdc_wr #
(
    // Width of data bus in bits
    parameter DATA_WIDTH = 32,
    // Width of address bus in bits
    parameter ADDR_WIDTH = 32,
    // Width of wstrb (width of data bus in words)
    parameter STRB_WIDTH = (DATA_WIDTH/8)
)
(
    /*
     * AXI lite slave interface
     */
    input  wire                   s_clk,
    input  wire                   s_rst,
    input  wire [ADDR_WIDTH-1:0]  s_axil_awaddr,
    input  wire [2:0]             s_axil_awprot,
    input  wire                   s_axil_awvalid,
    output wire                   s_axil_awready,
    input  wire [DATA_WIDTH-1:0]  s_axil_wdata,
    input  wire [STRB_WIDTH-1:0]  s_axil_wstrb,
    input  wire                   s_axil_wvalid,
    output wire                   s_axil_wready,
    output wire [1:0]             s_axil_bresp,
    output wire                   s_axil_bvalid,
    input  wire                   s_axil_bready,

    /*
     * AXI lite master interface
     */
    input  wire                   m_clk,
    input  wire                   m_rst,
    output wire [ADDR_WIDTH-1:0]  m_axil_awaddr,
    output wire [2:0]             m_axil_awprot,
    output wire                   m_axil_awvalid,
    input  wire                   m_axil_awready,
    output wire [DATA_WIDTH-1:0]  m_axil_wdata,
    output wire [STRB_WIDTH-1:0]  m_axil_wstrb,
    output wire                   m_axil_wvalid,
    input  wire                   m_axil_wready,
    input  wire [1:0]             m_axil_bresp,
    input  wire                   m_axil_bvalid,
    output wire                   m_axil_bready
);

reg [1:0] s_state_reg = 2'd0;
reg s_flag_reg = 1'b0;
(* srl_style = "register" *)
reg s_flag_sync_reg_1 = 1'b0;
(* srl_style = "register" *)
reg s_flag_sync_reg_2 = 1'b0;

reg [1:0] m_state_reg = 2'd0;
reg m_flag_reg = 1'b0;
(* srl_style = "register" *)
reg m_flag_sync_reg_1 = 1'b0;
(* srl_style = "register" *)
reg m_flag_sync_reg_2 = 1'b0;

reg [ADDR_WIDTH-1:0]  s_axil_awaddr_reg = {ADDR_WIDTH{1'b0}};
reg [2:0]             s_axil_awprot_reg = 3'd0;
reg                   s_axil_awvalid_reg = 1'b0;
reg [DATA_WIDTH-1:0]  s_axil_wdata_reg = {DATA_WIDTH{1'b0}};
reg [STRB_WIDTH-1:0]  s_axil_wstrb_reg = {STRB_WIDTH{1'b0}};
reg                   s_axil_wvalid_reg = 1'b0;
reg [1:0]             s_axil_bresp_reg = 2'b00;
reg                   s_axil_bvalid_reg = 1'b0;

reg [ADDR_WIDTH-1:0]  m_axil_awaddr_reg = {ADDR_WIDTH{1'b0}};
reg [2:0]             m_axil_awprot_reg = 3'd0;
reg                   m_axil_awvalid_reg = 1'b0;
reg [DATA_WIDTH-1:0]  m_axil_wdata_reg = {DATA_WIDTH{1'b0}};
reg [STRB_WIDTH-1:0]  m_axil_wstrb_reg = {STRB_WIDTH{1'b0}};
reg                   m_axil_wvalid_reg = 1'b0;
reg [1:0]             m_axil_bresp_reg = 2'b00;
reg                   m_axil_bvalid_reg = 1'b1;

assign s_axil_awready = !s_axil_awvalid_reg && !s_axil_bvalid_reg;
assign s_axil_wready = !s_axil_wvalid_reg && !s_axil_bvalid_reg;
assign s_axil_bresp = s_axil_bresp_reg;
assign s_axil_bvalid = s_axil_bvalid_reg;

assign m_axil_awaddr = m_axil_awaddr_reg;
assign m_axil_awprot = m_axil_awprot_reg;
assign m_axil_awvalid = m_axil_awvalid_reg;
assign m_axil_wdata = m_axil_wdata_reg;
assign m_axil_wstrb = m_axil_wstrb_reg;
assign m_axil_wvalid = m_axil_wvalid_reg;
assign m_axil_bready = !m_axil_bvalid_reg;

// slave side
always @(posedge s_clk) begin
    s_axil_bvalid_reg <= s_axil_bvalid_reg && !s_axil_bready;

    if (!s_axil_awvalid_reg && !s_axil_bvalid_reg) begin
        s_axil_awaddr_reg <= s_axil_awaddr;
        s_axil_awprot_reg <= s_axil_awprot;
        s_axil_awvalid_reg <= s_axil_awvalid;
    end

    if (!s_axil_wvalid_reg && !s_axil_bvalid_reg) begin
        s_axil_wdata_reg <= s_axil_wdata;
        s_axil_wstrb_reg <= s_axil_wstrb;
        s_axil_wvalid_reg <= s_axil_wvalid;
    end

    case (s_state_reg)
        2'd0: begin
            if (s_axil_awvalid_reg && s_axil_wvalid_reg) begin
                s_state_reg <= 2'd1;
                s_flag_reg <= 1'b1;
            end
        end
        2'd1: begin
            if (m_flag_sync_reg_2) begin
                s_state_reg <= 2'd2;
                s_flag_reg <= 1'b0;
                s_axil_bresp_reg <= m_axil_bresp_reg;
                s_axil_bvalid_reg <= 1'b1;
            end
        end
        2'd2: begin
            if (!m_flag_sync_reg_2) begin
                s_state_reg <= 2'd0;
                s_axil_awvalid_reg <= 1'b0;
                s_axil_wvalid_reg <= 1'b0;
            end
        end
    endcase

    if (s_rst) begin
        s_state_reg <= 2'd0;
        s_flag_reg <= 1'b0;
        s_axil_awvalid_reg <= 1'b0;
        s_axil_wvalid_reg <= 1'b0;
        s_axil_bvalid_reg <= 1'b0;
    end
end

// synchronization
always @(posedge s_clk) begin
    m_flag_sync_reg_1 <= m_flag_reg;
    m_flag_sync_reg_2 <= m_flag_sync_reg_1;
end

always @(posedge m_clk) begin
    s_flag_sync_reg_1 <= s_flag_reg;
    s_flag_sync_reg_2 <= s_flag_sync_reg_1;
end

// master side
// Shannon expansion on the late signal s_flag_sync_reg_2:
// every next-state value is computed for flag=1 and flag=0 independently
// of the flag, and the flag is used only as the final mux select.
wire m_st0 = (m_state_reg == 2'd0);
wire m_st1 = (m_state_reg == 2'd1);
wire m_st2 = (m_state_reg == 2'd2);

// valid flags
wire awv_hold = m_axil_awvalid_reg && !m_axil_awready;
wire wv_hold  = m_axil_wvalid_reg  && !m_axil_wready;
wire awv_f1 = !m_rst && (m_st0 ? 1'b1 : awv_hold);
wire awv_f0 = !m_rst && awv_hold;
wire wv_f1  = !m_rst && (m_st0 ? 1'b1 : wv_hold);
wire wv_f0  = !m_rst && wv_hold;

// bvalid
wire bv_base = m_axil_bvalid_reg ? m_axil_bvalid_reg : m_axil_bvalid;
wire bv_f1 = m_rst ? 1'b1 : (m_st0 ? 1'b0 : bv_base);
wire bv_f0 = m_rst ? 1'b1 : bv_base;

// state
wire [1:0] st_s1 = m_axil_bvalid_reg ? 2'd2 : 2'd1;
wire [1:0] st_f1 = m_rst ? 2'd0 :
                   m_st0 ? 2'd1 :
                   m_st1 ? st_s1 :
                   m_st2 ? 2'd2 : m_state_reg;
wire [1:0] st_f0 = m_rst ? 2'd0 :
                   m_st0 ? 2'd0 :
                   m_st1 ? st_s1 :
                   m_st2 ? 2'd0 : m_state_reg;

// m_flag_reg
wire mf_s1 = m_st1 && m_axil_bvalid_reg;
wire mf_f1 = !m_rst && (mf_s1 ? 1'b1 : m_flag_reg);
wire mf_f0 = !m_rst && (mf_s1 ? 1'b1 : (m_st2 ? 1'b0 : m_flag_reg));

// data registers: flag=1 loads when in state 0, flag=0 always holds
wire [ADDR_WIDTH-1:0] awaddr_f1 = m_st0 ? s_axil_awaddr_reg : m_axil_awaddr_reg;
wire [2:0]            awprot_f1 = m_st0 ? s_axil_awprot_reg : m_axil_awprot_reg;
wire [DATA_WIDTH-1:0] wdata_f1  = m_st0 ? s_axil_wdata_reg  : m_axil_wdata_reg;
wire [STRB_WIDTH-1:0] wstrb_f1  = m_st0 ? s_axil_wstrb_reg  : m_axil_wstrb_reg;

always @(posedge m_clk) begin
    if (!m_axil_bvalid_reg) begin
        m_axil_bresp_reg <= m_axil_bresp;
    end

    m_axil_awvalid_reg <= s_flag_sync_reg_2 ? awv_f1 : awv_f0;
    m_axil_wvalid_reg  <= s_flag_sync_reg_2 ? wv_f1  : wv_f0;
    m_axil_bvalid_reg  <= s_flag_sync_reg_2 ? bv_f1  : bv_f0;
    m_state_reg        <= s_flag_sync_reg_2 ? st_f1  : st_f0;
    m_flag_reg         <= s_flag_sync_reg_2 ? mf_f1  : mf_f0;

    m_axil_awaddr_reg  <= s_flag_sync_reg_2 ? awaddr_f1 : m_axil_awaddr_reg;
    m_axil_awprot_reg  <= s_flag_sync_reg_2 ? awprot_f1 : m_axil_awprot_reg;
    m_axil_wdata_reg   <= s_flag_sync_reg_2 ? wdata_f1  : m_axil_wdata_reg;
    m_axil_wstrb_reg   <= s_flag_sync_reg_2 ? wstrb_f1  : m_axil_wstrb_reg;
end

endmodule

`resetall
