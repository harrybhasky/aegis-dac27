////////////////////////////////////////////////////////////////////////////////
//
// Filename:	rtl/afifo.v
// {{{
// Project:	WB2AXIPSP: bus bridges and other odds and ends
//
// Purpose:	A basic asynchronous FIFO.
//
// Creator:	Dan Gisselquist, Ph.D.
//		Gisselquist Technology, LLC
//
////////////////////////////////////////////////////////////////////////////////
// }}}
// Copyright (C) 2019-2025, Gisselquist Technology, LLC
// {{{
// This file is part of the WB2AXIP project.
//
// The WB2AXIP project contains free software and gateware, licensed under the
// Apache License, Version 2.0 (the "License").  You may not use this project,
// or this file, except in compliance with the License.  You may obtain a copy
// of the License at
// }}}
//	http://www.apache.org/licenses/LICENSE-2.0
// {{{
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
// WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  See the
// License for the specific language governing permissions and limitations
// under the License.
//
////////////////////////////////////////////////////////////////////////////////
//
//
`default_nettype	none
module afifo #(
		// {{{
		// LGFIFO is the log based-two of the number of entries
		//	in the FIFO, log_2(fifo size)
		parameter	LGFIFO = 3,
		//
		// WIDTH is the number of data bits in each entry
		parameter	WIDTH  = 16,
		//
		// NFF is the number of flip flops used to cross clock domains.
		// 2 is a minimum.  Some applications appreciate the better
		parameter	NFF    = 2,
		//
		// This core can either write on the positive edge of the clock
		// or the negative edge.  Set WRITE_ON_POSEDGE (the default)
		// to write on the positive edge of the clock.
		parameter [0:0]	WRITE_ON_POSEDGE = 1'b1,
		//
		// Many logic elements can read from memory asynchronously.
		// This capability is sometimes known as "Distributed RAM" or
		// "LUT RAM".  Doing so, however, burdens the timing of any
		// logic to follow.  By setting OPT_REGISTER_READS, we force
		// all reads to be synchronous and not burdened by any logic.
		// This tends to work with more hardware.  If your hardware does
		// support "Distributed RAM", then you may be able to spare a
		// clock of latency by clearing this parameter.
		parameter [0:0]	OPT_REGISTER_READS = 1'b1
`ifdef	FORMAL
		// F_OPT_DATA_STB
		// {{{
		// In the formal proof, F_OPT_DATA_STB includes a series of
		// assumptions associated with a data strobe I/O pin--things
		// like a discontinuous clock--just to make sure the core still
		// works in those circumstances
		, parameter [0:0]	F_OPT_DATA_STB = 1'b1
		// }}}
`endif
		// }}}
	) (
		// {{{
		//
		// The (incoming) write data interface
		input	wire			i_wclk, i_wr_reset_n, i_wr,
		input	wire	[WIDTH-1:0]	i_wr_data,
		output	reg			o_wr_full,
		//
		// The (incoming) write data interface
		input	wire			i_rclk, i_rd_reset_n, i_rd,
		output	reg	[WIDTH-1:0]	o_rd_data,
		output	reg			o_rd_empty
`ifdef	FORMAL
		, output reg	[LGFIFO:0]	f_fill
`endif
		// }}}
	);

	// Register/net declarations
	// {{{
	// MSB = most significant bit of the FIFO address vector.  It's
	// just short-hand for LGFIFO, and won't work any other way.
	localparam	MSB = LGFIFO;
	//
	reg	[WIDTH-1:0]		mem	[(1<<LGFIFO)-1:0];
	reg	[LGFIFO:0]		rd_addr, wr_addr,
					rd_wgray, wr_rgray;
	wire	[LGFIFO:0]		next_rd_addr, next_wr_addr;
	reg	[LGFIFO:0]		rgray, wgray;
	(* ASYNC_REG = "TRUE" *) reg	[(LGFIFO+1)*(NFF-1)-1:0]
					rgray_cross, wgray_cross;
	wire				wclk;
	reg	[WIDTH-1:0]		lcl_rd_data;
	reg				lcl_read, lcl_rd_empty;
	// }}}

	// wclk - Write clock generation
	// {{{
	generate if (WRITE_ON_POSEDGE)
	begin : GEN_POSEDGE_WRITES

		assign	wclk = i_wclk;

	end else begin : GEN_NEGEDGE_WRITES

		assign	wclk = !i_wclk;

	end endgenerate
	// }}}

	////////////////////////////////////////////////////////////////////////
	//
	// Write to and read from memory
	// {{{
	////////////////////////////////////////////////////////////////////////
	//
	//

	// wr_addr, wgray
	// {{{
	assign	next_wr_addr = wr_addr + 1;
	always @(posedge wclk or negedge i_wr_reset_n)
	if (!i_wr_reset_n)
	begin
		wr_addr <= 0;
		wgray   <= 0;
	end else if (i_wr && !o_wr_full)
	begin
		wr_addr <= next_wr_addr;
		wgray   <= next_wr_addr ^ (next_wr_addr >> 1);
	end
	// }}}

	// Shannon expansion of the full compare on late bits wgray[MSB], wgray[MSB-1]
	wire		full_lo_match = (wr_rgray[MSB-2:0] == wgray[MSB-2:0]);
	wire		full_g00 = full_lo_match &&  wr_rgray[MSB] &&  wr_rgray[MSB-1]; // wgray[MSB:MSB-1] = 00
	wire		full_g01 = full_lo_match &&  wr_rgray[MSB] && !wr_rgray[MSB-1]; // 01
	wire		full_g10 = full_lo_match && !wr_rgray[MSB] &&  wr_rgray[MSB-1]; // 10
	wire		full_g11 = full_lo_match && !wr_rgray[MSB] && !wr_rgray[MSB-1]; // 11
	wire		full_sel = wgray[MSB] ? (wgray[MSB-1] ? full_g11 : full_g10)
					      : (wgray[MSB-1] ? full_g01 : full_g00);
	wire		wen_g00 = i_wr && !full_g00;
	wire		wen_g01 = i_wr && !full_g01;
	wire		wen_g10 = i_wr && !full_g10;
	wire		wen_g11 = i_wr && !full_g11;
	wire		wen_sel = wgray[MSB] ? (wgray[MSB-1] ? wen_g11 : wen_g10)
					     : (wgray[MSB-1] ? wen_g01 : wen_g00);

	// Write to memory
	// {{{
	always @(posedge wclk)
	if (wen_sel)
		mem[wr_addr[LGFIFO-1:0]] <= i_wr_data;
	// }}}

	// rd_addr, rgray
	// {{{
	assign	next_rd_addr = rd_addr + 1;
	always @(posedge i_rclk or negedge i_rd_reset_n)
	if (!i_rd_reset_n)
	begin
		rd_addr <= 0;
		rgray   <= 0;
	end else if (lcl_read && !lcl_rd_empty)
	begin
		rd_addr <= next_rd_addr;
		rgray   <= next_rd_addr ^ (next_rd_addr >> 1);
	end
	// }}}

	// Read from memory
	// {{{
	always @(*)
		lcl_rd_data = mem[rd_addr[LGFIFO-1:0]];
	// }}}
	// }}}
	////////////////////////////////////////////////////////////////////////
	//
	// Cross clock domains
	// {{{
	////////////////////////////////////////////////////////////////////////
	//
	//

	// read pointer -> wr_rgray
	// {{{
	always @(posedge wclk or negedge i_wr_reset_n)
	if (!i_wr_reset_n)
		{ wr_rgray, rgray_cross } <= 0;
	else
		{ wr_rgray, rgray_cross } <= { rgray_cross, rgray };
	// }}}

	// write pointer -> rd_wgray
	// {{{
	always @(posedge i_rclk or negedge i_rd_reset_n)
	if (!i_rd_reset_n)
		{ rd_wgray, wgray_cross } <= 0;
	else
		{ rd_wgray, wgray_cross } <= { wgray_cross, wgray };
	// }}}

	// }}}
	////////////////////////////////////////////////////////////////////////
	//
	// Flag generation
	// {{{
	////////////////////////////////////////////////////////////////////////
	//
	//

	always @(*)
		o_wr_full = full_sel;

	always @(*)
		lcl_rd_empty = (rd_wgray == rgray);

	// o_rd_empty, o_rd_data
	// {{{
	generate if (OPT_REGISTER_READS)
	begin : GEN_REGISTERED_READ
		// {{{
		always @(*)
			lcl_read = (o_rd_empty || i_rd);

		always @(posedge i_rclk or negedge i_rd_reset_n)
		if (!i_rd_reset_n)
			o_rd_empty <= 1'b1;
		else if (lcl_read)
			o_rd_empty <= lcl_rd_empty;

		always @(posedge i_rclk)
		if (lcl_read)
			o_rd_data <= lcl_rd_data;
		// }}}
	end else begin : GEN_COMBINATORIAL_FLAGS
		// {{{
		always @(*)
			lcl_read = i_rd;

		always @(*)
			o_rd_empty = lcl_rd_empty;

		always @(*)
			o_rd_data = lcl_rd_data;
		// }}}
	end endgenerate
	// }}}
	// }}}
endmodule
