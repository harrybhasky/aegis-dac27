// file ticket_machine.v4.3.v
module ticket_machine #(
    parameter ON  = 1'b1,
    parameter OFF = 1'b0
) (
    input  clk, clear, ten, twenty,
    output reg ready, dispense, return_sig, bill
);

    // use one-hot encoding to define states
    localparam RDY    = 6'b000001,
               DISP   = 6'b000010,
               RTN    = 6'b000100,
               BILL10 = 6'b001000,
               BILL20 = 6'b010000,
               BILL30 = 6'b100000;

    reg [5:0] State;
    reg [5:0] NextState;

    // shared exact state pre-decode (illegal states match none)
    wire is_rdy  = (State == RDY);
    wire is_disp = (State == DISP);
    wire is_rtn  = (State == RTN);
    wire is_b10  = (State == BILL10);
    wire is_b20  = (State == BILL20);
    wire is_b30  = (State == BILL30);

    // shared input conditions
    wire t_only = ten;
    wire w_only = ~ten & twenty;
    wire none   = ~ten & ~twenty;
    wire any_in = ten | twenty;

    // next-state per bit (flat AND-OR), illegal/DISP/RTN -> RDY
    wire n0 = ~((is_rdy & any_in) | is_b10 | is_b20 | is_b30);
    wire n1 = (is_b20 & w_only) | (is_b30 & t_only);
    wire n2 = is_b30 & w_only;
    wire n3 = (is_rdy & t_only) | (is_b10 & none);
    wire n4 = (is_rdy & w_only) | (is_b10 & t_only) | (is_b20 & none);
    wire n5 = (is_b10 & w_only) | (is_b20 & t_only) | (is_b30 & none);

    always @(*) begin
        NextState = {n5, n4, n3, n2, n1, n0};
    end

    // update state on clock rising edge
    always @(posedge clk) begin
        if (clear)
            State <= RDY;
        else
            State <= NextState;
    end

    // Moore outputs from shared decode
    always @(*) begin
        ready      = is_rdy  ? ON : OFF;
        dispense   = is_disp ? ON : OFF;
        return_sig = is_rtn  ? ON : OFF;
        bill       = (is_b10 | is_b20 | is_b30) ? ON : OFF;
    end

endmodule