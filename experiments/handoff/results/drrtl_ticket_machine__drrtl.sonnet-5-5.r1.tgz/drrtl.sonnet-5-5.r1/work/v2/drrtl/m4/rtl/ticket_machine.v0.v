// file ticket_machine.v1.4.v
module ticket_machine #(
    parameter ON  = 1'b1,
    parameter OFF = 1'b0
) (
    input  clk, clear, ten, twenty,
    output reg ready, dispense, return_sig, bill
);

    // use one-hot encoding to define states
    localparam RDY    = 6'b000001,
               DISP   = 6'b000010,
               RTN    = 6'b000100,
               BILL10 = 6'b001000,
               BILL20 = 6'b010000,
               BILL30 = 6'b100000;

    reg [5:0] State;
    wire [5:0] NextState;

    // one-hot state bit aliases (direct bit meaning)
    wire s_rdy    = State[0];
    wire s_disp   = State[1];
    wire s_rtn    = State[2];
    wire s_bill10 = State[3];
    wire s_bill20 = State[4];
    wire s_bill30 = State[5];

    // shared input conditions (ten has priority over twenty)
    wire in_ten    = ten;
    wire in_twenty = ~ten & twenty;
    wire in_none   = ~ten & ~twenty;

    // next state logic: direct AND-OR on one-hot bits
    assign NextState[0] = (s_rdy & in_none) | s_disp | s_rtn;
    assign NextState[1] = (s_bill20 & in_twenty) | (s_bill30 & in_ten);
    assign NextState[2] = s_bill30 & in_twenty;
    assign NextState[3] = (s_rdy & in_ten) | (s_bill10 & in_none);
    assign NextState[4] = (s_rdy & in_twenty) | (s_bill10 & in_ten) | (s_bill20 & in_none);
    assign NextState[5] = (s_bill10 & in_twenty) | (s_bill20 & in_ten) | (s_bill30 & in_none);

    // update state on clock rising edge
    always @(posedge clk) begin
        if (clear)
            State <= RDY;
        else
            State <= NextState;
    end

    // output logic (Moore): direct from one-hot state bits
    always @(*) begin
        ready      = s_rdy;
        dispense   = s_disp;
        return_sig = s_rtn;
        bill       = s_bill10 | s_bill20 | s_bill30;
    end

endmodule