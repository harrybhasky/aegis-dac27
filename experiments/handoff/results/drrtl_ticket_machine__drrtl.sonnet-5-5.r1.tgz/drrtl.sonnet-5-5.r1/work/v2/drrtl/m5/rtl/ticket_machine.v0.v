// file ticket_machine.v1.5.v
module ticket_machine #(
    parameter ON  = 1'b1,
    parameter OFF = 1'b0
) (
    input  clk, clear, ten, twenty,
    output reg ready, dispense, return_sig, bill
);

    // use one-hot encoding to define states
    localparam RDY    = 6'b000001,
               DISP   = 6'b000010,
               RTN    = 6'b000100,
               BILL10 = 6'b001000,
               BILL20 = 6'b010000,
               BILL30 = 6'b100000;

    reg [5:0] State;
    reg [5:0] NextState;

    // shared input-condition wires (ten has priority over twenty)
    wire ot = ~ten & twenty;          // only twenty
    wire nt = ~ten & ~twenty;         // neither

    // one-hot state bits
    wire s_rdy    = State[0];
    wire s_disp   = State[1];
    wire s_rtn    = State[2];
    wire s_bill10 = State[3];
    wire s_bill20 = State[4];
    wire s_bill30 = State[5];

    // update state on clock rising edge
    always @(posedge clk) begin
        if (clear)
            State <= RDY;
        else
            State <= NextState;
    end

    // output logic (Moore): direct one-hot bit access
    always @(*) begin
        ready      = s_rdy;
        dispense   = s_disp;
        return_sig = s_rtn;
        bill       = s_bill10 | s_bill20 | s_bill30;
    end

    // next state logic: flat AND-OR per one-hot bit
    always @(*) begin
        NextState[0] = s_disp | s_rtn | (s_rdy & nt);
        NextState[1] = (s_bill20 & ot) | (s_bill30 & ten);
        NextState[2] = s_bill30 & ot;
        NextState[3] = (s_rdy & ten) | (s_bill10 & nt);
        NextState[4] = (s_rdy & ot) | (s_bill10 & ten) | (s_bill20 & nt);
        NextState[5] = (s_bill10 & ot) | (s_bill20 & ten) | (s_bill30 & nt);
    end

endmodule