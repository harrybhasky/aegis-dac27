// file ticket_machine.v1.1.v
module ticket_machine #(
    parameter ON  = 1'b1,
    parameter OFF = 1'b0
) (
    input  clk, clear, ten, twenty,
    output reg ready, dispense, return_sig, bill
);

    // use one-hot encoding to define states
    localparam RDY    = 6'b000001,
               DISP   = 6'b000010,
               RTN    = 6'b000100,
               BILL10 = 6'b001000,
               BILL20 = 6'b010000,
               BILL30 = 6'b100000;

    reg [5:0] State;

    // one-hot state bit aliases
    wire s_rdy    = State[0];
    wire s_disp   = State[1];
    wire s_rtn    = State[2];
    wire s_bill10 = State[3];
    wire s_bill20 = State[4];
    wire s_bill30 = State[5];

    // shared input conditions (ten has priority over twenty)
    wire t_only  = ten;
    wire w_only  = ~ten & twenty;
    wire none_in = ~ten & ~twenty;

    // next-state equations (direct one-hot form)
    wire n_rdy    = s_disp | s_rtn | (s_rdy & none_in);
    wire n_disp   = (s_bill20 & w_only) | (s_bill30 & t_only);
    wire n_rtn    = s_bill30 & w_only;
    wire n_bill10 = (s_rdy & t_only) | (s_bill10 & none_in);
    wire n_bill20 = (s_rdy & w_only) | (s_bill10 & t_only) | (s_bill20 & none_in);
    wire n_bill30 = (s_bill10 & w_only) | (s_bill20 & t_only) | (s_bill30 & none_in);

    wire [5:0] NextState = {n_bill30, n_bill20, n_bill10, n_rtn, n_disp, n_rdy};

    // update state on clock rising edge
    always @(posedge clk) begin
        if (clear)
            State <= RDY;
        else
            State <= NextState;
    end

    // Moore outputs: direct bit reads
    always @(*) begin
        ready      = State[0] ? ON : OFF;
        dispense   = State[1] ? ON : OFF;
        return_sig = State[2] ? ON : OFF;
        bill       = (State[3] | State[4] | State[5]) ? ON : OFF;
    end

endmodule