// file ticket_machine.v1.2.v
module ticket_machine #(
    parameter ON  = 1'b1,
    parameter OFF = 1'b0
) (
    input  clk, clear, ten, twenty,
    output reg ready, dispense, return_sig, bill
);

    // use one-hot encoding to define states
    localparam RDY    = 6'b000001,
               DISP   = 6'b000010,
               RTN    = 6'b000100,
               BILL10 = 6'b001000,
               BILL20 = 6'b010000,
               BILL30 = 6'b100000;

    reg [5:0] State, NextState;

    // exact state decode (full compare keeps illegal-state behavior identical)
    wire s_rdy  = (State == RDY);
    wire s_disp = (State == DISP);
    wire s_rtn  = (State == RTN);
    wire s_b10  = (State == BILL10);
    wire s_b20  = (State == BILL20);
    wire s_b30  = (State == BILL30);

    // balanced legal-state OR; illegal -> RDY
    wire legal_a = s_rdy | s_disp;
    wire legal_b = s_rtn | s_b10;
    wire legal_c = s_b20 | s_b30;
    wire legal   = (legal_a | legal_b) | legal_c;
    wire illegal = ~legal;

    // input priority conditions (ten has priority over twenty)
    wire w = twenty & ~ten;
    wire n = ~ten & ~twenty;

    // next-state equations
    wire [5:0] ns;
    assign ns[0] = s_disp | s_rtn | illegal | (s_rdy & n);
    assign ns[1] = (s_b20 & w) | (s_b30 & ten);
    assign ns[2] = s_b30 & w;
    assign ns[3] = (s_rdy & ten) | (s_b10 & n);
    assign ns[4] = (s_rdy & w) | (s_b10 & ten) | (s_b20 & n);
    assign ns[5] = (s_b10 & w) | (s_b20 & ten) | (s_b30 & n);

    always @(*) NextState = ns;

    // update state on clock rising edge
    always @(posedge clk) begin
        if (clear)
            State <= RDY;
        else
            State <= NextState;
    end

    // Moore outputs from shared decode
    wire bill_w = (s_b10 | s_b20) | s_b30;

    always @(*) begin
        ready      = s_rdy;
        dispense   = s_disp;
        return_sig = s_rtn;
        bill       = bill_w;
    end

endmodule