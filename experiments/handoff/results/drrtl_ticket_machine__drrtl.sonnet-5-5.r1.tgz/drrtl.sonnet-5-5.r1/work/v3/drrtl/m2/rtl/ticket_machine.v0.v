// file ticket_machine.v2.2.v
module ticket_machine #(
    parameter ON  = 1'b1,
    parameter OFF = 1'b0
) (
    input  clk, clear, ten, twenty,
    output reg ready, dispense, return_sig, bill
);

    // use one-hot encoding to define states
    localparam RDY    = 6'b000001,
               DISP   = 6'b000010,
               RTN    = 6'b000100,
               BILL10 = 6'b001000,
               BILL20 = 6'b010000,
               BILL30 = 6'b100000;

    reg [5:0] State;
    wire [5:0] NextState;

    // one-hot state bits used directly (no full 6-bit decode)
    wire s_rdy  = State[0];
    wire s_disp = State[1];
    wire s_rtn  = State[2];
    wire s_b10  = State[3];
    wire s_b20  = State[4];
    wire s_b30  = State[5];

    // shared input conditions (ten has priority over twenty)
    wire n_tw   = ~ten & twenty;
    wire n_none = ~ten & ~twenty;

    // per-bit next-state equations
    assign NextState[0] = s_disp | s_rtn | (s_rdy & n_none);
    assign NextState[1] = (s_b20 & n_tw) | (s_b30 & ten);
    assign NextState[2] = s_b30 & n_tw;
    assign NextState[3] = (s_rdy & ten) | (s_b10 & n_none);
    assign NextState[4] = (s_rdy & n_tw) | (s_b10 & ten) | (s_b20 & n_none);
    assign NextState[5] = (s_b10 & n_tw) | (s_b20 & ten) | (s_b30 & n_none);

    // update state on clock rising edge
    always @(posedge clk) begin
        if (clear)
            State <= RDY;
        else
            State <= NextState;
    end

    // Moore outputs: direct one-hot bit decode
    always @(*) begin
        ready      = State[0];
        dispense   = State[1];
        return_sig = State[2];
        bill       = State[3] | State[4] | State[5];
    end

endmodule