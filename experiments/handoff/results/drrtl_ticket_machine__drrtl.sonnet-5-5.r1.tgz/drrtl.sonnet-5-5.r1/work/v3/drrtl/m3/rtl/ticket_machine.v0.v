// file ticket_machine.v2.3.v
module ticket_machine #(
    parameter ON  = 1'b1,
    parameter OFF = 1'b0
) (
    input  clk, clear, ten, twenty,
    output reg ready, dispense, return_sig, bill
);

    // one-hot state encoding (bit index = state)
    localparam RDY    = 6'b000001,
               DISP   = 6'b000010,
               RTN    = 6'b000100,
               BILL10 = 6'b001000,
               BILL20 = 6'b010000,
               BILL30 = 6'b100000;

    reg [5:0] State;
    reg [5:0] NextState;

    // shared input conditions (priority: ten over twenty)
    wire hold        = ~ten & ~twenty;
    wire twenty_only = ~ten & twenty;

    // direct one-hot bit tests
    wire s_rdy = State[0];
    wire s_dsp = State[1];
    wire s_rtn = State[2];
    wire s_b10 = State[3];
    wire s_b20 = State[4];
    wire s_b30 = State[5];

    // state register with synchronous clear
    always @(posedge clk) begin
        if (clear)
            State <= RDY;
        else
            State <= NextState;
    end

    // next-state logic: flat AND-OR per one-hot bit
    always @(*) begin
        NextState[0] = s_dsp | s_rtn | (s_rdy & hold);
        NextState[1] = (s_b20 & twenty_only) | (s_b30 & ten);
        NextState[2] = s_b30 & twenty_only;
        NextState[3] = (s_b10 & hold) | (s_rdy & ten);
        NextState[4] = (s_b20 & hold) | (s_b10 & ten) | (s_rdy & twenty_only);
        NextState[5] = (s_b30 & hold) | (s_b20 & ten) | (s_b10 & twenty_only);
    end

    // Moore outputs directly from state bits
    always @(*) begin
        ready      = State[0];
        dispense   = State[1];
        return_sig = State[2];
        bill       = State[3] | State[4] | State[5];
    end

endmodule