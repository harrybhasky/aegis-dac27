// file ticket_machine.v2.4.v
module ticket_machine #(
    parameter ON  = 1'b1,
    parameter OFF = 1'b0
) (
    input  clk, clear, ten, twenty,
    output reg ready, dispense, return_sig, bill
);

    // use one-hot encoding to define states
    localparam RDY    = 6'b000001,
               DISP   = 6'b000010,
               RTN    = 6'b000100,
               BILL10 = 6'b001000,
               BILL20 = 6'b010000,
               BILL30 = 6'b100000;

    reg [5:0] State;

    // shared state decode (full equality: identical behavior in invalid states)
    wire is_rdy  = (State == RDY);
    wire is_disp = (State == DISP);
    wire is_rtn  = (State == RTN);
    wire is_b10  = (State == BILL10);
    wire is_b20  = (State == BILL20);
    wire is_b30  = (State == BILL30);
    wire any_valid = is_rdy | is_disp | is_rtn | is_b10 | is_b20 | is_b30;

    // shared input conditions (ten has priority over twenty)
    wire c_ten  = ten;
    wire c_tw   = ~ten & twenty;
    wire c_none = ~ten & ~twenty;

    // next-state equations (flat AND-OR)
    wire n_rdy  = (is_rdy & c_none) | is_disp | is_rtn | ~any_valid;
    wire n_disp = (is_b20 & c_tw) | (is_b30 & c_ten);
    wire n_rtn  = is_b30 & c_tw;
    wire n_b10  = (is_rdy & c_ten) | (is_b10 & c_none);
    wire n_b20  = (is_rdy & c_tw) | (is_b10 & c_ten) | (is_b20 & c_none);
    wire n_b30  = (is_b10 & c_tw) | (is_b20 & c_ten) | (is_b30 & c_none);

    // update state on clock rising edge (synchronous clear -> RDY)
    always @(posedge clk) begin
        State[0] <= clear | n_rdy;
        State[1] <= ~clear & n_disp;
        State[2] <= ~clear & n_rtn;
        State[3] <= ~clear & n_b10;
        State[4] <= ~clear & n_b20;
        State[5] <= ~clear & n_b30;
    end

    // output logic based on current state (Moore state machine)
    always @(*) begin
        ready      = is_rdy  ? ON : OFF;
        dispense   = is_disp ? ON : OFF;
        return_sig = is_rtn  ? ON : OFF;
        bill       = (is_b10 | is_b20 | is_b30) ? ON : OFF;
    end

endmodule