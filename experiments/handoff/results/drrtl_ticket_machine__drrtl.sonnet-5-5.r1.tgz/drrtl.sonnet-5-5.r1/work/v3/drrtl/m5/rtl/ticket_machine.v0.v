// file ticket_machine.v2.5.v
module ticket_machine #(
    parameter ON  = 1'b1,
    parameter OFF = 1'b0
) (
    input  clk, clear, ten, twenty,
    output reg ready, dispense, return_sig, bill
);

    // one-hot encoding: bit i set <=> state i
    localparam RDY    = 6'b000001,
               DISP   = 6'b000010,
               RTN    = 6'b000100,
               BILL10 = 6'b001000,
               BILL20 = 6'b010000,
               BILL30 = 6'b100000;

    reg  [5:0] State;
    wire [5:0] NextState;

    // shared input conditions (ten has priority over twenty)
    wire twenty_only = ~ten & twenty;
    wire hold        = ~ten & ~twenty;

    // next-state logic using direct one-hot bit access
    assign NextState[0] = State[1] | State[2] | (State[0] & hold);
    assign NextState[1] = (State[4] & twenty_only) | (State[5] & ten);
    assign NextState[2] = State[5] & twenty_only;
    assign NextState[3] = (State[0] & ten) | (State[3] & hold);
    assign NextState[4] = (State[0] & twenty_only) | (State[3] & ten) | (State[4] & hold);
    assign NextState[5] = (State[3] & twenty_only) | (State[4] & ten) | (State[5] & hold);

    // update state on clock rising edge
    always @(posedge clk) begin
        if (clear)
            State <= RDY;
        else
            State <= NextState;
    end

    // Moore outputs directly from state bits
    always @(*) begin
        ready      = State[0] ? ON : OFF;
        dispense   = State[1] ? ON : OFF;
        return_sig = State[2] ? ON : OFF;
        bill       = (State[3] | State[4] | State[5]) ? ON : OFF;
    end

endmodule