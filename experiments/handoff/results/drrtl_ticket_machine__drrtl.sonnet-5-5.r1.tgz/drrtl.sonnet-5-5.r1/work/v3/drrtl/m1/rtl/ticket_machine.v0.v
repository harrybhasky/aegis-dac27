// file ticket_machine.v2.1.v
module ticket_machine #(
    parameter ON  = 1'b1,
    parameter OFF = 1'b0
) (
    input  clk, clear, ten, twenty,
    output reg ready, dispense, return_sig, bill
);

    // use one-hot encoding to define states
    localparam RDY    = 6'b000001,
               DISP   = 6'b000010,
               RTN    = 6'b000100,
               BILL10 = 6'b001000,
               BILL20 = 6'b010000,
               BILL30 = 6'b100000;

    reg [5:0] State;
    reg [5:0] NextState;

    // one-hot state bit aliases
    wire s_rdy  = State[0];
    wire s_disp = State[1];
    wire s_rtn  = State[2];
    wire s_b10  = State[3];
    wire s_b20  = State[4];
    wire s_b30  = State[5];

    // shared input conditions (ten has priority over twenty)
    wire t_only  = ten;
    wire w_only  = ~ten & twenty;
    wire none_in = ~ten & ~twenty;

    // direct one-hot next-state equations
    wire n_rdy  = s_disp | s_rtn | (s_rdy & none_in);
    wire n_disp = (s_b20 & w_only) | (s_b30 & t_only);
    wire n_rtn  = s_b30 & w_only;
    wire n_b10  = (s_rdy & t_only) | (s_b10 & none_in);
    wire n_b20  = (s_rdy & w_only) | (s_b10 & t_only) | (s_b20 & none_in);
    wire n_b30  = (s_b10 & w_only) | (s_b20 & t_only) | (s_b30 & none_in);

    always @(*) begin
        NextState = {n_b30, n_b20, n_b10, n_rtn, n_disp, n_rdy};
    end

    // update state on clock rising edge
    always @(posedge clk) begin
        if (clear)
            State <= RDY;
        else
            State <= NextState;
    end

    // Moore outputs read directly from state bits
    always @(*) begin
        ready      = State[0];
        dispense   = State[1];
        return_sig = State[2];
        bill       = State[3] | State[4] | State[5];
    end

endmodule