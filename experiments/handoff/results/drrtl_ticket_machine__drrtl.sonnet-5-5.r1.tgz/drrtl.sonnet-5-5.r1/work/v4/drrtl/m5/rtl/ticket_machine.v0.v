// file ticket_machine.v3.5.v
module ticket_machine #(
    parameter ON  = 1'b1,
    parameter OFF = 1'b0
) (
    input  clk, clear, ten, twenty,
    output reg ready, dispense, return_sig, bill
);

    // use one-hot encoding to define states
    localparam RDY    = 6'b000001,
               DISP   = 6'b000010,
               RTN    = 6'b000100,
               BILL10 = 6'b001000,
               BILL20 = 6'b010000,
               BILL30 = 6'b100000;

    reg [5:0] State;
    wire [5:0] NextState;

    // shared input conditions (ten has priority over twenty)
    wire t10     = ten;
    wire t20     = ~ten & twenty;
    wire idle_in = ~ten & ~twenty;
    wire nclr    = ~clear;

    // one-hot next-state equations (State is always one-hot after reset)
    wire n_rdy    = clear | State[1] | State[2] | (State[0] & idle_in);
    wire n_disp   = nclr & ((State[4] & t20) | (State[5] & t10));
    wire n_rtn    = nclr & (State[5] & t20);
    wire n_bill10 = nclr & ((State[0] & t10) | (State[3] & idle_in));
    wire n_bill20 = nclr & ((State[0] & t20) | (State[3] & t10) | (State[4] & idle_in));
    wire n_bill30 = nclr & ((State[3] & t20) | (State[4] & t10) | (State[5] & idle_in));

    assign NextState = {n_bill30, n_bill20, n_bill10, n_rtn, n_disp, n_rdy};

    // state register (clear is folded into the next-state equations)
    always @(posedge clk) begin
        State <= NextState;
    end

    // Moore outputs directly from one-hot state bits
    always @(*) begin
        ready      = State[0];
        dispense   = State[1];
        return_sig = State[2];
        bill       = State[3] | State[4] | State[5];
    end

endmodule