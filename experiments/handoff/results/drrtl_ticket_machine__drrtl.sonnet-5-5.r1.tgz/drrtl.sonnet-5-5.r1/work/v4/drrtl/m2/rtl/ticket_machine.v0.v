// file ticket_machine.v3.2.v
module ticket_machine #(
    parameter ON  = 1'b1,
    parameter OFF = 1'b0
) (
    input  clk, clear, ten, twenty,
    output reg ready, dispense, return_sig, bill
);

    // use one-hot encoding to define states
    localparam RDY    = 6'b000001,
               DISP   = 6'b000010,
               RTN    = 6'b000100,
               BILL10 = 6'b001000,
               BILL20 = 6'b010000,
               BILL30 = 6'b100000;

    reg [5:0] State;
    wire [5:0] NextState;

    // shared input-condition wires (ten has priority over twenty)
    wire ten_only = ten;
    wire tw_only  = ~ten & twenty;
    wire none     = ~ten & ~twenty;

    // one-hot next-state equations using direct state bits
    wire n_rdy    = State[1] | State[2] | (State[0] & none);
    wire n_disp   = (State[4] & tw_only) | (State[5] & ten_only);
    wire n_rtn    = State[5] & tw_only;
    wire n_bill10 = (State[0] & ten_only) | (State[3] & none);
    wire n_bill20 = (State[0] & tw_only) | (State[3] & ten_only) | (State[4] & none);
    wire n_bill30 = (State[3] & tw_only) | (State[4] & ten_only) | (State[5] & none);

    assign NextState = {n_bill30, n_bill20, n_bill10, n_rtn, n_disp, n_rdy};

    // update state on clock rising edge
    always @(posedge clk) begin
        if (clear)
            State <= RDY;
        else
            State <= NextState;
    end

    // Moore outputs: direct one-hot bit decode
    always @(*) begin
        ready      = State[0] ? ON : OFF;
        dispense   = State[1] ? ON : OFF;
        return_sig = State[2] ? ON : OFF;
        bill       = (State[3] | State[4] | State[5]) ? ON : OFF;
    end

endmodule