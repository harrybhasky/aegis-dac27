// file ticket_machine.v3.4.v
module ticket_machine #(
    parameter ON  = 1'b1,
    parameter OFF = 1'b0
) (
    input  clk, clear, ten, twenty,
    output reg ready, dispense, return_sig, bill
);

    // use one-hot encoding to define states
    localparam RDY    = 6'b000001,
               DISP   = 6'b000010,
               RTN    = 6'b000100,
               BILL10 = 6'b001000,
               BILL20 = 6'b010000,
               BILL30 = 6'b100000;

    reg [5:0] State;
    wire [5:0] NextState;

    // shared input qualifiers (ten has priority over twenty)
    wire t = ten;
    wire w = ~ten & twenty;
    wire h = ~ten & ~twenty;

    // one-hot next-state equations (bit n = state n)
    assign NextState[0] = State[1] | State[2] | (State[0] & h);
    assign NextState[1] = (State[4] & w) | (State[5] & t);
    assign NextState[2] = State[5] & w;
    assign NextState[3] = (State[0] & t) | (State[3] & h);
    assign NextState[4] = (State[0] & w) | (State[3] & t) | (State[4] & h);
    assign NextState[5] = (State[3] & w) | (State[4] & t) | (State[5] & h);

    // update state on clock rising edge; clear forces RDY
    always @(posedge clk) begin
        if (clear)
            State <= RDY;
        else
            State <= NextState;
    end

    // Moore outputs taken directly from one-hot state bits
    always @(State) begin
        ready      = State[0];
        dispense   = State[1];
        return_sig = State[2];
        bill       = State[3] | State[4] | State[5];
    end

endmodule