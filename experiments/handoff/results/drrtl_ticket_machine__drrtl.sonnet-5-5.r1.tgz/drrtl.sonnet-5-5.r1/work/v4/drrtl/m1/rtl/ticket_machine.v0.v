// file ticket_machine.v3.1.v
module ticket_machine #(
    parameter ON  = 1'b1,
    parameter OFF = 1'b0
) (
    input  clk, clear, ten, twenty,
    output reg ready, dispense, return_sig, bill
);

    // use one-hot encoding to define states
    localparam RDY    = 6'b000001,
               DISP   = 6'b000010,
               RTN    = 6'b000100,
               BILL10 = 6'b001000,
               BILL20 = 6'b010000,
               BILL30 = 6'b100000;

    reg [5:0] State, NextState;

    // shared input conditions (ten has priority over twenty)
    wire hold        = ~ten & ~twenty;
    wire twenty_only = ~ten & twenty;

    // one-hot state bits
    wire s_rdy    = State[0];
    wire s_disp   = State[1];
    wire s_rtn    = State[2];
    wire s_bill10 = State[3];
    wire s_bill20 = State[4];
    wire s_bill30 = State[5];

    // update state on clock rising edge
    always @(posedge clk) begin
        if (clear)
            State <= RDY;
        else
            State <= NextState;
    end

    // output logic based on current state (Moore state machine), direct bit decode
    always @(*) begin
        ready      = s_rdy      ? ON : OFF;
        dispense   = s_disp     ? ON : OFF;
        return_sig = s_rtn      ? ON : OFF;
        bill       = (s_bill10 | s_bill20 | s_bill30) ? ON : OFF;
    end

    // next state logic: flat AND-OR equations on one-hot bits
    always @(*) begin
        NextState[0] = (s_rdy & hold) | s_disp | s_rtn;
        NextState[1] = (s_bill20 & twenty_only) | (s_bill30 & ten);
        NextState[2] = s_bill30 & twenty_only;
        NextState[3] = (s_rdy & ten) | (s_bill10 & hold);
        NextState[4] = (s_rdy & twenty_only) | (s_bill10 & ten) | (s_bill20 & hold);
        NextState[5] = (s_bill10 & twenty_only) | (s_bill20 & ten) | (s_bill30 & hold);
    end

endmodule