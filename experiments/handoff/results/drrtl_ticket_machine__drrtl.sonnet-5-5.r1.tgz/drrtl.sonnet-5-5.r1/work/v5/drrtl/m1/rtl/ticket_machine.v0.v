// file ticket_machine.v4.1.v
module ticket_machine #(
    parameter ON  = 1'b1,
    parameter OFF = 1'b0
) (
    input  clk, clear, ten, twenty,
    output reg ready, dispense, return_sig, bill
);

    // use one-hot encoding to define states
    localparam RDY    = 6'b000001,
               DISP   = 6'b000010,
               RTN    = 6'b000100,
               BILL10 = 6'b001000,
               BILL20 = 6'b010000,
               BILL30 = 6'b100000;

    reg [5:0] State, NextState;

    // one-hot state bits (direct bit meaning)
    wire s_rdy   = State[0];
    wire s_disp  = State[1];
    wire s_rtn   = State[2];
    wire s_b10   = State[3];
    wire s_b20   = State[4];
    wire s_b30   = State[5];

    // shared input conditions (ten has priority over twenty)
    wire c_ten   = ten;
    wire c_tw    = ~ten & twenty;
    wire c_hold  = ~ten & ~twenty;

    // next state logic: direct AND-OR per one-hot bit
    always @(*) begin
        NextState[0] = s_disp | s_rtn | (s_rdy & c_hold);
        NextState[1] = (s_b20 & c_tw) | (s_b30 & c_ten);
        NextState[2] = s_b30 & c_tw;
        NextState[3] = (s_rdy & c_ten) | (s_b10 & c_hold);
        NextState[4] = (s_rdy & c_tw) | (s_b10 & c_ten) | (s_b20 & c_hold);
        NextState[5] = (s_b10 & c_tw) | (s_b20 & c_ten) | (s_b30 & c_hold);
    end

    // update state on clock rising edge
    always @(posedge clk) begin 
        if (clear)
            State <= RDY;
        else
            State <= NextState;
    end

    // output logic (Moore): direct from one-hot bits
    always @(*) begin
        ready      = State[0];
        dispense   = State[1];
        return_sig = State[2];
        bill       = State[3] | State[4] | State[5];
    end

endmodule