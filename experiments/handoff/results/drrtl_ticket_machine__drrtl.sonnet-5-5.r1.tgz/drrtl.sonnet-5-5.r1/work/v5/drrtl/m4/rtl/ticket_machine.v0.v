// file ticket_machine.v4.4.v
module ticket_machine #(
    parameter ON  = 1'b1,
    parameter OFF = 1'b0
) (
    input  clk, clear, ten, twenty,
    output reg ready, dispense, return_sig, bill
);

    // use one-hot encoding to define states
    localparam RDY    = 6'b000001,
               DISP   = 6'b000010,
               RTN    = 6'b000100,
               BILL10 = 6'b001000,
               BILL20 = 6'b010000,
               BILL30 = 6'b100000;

    reg [5:0] State;
    reg [5:0] NextState;

    // one-hot state taps (state is one-hot from reset)
    wire s_rdy  = State[0];
    wire s_disp = State[1];
    wire s_rtn  = State[2];
    wire s_b10  = State[3];
    wire s_b20  = State[4];
    wire s_b30  = State[5];

    // shared input conditions (ten has priority over twenty)
    wire no_in   = ~ten & ~twenty;
    wire only_tw = ~ten & twenty;

    // update state on clock rising edge
    always @(posedge clk) begin
        if (clear)
            State <= RDY;
        else
            State <= NextState;
    end

    // output logic (Moore): direct bit taps
    always @(*) begin
        ready      = s_rdy  ? ON : OFF;
        dispense   = s_disp ? ON : OFF;
        return_sig = s_rtn  ? ON : OFF;
        bill       = (s_b10 | s_b20 | s_b30) ? ON : OFF;
    end

    // next state logic: flat one-hot AND-OR equations
    always @(*) begin
        NextState[0] = (s_rdy & no_in) | s_disp | s_rtn;
        NextState[1] = (s_b20 & only_tw) | (s_b30 & ten);
        NextState[2] = s_b30 & only_tw;
        NextState[3] = (s_rdy & ten) | (s_b10 & no_in);
        NextState[4] = (s_rdy & only_tw) | (s_b10 & ten) | (s_b20 & no_in);
        NextState[5] = (s_b10 & only_tw) | (s_b20 & ten) | (s_b30 & no_in);
    end

endmodule