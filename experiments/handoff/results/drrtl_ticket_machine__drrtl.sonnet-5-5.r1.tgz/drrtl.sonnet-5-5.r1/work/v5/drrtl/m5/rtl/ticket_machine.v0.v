// file ticket_machine.v4.5.v
module ticket_machine #(
    parameter ON  = 1'b1,
    parameter OFF = 1'b0
) (
    input  clk, clear, ten, twenty,
    output reg ready, dispense, return_sig, bill
);

    // use one-hot encoding to define states
    localparam RDY    = 6'b000001,
               DISP   = 6'b000010,
               RTN    = 6'b000100,
               BILL10 = 6'b001000,
               BILL20 = 6'b010000,
               BILL30 = 6'b100000;

    reg [5:0] State;
    wire [5:0] NextState;

    // shared coin qualifiers (ten has priority over twenty)
    wire no_coin = ~ten & ~twenty;
    wire tw_only = ~ten &  twenty;

    // one-hot state bits
    wire s_rdy    = State[0];
    wire s_disp   = State[1];
    wire s_rtn    = State[2];
    wire s_bill10 = State[3];
    wire s_bill20 = State[4];
    wire s_bill30 = State[5];

    // next-state equations using direct one-hot bit tests
    assign NextState[0] = s_disp | s_rtn | (s_rdy & no_coin);
    assign NextState[1] = (s_bill20 & tw_only) | (s_bill30 & ten);
    assign NextState[2] = s_bill30 & tw_only;
    assign NextState[3] = (s_rdy & ten) | (s_bill10 & no_coin);
    assign NextState[4] = (s_rdy & tw_only) | (s_bill10 & ten) | (s_bill20 & no_coin);
    assign NextState[5] = (s_bill10 & tw_only) | (s_bill20 & ten) | (s_bill30 & no_coin);

    // update state on clock rising edge (synchronous clear to RDY)
    always @(posedge clk) begin
        if (clear)
            State <= RDY;
        else
            State <= NextState;
    end

    // Moore outputs directly from one-hot bits
    always @(*) begin
        ready      = s_rdy;
        dispense   = s_disp;
        return_sig = s_rtn;
        bill       = s_bill10 | s_bill20 | s_bill30;
    end

endmodule