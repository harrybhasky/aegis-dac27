// file ticket_machine.v0.1.v
module ticket_machine #(
    parameter ON  = 1'b1,
    parameter OFF = 1'b0
) (
    input  clk, clear, ten, twenty,
    output reg ready, dispense, return_sig, bill
);

    // use one-hot encoding to define states
    localparam RDY    = 6'b000001,
               DISP   = 6'b000010,
               RTN    = 6'b000100,
               BILL10 = 6'b001000,
               BILL20 = 6'b010000,
               BILL30 = 6'b100000;

    reg [5:0] State;
    wire [5:0] NextState;

    // shared state pre-decode (full equality kept for exact illegal-state behavior)
    wire state_is_rdy    = (State == RDY);
    wire state_is_disp   = (State == DISP);
    wire state_is_rtn    = (State == RTN);
    wire state_is_bill10 = (State == BILL10);
    wire state_is_bill20 = (State == BILL20);
    wire state_is_bill30 = (State == BILL30);

    // shared input conditions (ten has priority over twenty)
    wire only_twenty = ~ten & twenty;
    wire neither     = ~ten & ~twenty;

    // flat next-state equations
    wire n_bill10 = (state_is_rdy & ten) |
                    (state_is_bill10 & neither);

    wire n_bill20 = (state_is_rdy & only_twenty) |
                    (state_is_bill10 & ten) |
                    (state_is_bill20 & neither);

    wire n_bill30 = (state_is_bill10 & only_twenty) |
                    (state_is_bill20 & ten) |
                    (state_is_bill30 & neither);

    wire n_disp   = (state_is_bill20 & only_twenty) |
                    (state_is_bill30 & ten);

    wire n_rtn    = state_is_bill30 & only_twenty;

    // everything else (RDY hold, DISP, RTN, illegal states) goes to RDY
    wire n_rdy    = ~(n_bill10 | n_bill20 | n_bill30 | n_disp | n_rtn);

    assign NextState = {n_bill30, n_bill20, n_bill10, n_rtn, n_disp, n_rdy};

    // update state on clock rising edge; clear folded in as a final gate
    always @(posedge clk) begin
        State[0] <= clear | n_rdy;
        State[1] <= ~clear & n_disp;
        State[2] <= ~clear & n_rtn;
        State[3] <= ~clear & n_bill10;
        State[4] <= ~clear & n_bill20;
        State[5] <= ~clear & n_bill30;
    end

    // Moore outputs from shared decode wires
    always @(*) begin
        ready      = state_is_rdy    ? ON : OFF;
        dispense   = state_is_disp   ? ON : OFF;
        return_sig = state_is_rtn    ? ON : OFF;
        bill       = (state_is_bill10 | state_is_bill20 | state_is_bill30) ? ON : OFF;
    end

endmodule