// file ticket_machine.v0.5.v
module ticket_machine #(
    parameter ON  = 1'b1,
    parameter OFF = 1'b0
) (
    input  clk, clear, ten, twenty,
    output reg ready, dispense, return_sig, bill
);

    // use one-hot encoding to define states
    localparam RDY    = 6'b000001,
               DISP   = 6'b000010,
               RTN    = 6'b000100,
               BILL10 = 6'b001000,
               BILL20 = 6'b010000,
               BILL30 = 6'b100000;

    reg [5:0] State;

    // one-hot state bit aliases
    wire s_rdy    = State[0];
    wire s_disp   = State[1];
    wire s_rtn    = State[2];
    wire s_bill10 = State[3];
    wire s_bill20 = State[4];
    wire s_bill30 = State[5];

    // pre-decoded input conditions (ten has priority over twenty)
    wire ten_c    = ten;
    wire twenty_c = ~ten & twenty;
    wire hold_c   = ~ten & ~twenty;

    // next-state equations (direct AND-OR on one-hot bits)
    wire n_rdy    = s_disp | s_rtn | (s_rdy & hold_c);
    wire n_disp   = (s_bill20 & twenty_c) | (s_bill30 & ten_c);
    wire n_rtn    = s_bill30 & twenty_c;
    wire n_bill10 = (s_rdy & ten_c) | (s_bill10 & hold_c);
    wire n_bill20 = (s_rdy & twenty_c) | (s_bill10 & ten_c) | (s_bill20 & hold_c);
    wire n_bill30 = (s_bill10 & twenty_c) | (s_bill20 & ten_c) | (s_bill30 & hold_c);

    // update state on clock rising edge, with synchronous clear merged per bit
    always @(posedge clk) begin
        State[0] <= clear | n_rdy;
        State[1] <= ~clear & n_disp;
        State[2] <= ~clear & n_rtn;
        State[3] <= ~clear & n_bill10;
        State[4] <= ~clear & n_bill20;
        State[5] <= ~clear & n_bill30;
    end

    // Moore outputs directly from state bits
    always @(*) begin
        ready      = State[0] ? ON : OFF;
        dispense   = State[1] ? ON : OFF;
        return_sig = State[2] ? ON : OFF;
        bill       = (State[3] | State[4] | State[5]) ? ON : OFF;
    end

endmodule