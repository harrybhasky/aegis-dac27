// file ticket_machine.v0.4.v
module ticket_machine #(
    parameter ON  = 1'b1,
    parameter OFF = 1'b0
) (
    input  clk, clear, ten, twenty,
    output reg ready, dispense, return_sig, bill
);

    // one-hot states (bit index == state)
    localparam RDY    = 6'b000001,
               DISP   = 6'b000010,
               RTN    = 6'b000100,
               BILL10 = 6'b001000,
               BILL20 = 6'b010000,
               BILL30 = 6'b100000;

    reg [5:0] State;
    wire [5:0] NextState;

    // shared input conditions (ten has priority over twenty)
    wire hold    = ~ten & ~twenty;
    wire tw_only = ~ten &  twenty;

    // direct one-hot bit decode
    wire s_rdy = State[0];
    wire s_dsp = State[1];
    wire s_rtn = State[2];
    wire s_b10 = State[3];
    wire s_b20 = State[4];
    wire s_b30 = State[5];

    // flat AND-OR next-state equations
    assign NextState[0] = s_dsp | s_rtn | (s_rdy & hold);
    assign NextState[1] = (s_b20 & tw_only) | (s_b30 & ten);
    assign NextState[2] = s_b30 & tw_only;
    assign NextState[3] = (s_rdy & ten) | (s_b10 & hold);
    assign NextState[4] = (s_rdy & tw_only) | (s_b10 & ten) | (s_b20 & hold);
    assign NextState[5] = (s_b10 & tw_only) | (s_b20 & ten) | (s_b30 & hold);

    // synchronous clear folded into the final stage
    always @(posedge clk) begin
        State[0]   <= NextState[0] | clear;
        State[5:1] <= NextState[5:1] & {5{~clear}};
    end

    // Moore outputs: direct bit decode
    always @(*) begin
        ready      = State[0];
        dispense   = State[1];
        return_sig = State[2];
        bill       = State[3] | State[4] | State[5];
    end

endmodule