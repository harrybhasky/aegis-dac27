// file ticket_machine.v0.2.v
module ticket_machine #(
    parameter ON  = 1'b1,
    parameter OFF = 1'b0
) (
    input  clk, clear, ten, twenty,
    output reg ready, dispense, return_sig, bill
);

    // use one-hot encoding to define states
    localparam RDY    = 6'b000001,
               DISP   = 6'b000010,
               RTN    = 6'b000100,
               BILL10 = 6'b001000,
               BILL20 = 6'b010000,
               BILL30 = 6'b100000;

    reg [5:0] State;
    wire [5:0] NextState;

    // pre-computed input conditions (ten has priority over twenty)
    wire go_twenty = ~ten & twenty;
    wire go_hold   = ~ten & ~twenty;

    // direct one-hot bit meaning
    wire s_rdy    = State[0];
    wire s_disp   = State[1];
    wire s_rtn    = State[2];
    wire s_bill10 = State[3];
    wire s_bill20 = State[4];
    wire s_bill30 = State[5];

    // next-state logic: flat AND-OR equations on one-hot bits
    assign NextState[0] = s_disp | s_rtn | (s_rdy & go_hold);
    assign NextState[1] = (s_bill20 & go_twenty) | (s_bill30 & ten);
    assign NextState[2] = s_bill30 & go_twenty;
    assign NextState[3] = (s_rdy & ten) | (s_bill10 & go_hold);
    assign NextState[4] = (s_rdy & go_twenty) | (s_bill10 & ten) | (s_bill20 & go_hold);
    assign NextState[5] = (s_bill10 & go_twenty) | (s_bill20 & ten) | (s_bill30 & go_hold);

    // update state on clock rising edge
    always @(posedge clk) begin
        if (clear)
            State <= RDY;
        else
            State <= NextState;
    end

    // Moore outputs: direct one-hot bits
    always @(*) begin
        ready      = State[0];
        dispense   = State[1];
        return_sig = State[2];
        bill       = State[3] | State[4] | State[5];
    end

endmodule