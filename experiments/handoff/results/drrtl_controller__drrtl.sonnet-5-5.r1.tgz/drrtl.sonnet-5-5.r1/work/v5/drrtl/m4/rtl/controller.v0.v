// file controller.v4.4.v

module control_unit
(
	output reg [ 2:0] sbox_sel,
	output reg [ 1:0] rk_sel,
	output reg [ 1:0] key_out_sel,
	output reg [ 1:0] col_sel,
	output reg [ 3:0] key_en,
	output reg [ 3:0] col_en,
	output     [ 3:0] round,
	output reg bypass_rk,
	output reg bypass_key_en,
	output reg key_sel,
	output reg iv_cnt_en,
	output reg iv_cnt_sel,
	output reg key_derivation_en,
	output end_comp,
	output key_init,
	output key_gen,
	output mode_ctr,
	output mode_cbc,
	output last_round,
  output encrypt_decrypt,	
	input [1:0] operation_mode,
	input [1:0] aes_mode,
	input start,
	input disable_core,
	input clk,
	input rst_n
);

localparam ENCRYPTION     = 2'b00;
localparam KEY_DERIVATION = 2'b01;
localparam DECRYPTION     = 2'b10;
localparam DECRYP_W_DERIV = 2'b11;

localparam ECB = 2'b00;
localparam CBC = 2'b01;
localparam CTR = 2'b10;

localparam ENABLE = 1'b1;
localparam DISABLE = 1'b0;

localparam INITIAL_ROUND     = 4'd00;

localparam IDLE        = 4'd00;
localparam ROUND0_COL0 = 4'd01;
localparam ROUND0_COL1 = 4'd02;
localparam ROUND0_COL2 = 4'd03;
localparam ROUND0_COL3 = 4'd04;
localparam ROUND_KEY0  = 4'd05;
localparam ROUND_COL0  = 4'd06;
localparam ROUND_COL1  = 4'd07;
localparam ROUND_COL2  = 4'd08;
localparam ROUND_COL3  = 4'd09;
localparam READY       = 4'd10;
localparam GEN_KEY0    = 4'd11;
localparam GEN_KEY1    = 4'd12;
localparam GEN_KEY2    = 4'd13;
localparam GEN_KEY3    = 4'd14;
localparam NOP         = 4'd15;

reg [3:0] state, next_state;
reg [3:0] rd_count;

wire rd_count_en;
wire op_key_derivation;
wire first_round;
wire [1:0] op_mode;
wire enc_dec;

// ---------------------------------------------------------------
// Shared state decode
// ---------------------------------------------------------------
wire s_idle  = (state == IDLE);
wire s_r0c0  = (state == ROUND0_COL0);
wire s_r0c1  = (state == ROUND0_COL1);
wire s_r0c2  = (state == ROUND0_COL2);
wire s_r0c3  = (state == ROUND0_COL3);
wire s_rk0   = (state == ROUND_KEY0);
wire s_rc0   = (state == ROUND_COL0);
wire s_rc1   = (state == ROUND_COL1);
wire s_rc2   = (state == ROUND_COL2);
wire s_rc3   = (state == ROUND_COL3);
wire s_ready = (state == READY);
wire s_gk0   = (state == GEN_KEY0);
wire s_gk1   = (state == GEN_KEY1);
wire s_gk2   = (state == GEN_KEY2);
wire s_gk3   = (state == GEN_KEY3);

wire r0_any  = s_r0c0 | s_r0c1 | s_r0c2 | s_r0c3;
wire rc_any  = s_rc0 | s_rc1 | s_rc2 | s_rc3;
wire gk_any  = s_gk0 | s_gk1 | s_gk2 | s_gk3;

// State Flops
always @(posedge clk, negedge rst_n)
	begin
		if(!rst_n)
			state <= IDLE;
		else
			if(disable_core)
				state <= IDLE;
			else
				state <= next_state;
	end

assign mode_ctr = (aes_mode == CTR);
assign mode_cbc = (aes_mode == CBC);

// op_mode in {ENCRYPTION, KEY_DERIVATION} <=> ctr | ~operation_mode[1]
wire enc_in = mode_ctr | ~operation_mode[1];

assign encrypt_decrypt = enc_in | gk_any;
assign enc_dec = encrypt_decrypt | mode_ctr;
assign key_gen = s_rk0;

assign op_mode = (mode_ctr) ? ENCRYPTION : operation_mode;
assign op_key_derivation = (op_mode == KEY_DERIVATION);

assign key_init = start;

wire not_enc_dec = ~enc_dec;
wire e  = enc_dec;
wire ne = not_enc_dec;
wire lr = last_round;
wire nlr = ~last_round;

wire last_round_and_enc_dec = lr & e;
wire last_round_and_mode_ctr = lr & mode_ctr;
wire last_round_special_case = (lr & mode_cbc & ne) | last_round_and_mode_ctr;
wire nsp = ~last_round_special_case;

// Next State Logic
always @(*)
	begin
		next_state = state;
		case(state)
			IDLE:
				begin
					if(!start)
						next_state = IDLE;
					else
						case(op_mode)
							ENCRYPTION    : next_state = ROUND0_COL0;
							DECRYPTION    : next_state = ROUND0_COL3;
							KEY_DERIVATION: next_state = GEN_KEY0;
							DECRYP_W_DERIV: next_state = GEN_KEY0;
							default       : next_state = IDLE;
						endcase
				end
			ROUND0_COL0:
					next_state = (enc_dec) ? ROUND0_COL1 : ROUND_KEY0; 
			ROUND0_COL1:
					next_state = (enc_dec) ? ROUND0_COL2 : ROUND0_COL0;
			ROUND0_COL2:
					next_state = (enc_dec) ? ROUND0_COL3 : ROUND0_COL1;
			ROUND0_COL3:
					next_state = (enc_dec) ? ROUND_KEY0 : ROUND0_COL2;
			ROUND_KEY0 :
				begin
					if(!first_round)
						next_state = (last_round) ? READY : NOP;
					else
						next_state = (enc_dec) ? ROUND_COL0 : ROUND_COL3;
				end
			NOP        :
					next_state = (enc_dec) ? ROUND_COL0 : ROUND_COL3;
			ROUND_COL0 :
					next_state = (enc_dec) ? ROUND_COL1 : ROUND_KEY0;
			ROUND_COL1 :
					next_state = (enc_dec) ? ROUND_COL2 : ROUND_COL0;
			ROUND_COL2 :
					next_state = (enc_dec) ? ROUND_COL3 : ROUND_COL1;
			ROUND_COL3 :
				begin
					if(last_round_and_enc_dec)
						next_state = READY;
					else
						next_state = (enc_dec) ? ROUND_KEY0 : ROUND_COL2;
				end
			GEN_KEY0   : next_state = GEN_KEY1;
			GEN_KEY1   : next_state = GEN_KEY2;
			GEN_KEY2   : next_state = GEN_KEY3;
			GEN_KEY3   :
				begin
					if(last_round)
						next_state = (op_key_derivation) ? READY : ROUND0_COL3;
					else
						next_state = GEN_KEY0;
				end
			READY      : next_state = IDLE;
		endcase
	end

// Output Logic
assign end_comp = s_ready;

// Shared column-index decodes
wire col1 = s_r0c1 | s_rc1;
wire col2 = s_r0c2 | s_rc2;
wire col3 = s_r0c3 | s_rc3;

// col_en shared "all columns" condition
wire g_all = (s_r0c0 & ne) | (s_r0c3 & e) | (s_rc0 & ne & nlr) | (s_rc3 & e & nlr);

assign rd_count_en = s_rk0 | s_gk0;

always @(*)
	begin
		sbox_sel[0] = col1 | col3;
		sbox_sel[1] = col2 | col3;
		sbox_sel[2] = s_rk0 | s_gk0;

		rk_sel[0] = rc_any & lr;
		rk_sel[1] = rc_any & nlr;

		bypass_rk     = r0_any;
		bypass_key_en = r0_any | s_gk1 | s_gk2 | s_gk3;

		key_out_sel[0] = col1 | col3;
		key_out_sel[1] = col2 | col3;

		col_sel[1] = ~r0_any & ~(rc_any & nsp);
		col_sel[0] = (s_r0c0 & e) | s_r0c1 | s_r0c2 | (s_r0c3 & ne)
		           | (nsp & ((s_rc0 & (e | lr)) | s_rc1 | s_rc2 | (s_rc3 & (ne | lr))));

		key_sel = s_rk0 | rc_any | s_gk1 | s_gk2 | s_gk3
		        | (ne & (s_r0c1 | s_r0c2 | s_r0c3));

		key_en[0] = s_rk0 | s_gk1;
		key_en[1] = (s_r0c1 & ne) | (s_rc0 & e) | (s_rc1 & ne) | s_gk1;
		key_en[2] = (s_r0c2 & ne) | (s_rc1 & e) | (s_rc2 & ne) | s_gk2;
		key_en[3] = (s_r0c3 & ne) | (s_rc2 & e) | (s_rc3 & ne) | s_gk3;

		col_en[0] = g_all | s_r0c0 | s_rc0;
		col_en[1] = g_all | s_r0c1 | s_rc1;
		col_en[2] = g_all | s_r0c2 | s_rc2;
		col_en[3] = g_all | s_r0c3 | s_rc3;

		iv_cnt_en  = s_rc3 & last_round_and_mode_ctr;
		iv_cnt_sel = s_rc3 & last_round_and_mode_ctr;

		key_derivation_en = s_ready & op_key_derivation;
	end

// Round Counter
wire rd_clear = s_idle | (s_gk3 & lr);

always @(posedge clk, negedge rst_n)
	begin
		if(!rst_n)
			rd_count <= INITIAL_ROUND;
		else
			if(rd_clear)
				rd_count <= INITIAL_ROUND;
			else 
				if(rd_count_en)
					rd_count <= rd_count + 1'b1;
	end

assign round = rd_count;
assign first_round = ~(|rd_count);
// rd_count == 10 (1010) or 11 (1011)
assign last_round  = rd_count[3] & ~rd_count[2] & rd_count[1];

endmodule