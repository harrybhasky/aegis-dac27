// file controller.v4.1.v

module control_unit
(
	output reg [ 2:0] sbox_sel,
	output reg [ 1:0] rk_sel,
	output reg [ 1:0] key_out_sel,
	output reg [ 1:0] col_sel,
	output reg [ 3:0] key_en,
	output reg [ 3:0] col_en,
	output     [ 3:0] round,
	output reg bypass_rk,
	output reg bypass_key_en,
	output reg key_sel,
	output reg iv_cnt_en,
	output reg iv_cnt_sel,
	output reg key_derivation_en,
	output end_comp,
	output key_init,
	output key_gen,
	output mode_ctr,
	output mode_cbc,
	output last_round,
  output encrypt_decrypt,	
	input [1:0] operation_mode,
	input [1:0] aes_mode,
	input start,
	input disable_core,
	input clk,
	input rst_n
);

//=============================================================================
// Operation Modes
//=============================================================================
localparam ENCRYPTION     = 2'b00;
localparam KEY_DERIVATION = 2'b01;
localparam DECRYPTION     = 2'b10;
localparam DECRYP_W_DERIV = 2'b11;

//=============================================================================
// AES Modes
//=============================================================================
localparam ECB = 2'b00;
localparam CBC = 2'b01;
localparam CTR = 2'b10;

//=============================================================================
// SBOX SEL
//=============================================================================
localparam COL_0 = 3'b000;
localparam COL_1 = 3'b001;
localparam COL_2 = 3'b010;
localparam COL_3 = 3'b011;
localparam G_FUNCTION = 3'b100;

//=============================================================================
// RK_SEL
//=============================================================================
localparam COL        = 2'b00;
localparam MIXCOL_IN  = 2'b01;
localparam MIXCOL_OUT = 2'b10;

//=============================================================================
// KEY_OUT_SEL
//=============================================================================
localparam KEY_0 = 2'b00;
localparam KEY_1 = 2'b01;
localparam KEY_2 = 2'b10;
localparam KEY_3 = 2'b11;

//=============================================================================
// COL_SEL
//=============================================================================
localparam SHIFT_ROWS = 2'b00;
localparam ADD_RK_OUT = 2'b01;
localparam INPUT      = 2'b10;

//=============================================================================
// KEY_SEL
//=============================================================================
localparam KEY_HOST = 1'b0;
localparam KEY_OUT  = 1'b1;

//=============================================================================
// KEY_EN
//=============================================================================
localparam KEY_DIS  = 4'b0000;
localparam EN_KEY_0 = 4'b0001;
localparam EN_KEY_1 = 4'b0010;
localparam EN_KEY_2 = 4'b0100;
localparam EN_KEY_3 = 4'b1000;
localparam KEY_ALL  = 4'b1111;

//=============================================================================
// COL_EN
//=============================================================================
localparam COL_DIS  = 4'b0000;
localparam EN_COL_0 = 4'b0001;
localparam EN_COL_1 = 4'b0010;
localparam EN_COL_2 = 4'b0100;
localparam EN_COL_3 = 4'b1000;
localparam COL_ALL  = 4'b1111;

//=============================================================================
// IV_CNT_SEL
//=============================================================================
localparam IV_CNT = 1'b1;
localparam IV_BUS = 1'b0;

//=============================================================================
// ENABLES
//=============================================================================
localparam ENABLE = 1'b1;
localparam DISABLE = 1'b0;

localparam NUMBER_ROUND      = 4'd10;
localparam NUMBER_ROUND_INC  = 4'd11;
localparam INITIAL_ROUND     = 4'd00;

//=============================================================================
// FSM STATES
//=============================================================================
localparam IDLE        = 4'd00;
localparam ROUND0_COL0 = 4'd01;
localparam ROUND0_COL1 = 4'd02;
localparam ROUND0_COL2 = 4'd03;
localparam ROUND0_COL3 = 4'd04;
localparam ROUND_KEY0  = 4'd05;
localparam ROUND_COL0  = 4'd06;
localparam ROUND_COL1  = 4'd07;
localparam ROUND_COL2  = 4'd08;
localparam ROUND_COL3  = 4'd09;
localparam READY       = 4'd10;
localparam GEN_KEY0    = 4'd11;
localparam GEN_KEY1    = 4'd12;
localparam GEN_KEY2    = 4'd13;
localparam GEN_KEY3    = 4'd14;
localparam NOP         = 4'd15;

reg [3:0] state, next_state;
reg [3:0] rd_count;

wire rd_count_en;
wire op_key_derivation;
wire first_round;
wire [1:0] op_mode;
wire enc_dec;

wire last_round_and_mode_cbc_and_not_enc_dec;
wire last_round_and_mode_ctr;
wire last_round_special_case;
wire last_round_and_enc_dec;
wire not_last_round_and_enc_dec;
wire not_enc_dec;
wire not_last_round;

// State Flops Definition
always @(posedge clk, negedge rst_n)
	begin
		if(!rst_n)
			state <= IDLE;
		else
			if(disable_core)
				state <= IDLE;
			else
				state <= next_state;
	end

//=============================================================================
// One-hot pre-decode of state
//=============================================================================
wire state_is_idle        = (state == IDLE);
wire state_is_round0_col0 = (state == ROUND0_COL0);
wire state_is_round0_col1 = (state == ROUND0_COL1);
wire state_is_round0_col2 = (state == ROUND0_COL2);
wire state_is_round0_col3 = (state == ROUND0_COL3);
wire state_is_round_key0  = (state == ROUND_KEY0);
wire state_is_round_col0  = (state == ROUND_COL0);
wire state_is_round_col1  = (state == ROUND_COL1);
wire state_is_round_col2  = (state == ROUND_COL2);
wire state_is_round_col3  = (state == ROUND_COL3);
wire state_is_ready       = (state == READY);
wire state_is_gen_key0    = (state == GEN_KEY0);
wire state_is_gen_key1    = (state == GEN_KEY1);
wire state_is_gen_key2    = (state == GEN_KEY2);
wire state_is_gen_key3    = (state == GEN_KEY3);
wire state_is_nop         = (state == NOP);

assign mode_ctr = (aes_mode == CTR);
assign mode_cbc = (aes_mode == CBC);

assign op_mode = (mode_ctr) ? ENCRYPTION : operation_mode;

assign encrypt_decrypt = (op_mode == ENCRYPTION || op_mode == KEY_DERIVATION || state == GEN_KEY0   
			  ||   state == GEN_KEY1       ||state == GEN_KEY2   ||   state == GEN_KEY3       );

// enc_dec computed directly from inputs. The GEN_KEY state term of the original
// is dropped: next_state and outputs never use enc_dec in GEN_KEY states.
assign enc_dec = (~operation_mode[1]) | mode_ctr;

assign key_gen = state_is_round_key0;

assign op_key_derivation = (op_mode == KEY_DERIVATION);

assign key_init = start;

assign not_enc_dec = ~enc_dec;
assign not_last_round = ~last_round;
assign last_round_and_enc_dec = last_round & enc_dec;
assign not_last_round_and_enc_dec = not_last_round & enc_dec;
assign last_round_and_mode_cbc_and_not_enc_dec = last_round & mode_cbc & not_enc_dec;
assign last_round_and_mode_ctr = last_round & mode_ctr;
assign last_round_special_case = last_round_and_mode_cbc_and_not_enc_dec | last_round_and_mode_ctr;

//=============================================================================
// Next State Logic (flat AND-OR over one-hot state; all 16 states covered)
//=============================================================================
wire [3:0] ns_idle = !start ? IDLE :
                     (op_mode == ENCRYPTION)     ? ROUND0_COL0 :
                     (op_mode == DECRYPTION)     ? ROUND0_COL3 :
                                                   GEN_KEY0;
wire [3:0] ns_r0c0 = enc_dec ? ROUND0_COL1 : ROUND_KEY0;
wire [3:0] ns_r0c1 = enc_dec ? ROUND0_COL2 : ROUND0_COL0;
wire [3:0] ns_r0c2 = enc_dec ? ROUND0_COL3 : ROUND0_COL1;
wire [3:0] ns_r0c3 = enc_dec ? ROUND_KEY0  : ROUND0_COL2;
wire [3:0] ns_rk0  = !first_round ? (last_round ? READY : NOP) :
                                    (enc_dec ? ROUND_COL0 : ROUND_COL3);
wire [3:0] ns_nop  = enc_dec ? ROUND_COL0 : ROUND_COL3;
wire [3:0] ns_rc0  = enc_dec ? ROUND_COL1 : ROUND_KEY0;
wire [3:0] ns_rc1  = enc_dec ? ROUND_COL2 : ROUND_COL0;
wire [3:0] ns_rc2  = enc_dec ? ROUND_COL3 : ROUND_COL1;
wire [3:0] ns_rc3  = last_round_and_enc_dec ? READY :
                     (enc_dec ? ROUND_KEY0 : ROUND_COL2);
wire [3:0] ns_gk3  = last_round ? (op_key_derivation ? READY : ROUND0_COL3) : GEN_KEY0;

always @(*)
	begin
		next_state = ({4{state_is_idle}}        & ns_idle)
		           | ({4{state_is_round0_col0}} & ns_r0c0)
		           | ({4{state_is_round0_col1}} & ns_r0c1)
		           | ({4{state_is_round0_col2}} & ns_r0c2)
		           | ({4{state_is_round0_col3}} & ns_r0c3)
		           | ({4{state_is_round_key0}}  & ns_rk0)
		           | ({4{state_is_nop}}         & ns_nop)
		           | ({4{state_is_round_col0}}  & ns_rc0)
		           | ({4{state_is_round_col1}}  & ns_rc1)
		           | ({4{state_is_round_col2}}  & ns_rc2)
		           | ({4{state_is_round_col3}}  & ns_rc3)
		           | ({4{state_is_gen_key0}}    & GEN_KEY1)
		           | ({4{state_is_gen_key1}}    & GEN_KEY2)
		           | ({4{state_is_gen_key2}}    & GEN_KEY3)
		           | ({4{state_is_gen_key3}}    & ns_gk3);
		// READY -> IDLE (4'd0): contributes nothing to the OR
	end

// Output Logic
assign end_comp = state_is_ready;

assign rd_count_en = state_is_round_key0 | state_is_gen_key0;

always @(*)
	begin
		sbox_sel = COL_0;
		rk_sel = COL;
		bypass_rk = DISABLE;
		key_out_sel = KEY_0;
		col_sel = INPUT;
		key_sel = KEY_HOST;
		key_en = KEY_DIS;
		col_en = COL_DIS;
		iv_cnt_en = DISABLE;
		iv_cnt_sel = IV_BUS;
		bypass_key_en = DISABLE;
		key_derivation_en = DISABLE;
		case(state)
			ROUND0_COL0:
				begin
					sbox_sel = COL_0;
					rk_sel   = COL;
					bypass_rk = ENABLE;
					bypass_key_en = ENABLE;
					key_out_sel = KEY_0;
					col_sel = (enc_dec) ? ADD_RK_OUT : SHIFT_ROWS;
					col_en =  (enc_dec) ? EN_COL_0 : COL_ALL;
				end
			ROUND0_COL1:
				begin
					sbox_sel = COL_1;
					rk_sel   = COL;
					bypass_rk = ENABLE;
					bypass_key_en = ENABLE;
					key_out_sel = KEY_1;
					col_sel = ADD_RK_OUT;
					col_en = EN_COL_1;
					if(!enc_dec)
						begin
							key_sel = KEY_OUT;
							key_en =  EN_KEY_1;
						end
				end
			ROUND0_COL2:
				begin
					sbox_sel = COL_2;
					rk_sel   = COL;
					bypass_rk = ENABLE;
					bypass_key_en = ENABLE;
					key_out_sel = KEY_2;
					col_sel = ADD_RK_OUT;
					col_en = EN_COL_2;
					if(!enc_dec)
						begin
							key_sel = KEY_OUT;
							key_en =  EN_KEY_2;
						end
				end
			ROUND0_COL3:
				begin
					sbox_sel = COL_3;
					rk_sel   = COL;
					bypass_key_en = ENABLE;
					key_out_sel = KEY_3;
					col_sel = (enc_dec) ? SHIFT_ROWS : ADD_RK_OUT;
					col_en =  (enc_dec) ? COL_ALL : EN_COL_3;
					bypass_rk = ENABLE;
					if(!enc_dec)
					begin
							key_sel = KEY_OUT;
							key_en =  EN_KEY_3;
					end
				end
			ROUND_KEY0:
				begin
					sbox_sel = G_FUNCTION;
					key_sel = KEY_OUT;
					key_en = EN_KEY_0;
				end
			ROUND_COL0:
				begin
					sbox_sel = COL_0;
					rk_sel = (last_round) ? MIXCOL_IN : MIXCOL_OUT;
					key_out_sel = KEY_0;
					key_sel = KEY_OUT;

					if(enc_dec)
						key_en = EN_KEY_1;
					if(last_round_special_case)
						col_sel = INPUT;
					else
						begin
							if(not_enc_dec)
								col_sel = (last_round) ? ADD_RK_OUT : SHIFT_ROWS;
							else
								col_sel = ADD_RK_OUT;
						end
					if(enc_dec)
						col_en = EN_COL_0;
					else
						col_en = (last_round) ? EN_COL_0 : COL_ALL;
				end
			ROUND_COL1:
				begin
					sbox_sel = COL_1;
					rk_sel   = (last_round) ? MIXCOL_IN : MIXCOL_OUT;
					key_out_sel = KEY_1;
					key_sel = KEY_OUT;
					if(enc_dec)
						key_en = EN_KEY_2;
					else
						key_en = EN_KEY_1;
					if(last_round_special_case)
						col_sel = INPUT;
					else
						col_sel = ADD_RK_OUT;
					col_en = EN_COL_1;
				end
			ROUND_COL2:
				begin
					sbox_sel = COL_2;
					rk_sel   = (last_round) ? MIXCOL_IN : MIXCOL_OUT;
					key_out_sel = KEY_2;
					key_sel = KEY_OUT;
					if(enc_dec)
						key_en = EN_KEY_3;
					else
						key_en = EN_KEY_2;
					if(last_round_special_case)
						col_sel = INPUT;
					else
						col_sel = ADD_RK_OUT;
					col_en = EN_COL_2;
				end
			ROUND_COL3:
				begin
					sbox_sel = COL_3;
					rk_sel   = (last_round) ? MIXCOL_IN : MIXCOL_OUT;
					key_out_sel = KEY_3;
					key_sel = KEY_OUT;
					if(not_enc_dec)
						key_en = EN_KEY_3;
					if(last_round_special_case)
						col_sel = INPUT;
					else
						begin
							if(enc_dec)
								col_sel = (last_round) ? ADD_RK_OUT : SHIFT_ROWS;
							else
								col_sel = ADD_RK_OUT;
						end
					if(enc_dec)
						col_en = (last_round) ? EN_COL_3 : COL_ALL;
					else
						col_en = EN_COL_3;
					if(last_round_and_mode_ctr)
						begin
							iv_cnt_en = ENABLE;
							iv_cnt_sel = IV_CNT;
						end
				end
			GEN_KEY0:
				begin
					sbox_sel = G_FUNCTION;
				end
			GEN_KEY1:
				begin
					key_en = EN_KEY_1 | EN_KEY_0; //Enable key 0 AND key 1
					key_sel = KEY_OUT;
					bypass_key_en = ENABLE;
				end
			GEN_KEY2:
				begin
					key_en = EN_KEY_2;
					key_sel = KEY_OUT;
					bypass_key_en = ENABLE;
				end
			GEN_KEY3:
				begin
					key_en = EN_KEY_3;
					key_sel = KEY_OUT;
					bypass_key_en = ENABLE;
				end
			READY:
				begin
					if(op_mode == KEY_DERIVATION)
						key_derivation_en = ENABLE;
				end
		endcase
	end

// Round Counter
wire rd_count_clr = state_is_idle | (state_is_gen_key3 & last_round);

always @(posedge clk, negedge rst_n)
	begin
		if(!rst_n)
			rd_count <= INITIAL_ROUND;
		else
			if(rd_count_clr)
				rd_count <= INITIAL_ROUND;
			else 
				if(rd_count_en)
					rd_count <= rd_count + 1'b1;
	end

assign round = rd_count;
assign first_round = (rd_count == INITIAL_ROUND);
// rd_count == 10 (1010) or 11 (1011)
assign last_round  = rd_count[3] & ~rd_count[2] & rd_count[1];

endmodule