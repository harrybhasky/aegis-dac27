// file controller.v0.5.v

module control_unit
(
	output reg [ 2:0] sbox_sel,
	output reg [ 1:0] rk_sel,
	output reg [ 1:0] key_out_sel,
	output reg [ 1:0] col_sel,
	output reg [ 3:0] key_en,
	output reg [ 3:0] col_en,
	output     [ 3:0] round,
	output reg bypass_rk,
	output reg bypass_key_en,
	output reg key_sel,
	output reg iv_cnt_en,
	output reg iv_cnt_sel,
	output reg key_derivation_en,
	output end_comp,
	output key_init,
	output key_gen,
	output mode_ctr,
	output mode_cbc,
	output last_round,
  output encrypt_decrypt,	
	input [1:0] operation_mode,
	input [1:0] aes_mode,
	input start,
	input disable_core,
	input clk,
	input rst_n
);

localparam ENCRYPTION     = 2'b00;
localparam KEY_DERIVATION = 2'b01;
localparam DECRYPTION     = 2'b10;
localparam DECRYP_W_DERIV = 2'b11;

localparam ECB = 2'b00;
localparam CBC = 2'b01;
localparam CTR = 2'b10;

localparam COL_0 = 3'b000;
localparam COL_1 = 3'b001;
localparam COL_2 = 3'b010;
localparam COL_3 = 3'b011;
localparam G_FUNCTION = 3'b100;

localparam COL        = 2'b00;
localparam MIXCOL_IN  = 2'b01;
localparam MIXCOL_OUT = 2'b10;

localparam KEY_0 = 2'b00;
localparam KEY_1 = 2'b01;
localparam KEY_2 = 2'b10;
localparam KEY_3 = 2'b11;

localparam SHIFT_ROWS = 2'b00;
localparam ADD_RK_OUT = 2'b01;
localparam INPUT      = 2'b10;

localparam KEY_HOST = 1'b0;
localparam KEY_OUT  = 1'b1;

localparam KEY_DIS  = 4'b0000;
localparam EN_KEY_0 = 4'b0001;
localparam EN_KEY_1 = 4'b0010;
localparam EN_KEY_2 = 4'b0100;
localparam EN_KEY_3 = 4'b1000;
localparam KEY_ALL  = 4'b1111;

localparam COL_DIS  = 4'b0000;
localparam EN_COL_0 = 4'b0001;
localparam EN_COL_1 = 4'b0010;
localparam EN_COL_2 = 4'b0100;
localparam EN_COL_3 = 4'b1000;
localparam COL_ALL  = 4'b1111;

localparam IV_CNT = 1'b1;
localparam IV_BUS = 1'b0;

localparam ENABLE = 1'b1;
localparam DISABLE = 1'b0;

localparam NUMBER_ROUND      = 4'd10;
localparam NUMBER_ROUND_INC  = 4'd11;
localparam INITIAL_ROUND     = 4'd00;

localparam IDLE        = 4'd00;
localparam ROUND0_COL0 = 4'd01;
localparam ROUND0_COL1 = 4'd02;
localparam ROUND0_COL2 = 4'd03;
localparam ROUND0_COL3 = 4'd04;
localparam ROUND_KEY0  = 4'd05;
localparam ROUND_COL0  = 4'd06;
localparam ROUND_COL1  = 4'd07;
localparam ROUND_COL2  = 4'd08;
localparam ROUND_COL3  = 4'd09;
localparam READY       = 4'd10;
localparam GEN_KEY0    = 4'd11;
localparam GEN_KEY1    = 4'd12;
localparam GEN_KEY2    = 4'd13;
localparam GEN_KEY3    = 4'd14;
localparam NOP         = 4'd15;

reg [3:0] state, next_state;
reg [3:0] rd_count;

wire rd_count_en;
wire rd_count_clr;
wire op_key_derivation;
wire first_round;
wire [1:0] op_mode;
wire enc_dec;

wire last_round_and_mode_cbc_and_not_enc_dec;
wire last_round_and_mode_ctr;
wire last_round_special_case;
wire last_round_and_enc_dec;
wire not_last_round_and_enc_dec;
wire not_enc_dec;
wire not_last_round;

// Predecoded state wires
wire s_idle = (state == IDLE);
wire s_r0c0 = (state == ROUND0_COL0);
wire s_r0c1 = (state == ROUND0_COL1);
wire s_r0c2 = (state == ROUND0_COL2);
wire s_r0c3 = (state == ROUND0_COL3);
wire s_rk0  = (state == ROUND_KEY0);
wire s_rc0  = (state == ROUND_COL0);
wire s_rc1  = (state == ROUND_COL1);
wire s_rc2  = (state == ROUND_COL2);
wire s_rc3  = (state == ROUND_COL3);
wire s_rdy  = (state == READY);
wire s_gk0  = (state == GEN_KEY0);
wire s_gk1  = (state == GEN_KEY1);
wire s_gk2  = (state == GEN_KEY2);
wire s_gk3  = (state == GEN_KEY3);

// State Flops Definition
always @(posedge clk, negedge rst_n)
	begin
		if(!rst_n)
			state <= IDLE;
		else
			if(disable_core)
				state <= IDLE;
			else
				state <= next_state;
	end

assign mode_ctr = (aes_mode == CTR);
assign mode_cbc = (aes_mode == CBC);

assign op_mode = (mode_ctr) ? ENCRYPTION : operation_mode;

// op_mode is ENCRYPTION or KEY_DERIVATION iff op_mode[1] == 0
assign encrypt_decrypt = ~op_mode[1] | s_gk0 | s_gk1 | s_gk2 | s_gk3;

assign enc_dec = encrypt_decrypt | mode_ctr;
assign key_gen = s_rk0;

assign op_key_derivation = (op_mode == KEY_DERIVATION);

assign key_init = start;

assign not_enc_dec = ~enc_dec;
assign not_last_round = ~last_round;
assign last_round_and_enc_dec = last_round & enc_dec;
assign not_last_round_and_enc_dec = not_last_round & enc_dec;
assign last_round_and_mode_cbc_and_not_enc_dec = last_round & mode_cbc & not_enc_dec;
assign last_round_and_mode_ctr = last_round & mode_ctr;
assign last_round_special_case = last_round_and_mode_cbc_and_not_enc_dec | last_round_and_mode_ctr;

// Next State Logic
always @(*)
	begin
		next_state = state;
		case(state)
			IDLE:
				begin
					if(!start)
						next_state = IDLE;
					else
						case(op_mode)
							ENCRYPTION    : next_state = ROUND0_COL0;
							DECRYPTION    : next_state = ROUND0_COL3;
							KEY_DERIVATION: next_state = GEN_KEY0;
							DECRYP_W_DERIV: next_state = GEN_KEY0;
							default       : next_state = IDLE;
						endcase
				end
			ROUND0_COL0:
				next_state = (enc_dec) ? ROUND0_COL1 : ROUND_KEY0; 
			ROUND0_COL1:
				next_state = (enc_dec) ? ROUND0_COL2 : ROUND0_COL0;
			ROUND0_COL2:
				next_state = (enc_dec) ? ROUND0_COL3 : ROUND0_COL1;
			ROUND0_COL3:
				next_state = (enc_dec) ? ROUND_KEY0 : ROUND0_COL2;
			ROUND_KEY0 :
				begin
					if(!first_round)
						next_state = (last_round) ? READY : NOP;
					else
						next_state = (enc_dec) ? ROUND_COL0 : ROUND_COL3;
				end
			NOP        :
				next_state = (enc_dec) ? ROUND_COL0 : ROUND_COL3;
			ROUND_COL0 :
				next_state = (enc_dec) ? ROUND_COL1 : ROUND_KEY0;
			ROUND_COL1 :
				next_state = (enc_dec) ? ROUND_COL2 : ROUND_COL0;
			ROUND_COL2 :
				next_state = (enc_dec) ? ROUND_COL3 : ROUND_COL1;
			ROUND_COL3 :
				begin
					if(last_round_and_enc_dec)
						next_state = READY;
					else
						next_state = (enc_dec) ? ROUND_KEY0 : ROUND_COL2;
				end
			GEN_KEY0   :
				next_state = GEN_KEY1;
			GEN_KEY1   :
				next_state = GEN_KEY2;
			GEN_KEY2   :
				next_state = GEN_KEY3;
			GEN_KEY3   :
				begin
					if(last_round)
						next_state = (op_key_derivation) ? READY : ROUND0_COL3;
					else
						next_state = GEN_KEY0;
				end
			READY      :
				next_state = IDLE;
		endcase
	end

// Output Logic
assign end_comp = s_rdy;

// Flat decodes for pure state-to-output maps
wire sbox2_w = s_rk0 | s_gk0;
wire sel1_w  = s_r0c2 | s_r0c3 | s_rc2 | s_rc3;
wire sel0_w  = s_r0c1 | s_r0c3 | s_rc1 | s_rc3;
wire key_sel_w = (not_enc_dec & (s_r0c1 | s_r0c2 | s_r0c3))
               | s_rk0 | s_rc0 | s_rc1 | s_rc2 | s_rc3
               | s_gk1 | s_gk2 | s_gk3;

assign rd_count_en  = s_rk0 | s_gk0;
assign rd_count_clr = s_idle | (s_gk3 & last_round);

always @(*)
	begin
		sbox_sel = {sbox2_w, sel1_w, sel0_w};
		key_out_sel = {sel1_w, sel0_w};
		key_sel = key_sel_w;
		rk_sel = COL;
		bypass_rk = DISABLE;
		col_sel = INPUT;
		key_en = KEY_DIS;
		col_en = COL_DIS;
		iv_cnt_en = DISABLE;
		iv_cnt_sel = IV_BUS;
		bypass_key_en = DISABLE;
		key_derivation_en = DISABLE;
		case(state)
			ROUND0_COL0:
				begin
					rk_sel   = COL;
					bypass_rk = ENABLE;
					bypass_key_en = ENABLE;
					col_sel = (enc_dec) ? ADD_RK_OUT : SHIFT_ROWS;
					col_en =  (enc_dec) ? EN_COL_0 : COL_ALL;
				end
			ROUND0_COL1:
				begin
					bypass_rk = ENABLE;
					bypass_key_en = ENABLE;
					col_sel = ADD_RK_OUT;
					col_en = EN_COL_1;
					if(!enc_dec)
						key_en =  EN_KEY_1;
				end
			ROUND0_COL2:
				begin
					bypass_rk = ENABLE;
					bypass_key_en = ENABLE;
					col_sel = ADD_RK_OUT;
					col_en = EN_COL_2;
					if(!enc_dec)
						key_en =  EN_KEY_2;
				end
			ROUND0_COL3:
				begin
					bypass_key_en = ENABLE;
					col_sel = (enc_dec) ? SHIFT_ROWS : ADD_RK_OUT;
					col_en =  (enc_dec) ? COL_ALL : EN_COL_3;
					bypass_rk = ENABLE;
					if(!enc_dec)
						key_en =  EN_KEY_3;
				end
			ROUND_KEY0:
				begin
					key_en = EN_KEY_0;
				end
			ROUND_COL0:
				begin
					rk_sel = (last_round) ? MIXCOL_IN : MIXCOL_OUT;
					if(enc_dec)
						key_en = EN_KEY_1;
					if(last_round_special_case)
						col_sel = INPUT;
					else
						begin
							if(not_enc_dec)
								col_sel = (last_round) ? ADD_RK_OUT : SHIFT_ROWS;
							else
								col_sel = ADD_RK_OUT;
						end
					if(enc_dec)
						col_en = EN_COL_0;
					else
						col_en = (last_round) ? EN_COL_0 : COL_ALL;
				end
			ROUND_COL1:
				begin
					rk_sel   = (last_round) ? MIXCOL_IN : MIXCOL_OUT;
					if(enc_dec)
						key_en = EN_KEY_2;
					else
						key_en = EN_KEY_1;
					if(last_round_special_case)
						col_sel = INPUT;
					else
						col_sel = ADD_RK_OUT;
					col_en = EN_COL_1;
				end
			ROUND_COL2:
				begin
					rk_sel   = (last_round) ? MIXCOL_IN : MIXCOL_OUT;
					if(enc_dec)
						key_en = EN_KEY_3;
					else
						key_en = EN_KEY_2;
					if(last_round_special_case)
						col_sel = INPUT;
					else
						col_sel = ADD_RK_OUT;
					col_en = EN_COL_2;
				end
			ROUND_COL3:
				begin
					rk_sel   = (last_round) ? MIXCOL_IN : MIXCOL_OUT;
					if(not_enc_dec)
						key_en = EN_KEY_3;
					if(last_round_special_case)
						col_sel = INPUT;
					else
						begin
							if(enc_dec)
								col_sel = (last_round) ? ADD_RK_OUT : SHIFT_ROWS;
							else
								col_sel = ADD_RK_OUT;
						end
					if(enc_dec)
						col_en = (last_round) ? EN_COL_3 : COL_ALL;
					else
						col_en = EN_COL_3;
					if(last_round_and_mode_ctr)
						begin
							iv_cnt_en = ENABLE;
							iv_cnt_sel = IV_CNT;
						end
				end
			GEN_KEY1:
				begin
					key_en = EN_KEY_1 | EN_KEY_0;
					bypass_key_en = ENABLE;
				end
			GEN_KEY2:
				begin
					key_en = EN_KEY_2;
					bypass_key_en = ENABLE;
				end
			GEN_KEY3:
				begin
					key_en = EN_KEY_3;
					bypass_key_en = ENABLE;
				end
			READY:
				begin
					if(op_mode == KEY_DERIVATION)
						key_derivation_en = ENABLE;
				end
			default: ;
		endcase
	end

// Round Counter
always @(posedge clk, negedge rst_n)
	begin
		if(!rst_n)
			rd_count <= INITIAL_ROUND;
		else
			if(rd_count_clr)
				rd_count <= INITIAL_ROUND;
			else 
				if(rd_count_en)
					rd_count <= rd_count + 1'b1;
	end

assign round = rd_count;
assign first_round = ~(|rd_count);
// rd_count == 10 (1010) or 11 (1011)
assign last_round  = rd_count[3] & ~rd_count[2] & rd_count[1];

endmodule