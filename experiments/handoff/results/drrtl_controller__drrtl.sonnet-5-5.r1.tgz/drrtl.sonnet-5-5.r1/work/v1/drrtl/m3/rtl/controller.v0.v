// file controller.v0.3.v

module control_unit
(
	output reg [ 2:0] sbox_sel,
	output reg [ 1:0] rk_sel,
	output reg [ 1:0] key_out_sel,
	output reg [ 1:0] col_sel,
	output reg [ 3:0] key_en,
	output reg [ 3:0] col_en,
	output     [ 3:0] round,
	output reg bypass_rk,
	output reg bypass_key_en,
	output reg key_sel,
	output reg iv_cnt_en,
	output reg iv_cnt_sel,
	output reg key_derivation_en,
	output end_comp,
	output key_init,
	output key_gen,
	output mode_ctr,
	output mode_cbc,
	output last_round,
  output encrypt_decrypt,	
	input [1:0] operation_mode,
	input [1:0] aes_mode,
	input start,
	input disable_core,
	input clk,
	input rst_n
);

//=============================================================================
// Operation Modes
//=============================================================================
localparam ENCRYPTION     = 2'b00;
localparam KEY_DERIVATION = 2'b01;
localparam DECRYPTION     = 2'b10;
localparam DECRYP_W_DERIV = 2'b11;

//=============================================================================
// AES Modes
//=============================================================================
localparam ECB = 2'b00;
localparam CBC = 2'b01;
localparam CTR = 2'b10;

//=============================================================================
// SBOX SEL
//=============================================================================
localparam COL_0 = 3'b000;
localparam COL_1 = 3'b001;
localparam COL_2 = 3'b010;
localparam COL_3 = 3'b011;
localparam G_FUNCTION = 3'b100;

//=============================================================================
// RK_SEL
//=============================================================================
localparam COL        = 2'b00;
localparam MIXCOL_IN  = 2'b01;
localparam MIXCOL_OUT = 2'b10;

//=============================================================================
// KEY_OUT_SEL
//=============================================================================
localparam KEY_0 = 2'b00;
localparam KEY_1 = 2'b01;
localparam KEY_2 = 2'b10;
localparam KEY_3 = 2'b11;

//=============================================================================
// IV_CNT_SEL
//=============================================================================
localparam IV_CNT = 1'b1;
localparam IV_BUS = 1'b0;

//=============================================================================
// ENABLES
//=============================================================================
localparam ENABLE = 1'b1;
localparam DISABLE = 1'b0;

localparam NUMBER_ROUND      = 4'd10;
localparam NUMBER_ROUND_INC  = 4'd11;
localparam INITIAL_ROUND     = 4'd00;

//=============================================================================
// FSM STATES
//=============================================================================
localparam IDLE        = 4'd00;
localparam ROUND0_COL0 = 4'd01;
localparam ROUND0_COL1 = 4'd02;
localparam ROUND0_COL2 = 4'd03;
localparam ROUND0_COL3 = 4'd04;
localparam ROUND_KEY0  = 4'd05;
localparam ROUND_COL0  = 4'd06;
localparam ROUND_COL1  = 4'd07;
localparam ROUND_COL2  = 4'd08;
localparam ROUND_COL3  = 4'd09;
localparam READY       = 4'd10;
localparam GEN_KEY0    = 4'd11;
localparam GEN_KEY1    = 4'd12;
localparam GEN_KEY2    = 4'd13;
localparam GEN_KEY3    = 4'd14;
localparam NOP         = 4'd15;

reg [3:0] state, next_state;
reg [3:0] rd_count;

reg rd_count_en;
wire op_key_derivation;
wire first_round;
wire [1:0] op_mode;
wire enc_dec;
wire not_enc_dec;

// Shared one-hot state decode
wire state_is_idle = (state == IDLE);
wire state_is_r0c0 = (state == ROUND0_COL0);
wire state_is_r0c1 = (state == ROUND0_COL1);
wire state_is_r0c2 = (state == ROUND0_COL2);
wire state_is_r0c3 = (state == ROUND0_COL3);
wire state_is_rk0  = (state == ROUND_KEY0);
wire state_is_rc0  = (state == ROUND_COL0);
wire state_is_rc1  = (state == ROUND_COL1);
wire state_is_rc2  = (state == ROUND_COL2);
wire state_is_rc3  = (state == ROUND_COL3);
wire state_is_ready= (state == READY);
wire state_is_gk0  = (state == GEN_KEY0);
wire state_is_gk1  = (state == GEN_KEY1);
wire state_is_gk2  = (state == GEN_KEY2);
wire state_is_gk3  = (state == GEN_KEY3);

wire gen_key_any = state_is_gk0 | state_is_gk1 | state_is_gk2 | state_is_gk3;

wire not_last_round = ~last_round;
wire last_round_and_enc_dec;
wire last_round_and_mode_ctr;
wire last_round_special_case;

// State Flops Definition
always @(posedge clk, negedge rst_n)
	begin
		if(!rst_n)
			state <= IDLE;
		else
			if(disable_core)
				state <= IDLE;
			else
				state <= next_state;
	end

// op_mode is ENCRYPTION or KEY_DERIVATION  <=>  mode_ctr | ~operation_mode[1]
assign encrypt_decrypt = mode_ctr | ~operation_mode[1] | gen_key_any;

// encrypt_decrypt already contains mode_ctr
assign enc_dec = encrypt_decrypt;
assign not_enc_dec = ~enc_dec;
assign key_gen = state_is_rk0;

assign op_key_derivation = (op_mode == KEY_DERIVATION);

assign mode_ctr = (aes_mode == CTR);
assign mode_cbc = (aes_mode == CBC);

assign key_init = start;

assign last_round_and_enc_dec = last_round & enc_dec;
assign last_round_and_mode_ctr = last_round & mode_ctr;
assign last_round_special_case = (last_round & mode_cbc & not_enc_dec) | last_round_and_mode_ctr;

assign op_mode = (mode_ctr) ? ENCRYPTION : operation_mode;

// Next State Logic
always @(*)
	begin
		next_state = state;
		case(state)
			IDLE:
				begin
					if(!start)
						next_state = IDLE;
					else
						case(op_mode)
							ENCRYPTION    : next_state = ROUND0_COL0;
							DECRYPTION    : next_state = ROUND0_COL3;
							KEY_DERIVATION: next_state = GEN_KEY0;
							DECRYP_W_DERIV: next_state = GEN_KEY0;
							default       : next_state = IDLE;
						endcase
				end
			ROUND0_COL0:
					next_state = (enc_dec) ? ROUND0_COL1 : ROUND_KEY0; 
			ROUND0_COL1:
					next_state = (enc_dec) ? ROUND0_COL2 : ROUND0_COL0;
			ROUND0_COL2:
					next_state = (enc_dec) ? ROUND0_COL3 : ROUND0_COL1;
			ROUND0_COL3:
					next_state = (enc_dec) ? ROUND_KEY0 : ROUND0_COL2;
			ROUND_KEY0 :
				begin
					if(!first_round)
						next_state = (last_round) ? READY : NOP;
					else
						next_state = (enc_dec) ? ROUND_COL0 : ROUND_COL3;
				end
			NOP        :
					next_state = (enc_dec) ? ROUND_COL0 : ROUND_COL3;
			ROUND_COL0 :
					next_state = (enc_dec) ? ROUND_COL1 : ROUND_KEY0;
			ROUND_COL1 :
					next_state = (enc_dec) ? ROUND_COL2 : ROUND_COL0;
			ROUND_COL2 :
					next_state = (enc_dec) ? ROUND_COL3 : ROUND_COL1;
			ROUND_COL3 :
				begin
					if(last_round_and_enc_dec)
						next_state = READY;
					else
						next_state = (enc_dec) ? ROUND_KEY0 : ROUND_COL2;
				end
			GEN_KEY0   :
					next_state = GEN_KEY1;
			GEN_KEY1   :
					next_state = GEN_KEY2;
			GEN_KEY2   :
					next_state = GEN_KEY3;
			GEN_KEY3   :
				begin
					if(last_round)
						next_state = (op_key_derivation) ? READY : ROUND0_COL3;
					else
						next_state = GEN_KEY0;
				end
			READY      :
					next_state = IDLE;
		endcase
	end

// Output Logic
assign end_comp = state_is_ready;

// Flat equations for key_sel / key_en / col_en / col_sel
wire r0_any = state_is_r0c1 | state_is_r0c2 | state_is_r0c3;
wire rc_any = state_is_rc0 | state_is_rc1 | state_is_rc2 | state_is_rc3;
wire rc_not_last_ne = state_is_rc0 & not_enc_dec & not_last_round;
wire rc3_enc_not_last = state_is_rc3 & enc_dec & not_last_round;
wire rc_nospecial = ~last_round_special_case;

always @(*)
	begin
		key_sel = state_is_rk0 | rc_any | state_is_gk1 | state_is_gk2 | state_is_gk3
		          | (not_enc_dec & r0_any);

		key_en[0] = state_is_rk0 | state_is_gk1;
		key_en[1] = (state_is_r0c1 & not_enc_dec) | (state_is_rc0 & enc_dec)
		          | (state_is_rc1 & not_enc_dec) | state_is_gk1;
		key_en[2] = (state_is_r0c2 & not_enc_dec) | (state_is_rc1 & enc_dec)
		          | (state_is_rc2 & not_enc_dec) | state_is_gk2;
		key_en[3] = (state_is_r0c3 & not_enc_dec) | (state_is_rc2 & enc_dec)
		          | (state_is_rc3 & not_enc_dec) | state_is_gk3;

		col_en[0] = state_is_r0c0 | state_is_rc0 | (state_is_r0c3 & enc_dec) | rc3_enc_not_last;
		col_en[1] = (state_is_r0c0 & not_enc_dec) | state_is_r0c1 | (state_is_r0c3 & enc_dec)
		          | rc_not_last_ne | state_is_rc1 | rc3_enc_not_last;
		col_en[2] = (state_is_r0c0 & not_enc_dec) | state_is_r0c2 | (state_is_r0c3 & enc_dec)
		          | rc_not_last_ne | state_is_rc2 | rc3_enc_not_last;
		col_en[3] = (state_is_r0c0 & not_enc_dec) | state_is_r0c3
		          | rc_not_last_ne | state_is_rc3;

		// INPUT=10, ADD_RK_OUT=01, SHIFT_ROWS=00
		col_sel[1] = ~(state_is_r0c0 | r0_any | rc_any) | (rc_any & last_round_special_case);
		col_sel[0] = (state_is_r0c0 & enc_dec) | state_is_r0c1 | state_is_r0c2
		           | (state_is_r0c3 & not_enc_dec)
		           | (rc_nospecial & ( (state_is_rc0 & (enc_dec | last_round))
		                             | state_is_rc1 | state_is_rc2
		                             | (state_is_rc3 & (not_enc_dec | last_round)) ));
	end

// Remaining outputs
always @(*)
	begin
		sbox_sel = COL_0;
		rk_sel = COL;
		bypass_rk = DISABLE;
		key_out_sel = KEY_0;
		rd_count_en = DISABLE;
		iv_cnt_en = DISABLE;
		iv_cnt_sel = IV_BUS;
		bypass_key_en = DISABLE;
		key_derivation_en = DISABLE;
		case(state)
			ROUND0_COL0:
				begin
					sbox_sel = COL_0;
					rk_sel   = COL;
					bypass_rk = ENABLE;
					bypass_key_en = ENABLE;
					key_out_sel = KEY_0;
				end
			ROUND0_COL1:
				begin
					sbox_sel = COL_1;
					rk_sel   = COL;
					bypass_rk = ENABLE;
					bypass_key_en = ENABLE;
					key_out_sel = KEY_1;
				end
			ROUND0_COL2:
				begin
					sbox_sel = COL_2;
					rk_sel   = COL;
					bypass_rk = ENABLE;
					bypass_key_en = ENABLE;
					key_out_sel = KEY_2;
				end
			ROUND0_COL3:
				begin
					sbox_sel = COL_3;
					rk_sel   = COL;
					bypass_key_en = ENABLE;
					key_out_sel = KEY_3;
					bypass_rk = ENABLE;
				end
			ROUND_KEY0:
				begin
					sbox_sel = G_FUNCTION;
					rd_count_en = ENABLE;
				end
			ROUND_COL0:
				begin
					sbox_sel = COL_0;
					rk_sel = (last_round) ? MIXCOL_IN : MIXCOL_OUT;
					key_out_sel = KEY_0;
				end
			ROUND_COL1:
				begin
					sbox_sel = COL_1;
					rk_sel   = (last_round) ? MIXCOL_IN : MIXCOL_OUT;
					key_out_sel = KEY_1;
				end
			ROUND_COL2:
				begin
					sbox_sel = COL_2;
					rk_sel   = (last_round) ? MIXCOL_IN : MIXCOL_OUT;
					key_out_sel = KEY_2;
				end
			ROUND_COL3:
				begin
					sbox_sel = COL_3;
					rk_sel   = (last_round) ? MIXCOL_IN : MIXCOL_OUT;
					key_out_sel = KEY_3;
					if(last_round_and_mode_ctr)
						begin
							iv_cnt_en = ENABLE;
							iv_cnt_sel = IV_CNT;
						end
				end
			GEN_KEY0:
				begin
					sbox_sel = G_FUNCTION;
					rd_count_en = ENABLE;
				end
			GEN_KEY1:
					bypass_key_en = ENABLE;
			GEN_KEY2:
					bypass_key_en = ENABLE;
			GEN_KEY3:
					bypass_key_en = ENABLE;
			READY:
				begin
					if(op_mode == KEY_DERIVATION)
						key_derivation_en = ENABLE;
				end
		endcase
	end

// Round Counter
wire rd_count_clear = state_is_idle | (state_is_gk3 & last_round);

always @(posedge clk, negedge rst_n)
	begin
		if(!rst_n)
			rd_count <= INITIAL_ROUND;
		else
			if(rd_count_clear)
				rd_count <= INITIAL_ROUND;
			else 
				if(rd_count_en)
					rd_count <= rd_count + 1'b1;
	end

assign round = rd_count;
assign first_round = (rd_count == INITIAL_ROUND);
assign last_round  = (rd_count == NUMBER_ROUND || rd_count == NUMBER_ROUND_INC);

endmodule