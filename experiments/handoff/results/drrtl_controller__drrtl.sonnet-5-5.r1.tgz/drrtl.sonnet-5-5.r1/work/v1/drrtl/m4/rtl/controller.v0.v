// file controller.v0.4.v

module control_unit
(
	output [ 2:0] sbox_sel,
	output [ 1:0] rk_sel,
	output [ 1:0] key_out_sel,
	output [ 1:0] col_sel,
	output [ 3:0] key_en,
	output [ 3:0] col_en,
	output     [ 3:0] round,
	output bypass_rk,
	output bypass_key_en,
	output key_sel,
	output iv_cnt_en,
	output iv_cnt_sel,
	output key_derivation_en,
	output end_comp,
	output key_init,
	output key_gen,
	output mode_ctr,
	output mode_cbc,
	output last_round,
	output encrypt_decrypt,
	input [1:0] operation_mode,
	input [1:0] aes_mode,
	input start,
	input disable_core,
	input clk,
	input rst_n
);

localparam ENCRYPTION     = 2'b00;
localparam KEY_DERIVATION = 2'b01;
localparam DECRYPTION     = 2'b10;
localparam DECRYP_W_DERIV = 2'b11;

localparam ECB = 2'b00;
localparam CBC = 2'b01;
localparam CTR = 2'b10;

localparam NUMBER_ROUND      = 4'd10;
localparam NUMBER_ROUND_INC  = 4'd11;
localparam INITIAL_ROUND     = 4'd00;

localparam IDLE        = 4'd00;
localparam ROUND0_COL0 = 4'd01;
localparam ROUND0_COL1 = 4'd02;
localparam ROUND0_COL2 = 4'd03;
localparam ROUND0_COL3 = 4'd04;
localparam ROUND_KEY0  = 4'd05;
localparam ROUND_COL0  = 4'd06;
localparam ROUND_COL1  = 4'd07;
localparam ROUND_COL2  = 4'd08;
localparam ROUND_COL3  = 4'd09;
localparam READY       = 4'd10;
localparam GEN_KEY0    = 4'd11;
localparam GEN_KEY1    = 4'd12;
localparam GEN_KEY2    = 4'd13;
localparam GEN_KEY3    = 4'd14;
localparam NOP         = 4'd15;

reg [3:0] state, next_state;
reg [3:0] rd_count;

wire op_key_derivation;
wire first_round;
wire [1:0] op_mode;
wire enc_dec;

// ---------------------------------------------------------------------------
// One-hot style state pre-decode
// ---------------------------------------------------------------------------
wire s_idle = (state == IDLE);
wire s_r0c0 = (state == ROUND0_COL0);
wire s_r0c1 = (state == ROUND0_COL1);
wire s_r0c2 = (state == ROUND0_COL2);
wire s_r0c3 = (state == ROUND0_COL3);
wire s_rk0  = (state == ROUND_KEY0);
wire s_rc0  = (state == ROUND_COL0);
wire s_rc1  = (state == ROUND_COL1);
wire s_rc2  = (state == ROUND_COL2);
wire s_rc3  = (state == ROUND_COL3);
wire s_ready = (state == READY);
wire s_gk0  = (state == GEN_KEY0);
wire s_gk1  = (state == GEN_KEY1);
wire s_gk2  = (state == GEN_KEY2);
wire s_gk3  = (state == GEN_KEY3);

wire s_gk_grp = s_gk0 | s_gk1 | s_gk2 | s_gk3;
wire r0_any   = s_r0c0 | s_r0c1 | s_r0c2 | s_r0c3;
wire rc_any   = s_rc0 | s_rc1 | s_rc2 | s_rc3;

// ---------------------------------------------------------------------------
// Mode / data-dependent conditions
// ---------------------------------------------------------------------------
assign mode_ctr = (aes_mode == CTR);
assign mode_cbc = (aes_mode == CBC);
assign op_mode  = (mode_ctr) ? ENCRYPTION : operation_mode;

wire op_mode1 = ~mode_ctr & operation_mode[1];

assign encrypt_decrypt = ~op_mode1 | s_gk_grp;
assign enc_dec = encrypt_decrypt | mode_ctr;
wire ned = ~enc_dec;

assign last_round  = rd_count[3] & ~rd_count[2] & rd_count[1];
assign first_round = ~(|rd_count);

wire not_last_round = ~last_round;
wire last_round_and_enc_dec = last_round & enc_dec;
wire last_round_and_mode_ctr = last_round & mode_ctr;
wire sp = (last_round & mode_cbc & ned) | last_round_and_mode_ctr;
wire nsp = ~sp;

wire ed_nlast  = enc_dec & not_last_round;
wire ned_nlast = ned & not_last_round;

assign key_gen = s_rk0;
assign key_init = start;
assign op_key_derivation = (op_mode == KEY_DERIVATION);
assign end_comp = s_ready;

// State flops
always @(posedge clk, negedge rst_n)
	begin
		if(!rst_n)
			state <= IDLE;
		else
			if(disable_core)
				state <= IDLE;
			else
				state <= next_state;
	end

// Next State Logic
always @(*)
	begin
		next_state = state;
		case(state)
			IDLE:
				begin
					if(!start)
						next_state = IDLE;
					else
						case(op_mode)
							ENCRYPTION    : next_state = ROUND0_COL0;
							DECRYPTION    : next_state = ROUND0_COL3;
							KEY_DERIVATION: next_state = GEN_KEY0;
							DECRYP_W_DERIV: next_state = GEN_KEY0;
							default       : next_state = IDLE;
						endcase
				end
			ROUND0_COL0: next_state = (enc_dec) ? ROUND0_COL1 : ROUND_KEY0;
			ROUND0_COL1: next_state = (enc_dec) ? ROUND0_COL2 : ROUND0_COL0;
			ROUND0_COL2: next_state = (enc_dec) ? ROUND0_COL3 : ROUND0_COL1;
			ROUND0_COL3: next_state = (enc_dec) ? ROUND_KEY0 : ROUND0_COL2;
			ROUND_KEY0 :
				begin
					if(!first_round)
						next_state = (last_round) ? READY : NOP;
					else
						next_state = (enc_dec) ? ROUND_COL0 : ROUND_COL3;
				end
			NOP        : next_state = (enc_dec) ? ROUND_COL0 : ROUND_COL3;
			ROUND_COL0 : next_state = (enc_dec) ? ROUND_COL1 : ROUND_KEY0;
			ROUND_COL1 : next_state = (enc_dec) ? ROUND_COL2 : ROUND_COL0;
			ROUND_COL2 : next_state = (enc_dec) ? ROUND_COL3 : ROUND_COL1;
			ROUND_COL3 :
				begin
					if(last_round_and_enc_dec)
						next_state = READY;
					else
						next_state = (enc_dec) ? ROUND_KEY0 : ROUND_COL2;
				end
			GEN_KEY0   : next_state = GEN_KEY1;
			GEN_KEY1   : next_state = GEN_KEY2;
			GEN_KEY2   : next_state = GEN_KEY3;
			GEN_KEY3   :
				begin
					if(last_round)
						next_state = (op_key_derivation) ? READY : ROUND0_COL3;
					else
						next_state = GEN_KEY0;
				end
			READY      : next_state = IDLE;
		endcase
	end

// ---------------------------------------------------------------------------
// Output logic: flat per-bit AND-OR equations over pre-decoded state wires
// ---------------------------------------------------------------------------
wire col_odd = s_r0c1 | s_r0c3 | s_rc1 | s_rc3;
wire col_hi  = s_r0c2 | s_r0c3 | s_rc2 | s_rc3;

assign sbox_sel[2] = s_rk0 | s_gk0;
assign sbox_sel[1] = col_hi;
assign sbox_sel[0] = col_odd;

assign key_out_sel[1] = col_hi;
assign key_out_sel[0] = col_odd;

assign rk_sel[1] = rc_any & not_last_round;
assign rk_sel[0] = rc_any & last_round;

assign bypass_rk = r0_any;
assign bypass_key_en = r0_any | s_gk1 | s_gk2 | s_gk3;

assign key_sel = ((s_r0c1 | s_r0c2 | s_r0c3) & ned) | s_rk0 | rc_any
               | s_gk1 | s_gk2 | s_gk3;

assign key_en[0] = s_rk0 | s_gk1;
assign key_en[1] = (s_r0c1 & ned) | (s_rc0 & enc_dec) | (s_rc1 & ned) | s_gk1;
assign key_en[2] = (s_r0c2 & ned) | (s_rc1 & enc_dec) | (s_rc2 & ned) | s_gk2;
assign key_en[3] = (s_r0c3 & ned) | (s_rc2 & enc_dec) | (s_rc3 & ned) | s_gk3;

// col_sel: default INPUT (10)
wire cs_default = ~r0_any & ~rc_any;
assign col_sel[1] = cs_default | (rc_any & sp);
assign col_sel[0] = (s_r0c0 & enc_dec) | s_r0c1 | s_r0c2 | (s_r0c3 & ned)
                  | (nsp & ((s_rc0 & (enc_dec | last_round))
                          | s_rc1 | s_rc2
                          | (s_rc3 & (ned | last_round))));

wire grp_all_r0c0 = s_r0c0 & ned;
wire grp_all_r0c3 = s_r0c3 & enc_dec;
wire grp_all_rc0  = s_rc0 & ned_nlast;
wire grp_all_rc3  = s_rc3 & ed_nlast;
wire grp_all = grp_all_r0c0 | grp_all_r0c3 | grp_all_rc0 | grp_all_rc3;

assign col_en[0] = s_r0c0 | grp_all_r0c3 | s_rc0 | grp_all_rc3;
assign col_en[1] = s_r0c1 | s_rc1 | grp_all;
assign col_en[2] = s_r0c2 | s_rc2 | grp_all;
assign col_en[3] = s_r0c3 | s_rc3 | grp_all_r0c0 | grp_all_rc0;

wire rd_count_en = s_rk0 | s_gk0;

assign iv_cnt_en  = s_rc3 & last_round_and_mode_ctr;
assign iv_cnt_sel = s_rc3 & last_round_and_mode_ctr;

assign key_derivation_en = s_ready & (op_mode == KEY_DERIVATION);

// Round Counter
wire rd_clear = s_idle | (s_gk3 & last_round);

always @(posedge clk, negedge rst_n)
	begin
		if(!rst_n)
			rd_count <= INITIAL_ROUND;
		else
			if(rd_clear)
				rd_count <= INITIAL_ROUND;
			else
				if(rd_count_en)
					rd_count <= rd_count + 1'b1;
	end

assign round = rd_count;

endmodule