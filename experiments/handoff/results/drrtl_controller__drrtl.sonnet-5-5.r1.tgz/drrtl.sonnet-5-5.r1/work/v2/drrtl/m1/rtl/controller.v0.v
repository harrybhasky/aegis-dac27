// file controller.v1.1.v

module control_unit
(
	output reg [ 2:0] sbox_sel,
	output reg [ 1:0] rk_sel,
	output reg [ 1:0] key_out_sel,
	output reg [ 1:0] col_sel,
	output reg [ 3:0] key_en,
	output reg [ 3:0] col_en,
	output     [ 3:0] round,
	output reg bypass_rk,
	output reg bypass_key_en,
	output reg key_sel,
	output reg iv_cnt_en,
	output reg iv_cnt_sel,
	output reg key_derivation_en,
	output end_comp,
	output key_init,
	output key_gen,
	output mode_ctr,
	output mode_cbc,
	output last_round,
  output encrypt_decrypt,	
	input [1:0] operation_mode,
	input [1:0] aes_mode,
	input start,
	input disable_core,
	input clk,
	input rst_n
);

//=============================================================================
// Operation Modes
//=============================================================================
localparam ENCRYPTION     = 2'b00;
localparam KEY_DERIVATION = 2'b01;
localparam DECRYPTION     = 2'b10;
localparam DECRYP_W_DERIV = 2'b11;

//=============================================================================
// AES Modes
//=============================================================================
localparam ECB = 2'b00;
localparam CBC = 2'b01;
localparam CTR = 2'b10;

//=============================================================================
// SBOX SEL
//=============================================================================
localparam COL_0 = 3'b000;
localparam COL_1 = 3'b001;
localparam COL_2 = 3'b010;
localparam COL_3 = 3'b011;
localparam G_FUNCTION = 3'b100;

//=============================================================================
// RK_SEL
//=============================================================================
localparam COL        = 2'b00;
localparam MIXCOL_IN  = 2'b01;
localparam MIXCOL_OUT = 2'b10;

//=============================================================================
// KEY_OUT_SEL
//=============================================================================
localparam KEY_0 = 2'b00;
localparam KEY_1 = 2'b01;
localparam KEY_2 = 2'b10;
localparam KEY_3 = 2'b11;

//=============================================================================
// KEY_SEL / IV / ENABLES
//=============================================================================
localparam IV_CNT = 1'b1;
localparam IV_BUS = 1'b0;
localparam ENABLE = 1'b1;
localparam DISABLE = 1'b0;

localparam INITIAL_ROUND     = 4'd00;

//=============================================================================
// FSM STATES
//=============================================================================
localparam IDLE        = 4'd00;
localparam ROUND0_COL0 = 4'd01;
localparam ROUND0_COL1 = 4'd02;
localparam ROUND0_COL2 = 4'd03;
localparam ROUND0_COL3 = 4'd04;
localparam ROUND_KEY0  = 4'd05;
localparam ROUND_COL0  = 4'd06;
localparam ROUND_COL1  = 4'd07;
localparam ROUND_COL2  = 4'd08;
localparam ROUND_COL3  = 4'd09;
localparam READY       = 4'd10;
localparam GEN_KEY0    = 4'd11;
localparam GEN_KEY1    = 4'd12;
localparam GEN_KEY2    = 4'd13;
localparam GEN_KEY3    = 4'd14;
localparam NOP         = 4'd15;

reg [3:0] state, next_state;
reg [3:0] rd_count;

wire op_key_derivation;
wire first_round;
wire [1:0] op_mode;
wire enc_dec;

// ---------------------------------------------------------------------------
// One-hot pre-decode of state
// ---------------------------------------------------------------------------
wire s_idle  = (state == IDLE);
wire s_r0c0  = (state == ROUND0_COL0);
wire s_r0c1  = (state == ROUND0_COL1);
wire s_r0c2  = (state == ROUND0_COL2);
wire s_r0c3  = (state == ROUND0_COL3);
wire s_rk0   = (state == ROUND_KEY0);
wire s_rc0   = (state == ROUND_COL0);
wire s_rc1   = (state == ROUND_COL1);
wire s_rc2   = (state == ROUND_COL2);
wire s_rc3   = (state == ROUND_COL3);
wire s_ready = (state == READY);
wire s_gk0   = (state == GEN_KEY0);
wire s_gk1   = (state == GEN_KEY1);
wire s_gk2   = (state == GEN_KEY2);
wire s_gk3   = (state == GEN_KEY3);
wire s_nop   = (state == NOP);

wire s_gk_any = s_gk0 | s_gk1 | s_gk2 | s_gk3;
wire s_rc_any = s_rc0 | s_rc1 | s_rc2 | s_rc3;

// State Flops
always @(posedge clk, negedge rst_n)
	begin
		if(!rst_n)
			state <= IDLE;
		else
			if(disable_core)
				state <= IDLE;
			else
				state <= next_state;
	end

assign mode_ctr = (aes_mode == CTR);
assign mode_cbc = (aes_mode == CBC);

// op_mode in {ENCRYPTION, KEY_DERIVATION} <=> ctr | ~operation_mode[1]
assign op_mode = (mode_ctr) ? ENCRYPTION : operation_mode;
assign encrypt_decrypt = (~op_mode[1]) | s_gk_any;
assign enc_dec = encrypt_decrypt | mode_ctr;
assign key_gen = s_rk0;
assign op_key_derivation = (op_mode == KEY_DERIVATION);
assign key_init = start;
assign end_comp = s_ready;

wire ne = ~enc_dec;
wire not_last_round = ~last_round;
wire last_round_and_enc_dec = last_round & enc_dec;
wire last_round_and_mode_ctr = last_round & mode_ctr;
wire last_round_special_case = (last_round & mode_cbc & ne) | last_round_and_mode_ctr;
wire not_special = ~last_round_special_case;

// ---------------------------------------------------------------------------
// Next State Logic (flat AND-OR)
// ---------------------------------------------------------------------------
wire [3:0] nx_idle = start ? (op_mode[0] ? GEN_KEY0 : (op_mode[1] ? ROUND0_COL3 : ROUND0_COL0)) : IDLE;
wire [3:0] nx_r0c0 = enc_dec ? ROUND0_COL1 : ROUND_KEY0;
wire [3:0] nx_r0c1 = enc_dec ? ROUND0_COL2 : ROUND0_COL0;
wire [3:0] nx_r0c2 = enc_dec ? ROUND0_COL3 : ROUND0_COL1;
wire [3:0] nx_r0c3 = enc_dec ? ROUND_KEY0  : ROUND0_COL2;
wire [3:0] nx_rk0  = first_round ? (enc_dec ? ROUND_COL0 : ROUND_COL3)
                                 : (last_round ? READY : NOP);
wire [3:0] nx_nop  = enc_dec ? ROUND_COL0 : ROUND_COL3;
wire [3:0] nx_rc0  = enc_dec ? ROUND_COL1 : ROUND_KEY0;
wire [3:0] nx_rc1  = enc_dec ? ROUND_COL2 : ROUND_COL0;
wire [3:0] nx_rc2  = enc_dec ? ROUND_COL3 : ROUND_COL1;
wire [3:0] nx_rc3  = last_round_and_enc_dec ? READY : (enc_dec ? ROUND_KEY0 : ROUND_COL2);
wire [3:0] nx_gk3  = last_round ? (op_key_derivation ? READY : ROUND0_COL3) : GEN_KEY0;

always @(*)
	begin
		next_state = ({4{s_idle}} & nx_idle)
		           | ({4{s_r0c0}} & nx_r0c0)
		           | ({4{s_r0c1}} & nx_r0c1)
		           | ({4{s_r0c2}} & nx_r0c2)
		           | ({4{s_r0c3}} & nx_r0c3)
		           | ({4{s_rk0}}  & nx_rk0)
		           | ({4{s_nop}}  & nx_nop)
		           | ({4{s_rc0}}  & nx_rc0)
		           | ({4{s_rc1}}  & nx_rc1)
		           | ({4{s_rc2}}  & nx_rc2)
		           | ({4{s_rc3}}  & nx_rc3)
		           | ({4{s_gk0}}  & GEN_KEY1)
		           | ({4{s_gk1}}  & GEN_KEY2)
		           | ({4{s_gk2}}  & GEN_KEY3)
		           | ({4{s_gk3}}  & nx_gk3);
		           // READY -> IDLE (0)
	end

// ---------------------------------------------------------------------------
// Critical output equations
// ---------------------------------------------------------------------------
wire r0_any = s_r0c0 | s_r0c1 | s_r0c2 | s_r0c3;
wire nl = not_last_round;

// key_sel
wire key_sel_w = ((s_r0c1 | s_r0c2 | s_r0c3) & ne) | s_rk0 | s_rc_any
               | s_gk1 | s_gk2 | s_gk3;

// key_en
wire [3:0] key_en_w;
assign key_en_w[0] = s_rk0 | s_gk1;
assign key_en_w[1] = (s_r0c1 & ne) | (s_rc0 & enc_dec) | (s_rc1 & ne) | s_gk1;
assign key_en_w[2] = (s_r0c2 & ne) | (s_rc1 & enc_dec) | (s_rc2 & ne) | s_gk2;
assign key_en_w[3] = (s_r0c3 & ne) | (s_rc2 & enc_dec) | (s_rc3 & ne) | s_gk3;

// col_en
wire grp_all = (s_r0c0 & ne) | (s_r0c3 & enc_dec)
             | (s_rc0 & ne & nl) | (s_rc3 & enc_dec & nl);
wire [3:0] col_en_w;
assign col_en_w[0] = grp_all | s_r0c0 | s_rc0;
assign col_en_w[1] = grp_all | s_r0c1 | s_rc1;
assign col_en_w[2] = grp_all | s_r0c2 | s_rc2;
assign col_en_w[3] = grp_all | s_r0c3 | s_rc3;

// col_sel
wire [1:0] col_sel_w;
assign col_sel_w[1] = ~(r0_any | s_rc_any) | (s_rc_any & last_round_special_case);
assign col_sel_w[0] = (s_r0c0 & enc_dec) | s_r0c1 | s_r0c2 | (s_r0c3 & ne)
                    | (s_rc0 & not_special & (enc_dec | last_round))
                    | (s_rc1 & not_special)
                    | (s_rc2 & not_special)
                    | (s_rc3 & not_special & (ne | last_round));

wire rd_count_en = s_rk0 | s_gk0;

always @(*)
	begin
		key_sel = key_sel_w;
		key_en  = key_en_w;
		col_en  = col_en_w;
		col_sel = col_sel_w;
	end

// ---------------------------------------------------------------------------
// Remaining (non-critical) outputs
// ---------------------------------------------------------------------------
always @(*)
	begin
		sbox_sel = COL_0;
		rk_sel = COL;
		bypass_rk = DISABLE;
		key_out_sel = KEY_0;
		iv_cnt_en = DISABLE;
		iv_cnt_sel = IV_BUS;
		bypass_key_en = DISABLE;
		key_derivation_en = DISABLE;
		case(state)
			ROUND0_COL0:
				begin
					sbox_sel = COL_0;
					bypass_rk = ENABLE;
					bypass_key_en = ENABLE;
					key_out_sel = KEY_0;
				end
			ROUND0_COL1:
				begin
					sbox_sel = COL_1;
					bypass_rk = ENABLE;
					bypass_key_en = ENABLE;
					key_out_sel = KEY_1;
				end
			ROUND0_COL2:
				begin
					sbox_sel = COL_2;
					bypass_rk = ENABLE;
					bypass_key_en = ENABLE;
					key_out_sel = KEY_2;
				end
			ROUND0_COL3:
				begin
					sbox_sel = COL_3;
					bypass_key_en = ENABLE;
					key_out_sel = KEY_3;
					bypass_rk = ENABLE;
				end
			ROUND_KEY0:
				begin
					sbox_sel = G_FUNCTION;
				end
			ROUND_COL0:
				begin
					sbox_sel = COL_0;
					rk_sel = (last_round) ? MIXCOL_IN : MIXCOL_OUT;
					key_out_sel = KEY_0;
				end
			ROUND_COL1:
				begin
					sbox_sel = COL_1;
					rk_sel   = (last_round) ? MIXCOL_IN : MIXCOL_OUT;
					key_out_sel = KEY_1;
				end
			ROUND_COL2:
				begin
					sbox_sel = COL_2;
					rk_sel   = (last_round) ? MIXCOL_IN : MIXCOL_OUT;
					key_out_sel = KEY_2;
				end
			ROUND_COL3:
				begin
					sbox_sel = COL_3;
					rk_sel   = (last_round) ? MIXCOL_IN : MIXCOL_OUT;
					key_out_sel = KEY_3;
					if(last_round_and_mode_ctr)
						begin
							iv_cnt_en = ENABLE;
							iv_cnt_sel = IV_CNT;
						end
				end
			GEN_KEY0:
				begin
					sbox_sel = G_FUNCTION;
				end
			GEN_KEY1:
				begin
					bypass_key_en = ENABLE;
				end
			GEN_KEY2:
				begin
					bypass_key_en = ENABLE;
				end
			GEN_KEY3:
				begin
					bypass_key_en = ENABLE;
				end
			READY:
				begin
					if(op_mode == KEY_DERIVATION)
						key_derivation_en = ENABLE;
				end
			default: ;
		endcase
	end

// Round Counter
wire rd_count_clr = s_idle | (s_gk3 & last_round);

always @(posedge clk, negedge rst_n)
	begin
		if(!rst_n)
			rd_count <= INITIAL_ROUND;
		else
			if(rd_count_clr)
				rd_count <= INITIAL_ROUND;
			else 
				if(rd_count_en)
					rd_count <= rd_count + 1'b1;
	end

assign round = rd_count;
assign first_round = ~(|rd_count);
// rd_count == 10 (1010) or 11 (1011)
assign last_round  = rd_count[3] & ~rd_count[2] & rd_count[1];

endmodule