// file controller.v3.2.v

module control_unit
(
	output reg [ 2:0] sbox_sel,
	output reg [ 1:0] rk_sel,
	output reg [ 1:0] key_out_sel,
	output reg [ 1:0] col_sel,
	output reg [ 3:0] key_en,
	output reg [ 3:0] col_en,
	output     [ 3:0] round,
	output reg bypass_rk,
	output reg bypass_key_en,
	output reg key_sel,
	output reg iv_cnt_en,
	output reg iv_cnt_sel,
	output reg key_derivation_en,
	output end_comp,
	output key_init,
	output key_gen,
	output mode_ctr,
	output mode_cbc,
	output last_round,
  output encrypt_decrypt,	
	input [1:0] operation_mode,
	input [1:0] aes_mode,
	input start,
	input disable_core,
	input clk,
	input rst_n
);

localparam ENCRYPTION     = 2'b00;
localparam KEY_DERIVATION = 2'b01;
localparam DECRYPTION     = 2'b10;
localparam DECRYP_W_DERIV = 2'b11;

localparam ECB = 2'b00;
localparam CBC = 2'b01;
localparam CTR = 2'b10;

localparam INITIAL_ROUND     = 4'd00;

localparam IDLE        = 4'd00;
localparam ROUND0_COL0 = 4'd01;
localparam ROUND0_COL1 = 4'd02;
localparam ROUND0_COL2 = 4'd03;
localparam ROUND0_COL3 = 4'd04;
localparam ROUND_KEY0  = 4'd05;
localparam ROUND_COL0  = 4'd06;
localparam ROUND_COL1  = 4'd07;
localparam ROUND_COL2  = 4'd08;
localparam ROUND_COL3  = 4'd09;
localparam READY       = 4'd10;
localparam GEN_KEY0    = 4'd11;
localparam GEN_KEY1    = 4'd12;
localparam GEN_KEY2    = 4'd13;
localparam GEN_KEY3    = 4'd14;
localparam NOP         = 4'd15;

reg [3:0] state;
wire [3:0] next_state;
reg [3:0] rd_count;

reg rd_count_en;
wire op_key_derivation;
wire first_round;
wire [1:0] op_mode;
wire enc_dec;
wire not_enc_dec;
wire last_round_special_case;

// ---------------------------------------------------------------------
// One-hot pre-decode of state
// ---------------------------------------------------------------------
wire s_idle = (state == IDLE);
wire s_r0c0 = (state == ROUND0_COL0);
wire s_r0c1 = (state == ROUND0_COL1);
wire s_r0c2 = (state == ROUND0_COL2);
wire s_r0c3 = (state == ROUND0_COL3);
wire s_rk0  = (state == ROUND_KEY0);
wire s_rc0  = (state == ROUND_COL0);
wire s_rc1  = (state == ROUND_COL1);
wire s_rc2  = (state == ROUND_COL2);
wire s_rc3  = (state == ROUND_COL3);
wire s_rdy  = (state == READY);
wire s_gk0  = (state == GEN_KEY0);
wire s_gk1  = (state == GEN_KEY1);
wire s_gk2  = (state == GEN_KEY2);
wire s_gk3  = (state == GEN_KEY3);
wire s_nop  = (state == NOP);

wire gk_any = s_gk0 | s_gk1 | s_gk2 | s_gk3;
wire r0_any = (s_r0c0 | s_r0c1) | (s_r0c2 | s_r0c3);
wire rc_any = (s_rc0 | s_rc1) | (s_rc2 | s_rc3);

// ---------------------------------------------------------------------
// State flops
// ---------------------------------------------------------------------
always @(posedge clk, negedge rst_n)
	begin
		if(!rst_n)
			state <= IDLE;
		else
			if(disable_core)
				state <= IDLE;
			else
				state <= next_state;
	end

// ---------------------------------------------------------------------
// Mode / shared control
// ---------------------------------------------------------------------
assign mode_ctr = (aes_mode == CTR);
assign mode_cbc = (aes_mode == CBC);
assign op_mode  = (mode_ctr) ? ENCRYPTION : operation_mode;

// op_mode ENCRYPTION / KEY_DERIVATION <=> op_mode[1] == 0
assign encrypt_decrypt = ~op_mode[1] | gk_any;
assign enc_dec     = encrypt_decrypt | mode_ctr;
assign not_enc_dec = ~enc_dec;
assign key_gen     = s_rk0;
assign op_key_derivation = (op_mode == KEY_DERIVATION);
assign key_init    = start;

// last_round: rd_count == 10 (1010) or 11 (1011)
assign last_round  = rd_count[3] & ~rd_count[2] & rd_count[1];
assign first_round = (rd_count == INITIAL_ROUND);

wire not_last_round = ~last_round;
wire lr_and_ctr = last_round & mode_ctr;
assign last_round_special_case = (last_round & mode_cbc & not_enc_dec) | lr_and_ctr;

// ---------------------------------------------------------------------
// Next-state: flat AND-OR over one-hot state
// ---------------------------------------------------------------------
wire idle_go    = s_idle & start;
wire idle_to_c0 = idle_go & ~op_mode[1] & ~op_mode[0];   // ENCRYPTION
wire idle_to_c3 = idle_go &  op_mode[1] & ~op_mode[0];   // DECRYPTION
wire idle_to_gk = idle_go &  op_mode[0];                 // KEY_DERIV / DECRYP_W_DERIV

wire rk0_notfirst = s_rk0 & ~first_round;
wire rk0_first    = s_rk0 &  first_round;
wire rc3_done     = s_rc3 & last_round & enc_dec;
wire rc3_other    = s_rc3 & ~(last_round & enc_dec);
wire gk3_last     = s_gk3 & last_round;
wire gk3_notlast  = s_gk3 & not_last_round;

assign next_state =
	  ({4{idle_to_c0}}                       & ROUND0_COL0)
	| ({4{idle_to_c3}}                       & ROUND0_COL3)
	| ({4{idle_to_gk}}                       & GEN_KEY0)
	| ({4{s_r0c0 &  enc_dec}}                & ROUND0_COL1)
	| ({4{s_r0c0 & not_enc_dec}}             & ROUND_KEY0)
	| ({4{s_r0c1 &  enc_dec}}                & ROUND0_COL2)
	| ({4{s_r0c1 & not_enc_dec}}             & ROUND0_COL0)
	| ({4{s_r0c2 &  enc_dec}}                & ROUND0_COL3)
	| ({4{s_r0c2 & not_enc_dec}}             & ROUND0_COL1)
	| ({4{s_r0c3 &  enc_dec}}                & ROUND_KEY0)
	| ({4{s_r0c3 & not_enc_dec}}             & ROUND0_COL2)
	| ({4{rk0_notfirst &  last_round}}       & READY)
	| ({4{rk0_notfirst & not_last_round}}    & NOP)
	| ({4{(rk0_first | s_nop) &  enc_dec}}   & ROUND_COL0)
	| ({4{(rk0_first | s_nop) & not_enc_dec}} & ROUND_COL3)
	| ({4{s_rc0 &  enc_dec}}                 & ROUND_COL1)
	| ({4{s_rc0 & not_enc_dec}}              & ROUND_KEY0)
	| ({4{s_rc1 &  enc_dec}}                 & ROUND_COL2)
	| ({4{s_rc1 & not_enc_dec}}              & ROUND_COL0)
	| ({4{s_rc2 &  enc_dec}}                 & ROUND_COL3)
	| ({4{s_rc2 & not_enc_dec}}              & ROUND_COL1)
	| ({4{rc3_done}}                         & READY)
	| ({4{rc3_other &  enc_dec}}             & ROUND_KEY0)
	| ({4{rc3_other & not_enc_dec}}          & ROUND_COL2)
	| ({4{s_gk0}}                            & GEN_KEY1)
	| ({4{s_gk1}}                            & GEN_KEY2)
	| ({4{s_gk2}}                            & GEN_KEY3)
	| ({4{gk3_last &  op_key_derivation}}    & READY)
	| ({4{gk3_last & ~op_key_derivation}}    & ROUND0_COL3)
	| ({4{gk3_notlast}}                      & GEN_KEY0);
	// READY -> IDLE (0), IDLE no-start -> IDLE (0)

assign end_comp = s_rdy;

// ---------------------------------------------------------------------
// Output logic: flat AND-OR equations
// ---------------------------------------------------------------------
wire col01_grp = s_r0c1 | s_rc1 | s_r0c3 | s_rc3;   // COL_1 / COL_3
wire col23_grp = s_r0c2 | s_rc2 | s_r0c3 | s_rc3;   // COL_2 / COL_3
wire g_func    = s_rk0 | s_gk0;

wire all_col = (s_r0c0 & not_enc_dec)
             | (s_r0c3 & enc_dec)
             | (s_rc0 & not_enc_dec & not_last_round)
             | (s_rc3 & enc_dec & not_last_round);

always @(*)
	begin
		sbox_sel    = {g_func, col23_grp, col01_grp};
		key_out_sel = {col23_grp, col01_grp};

		rk_sel[0] = rc_any & last_round;
		rk_sel[1] = rc_any & not_last_round;

		bypass_rk     = r0_any;
		bypass_key_en = r0_any | s_gk1 | s_gk2 | s_gk3;

		key_sel = ((s_r0c1 | s_r0c2 | s_r0c3) & not_enc_dec)
		        | s_rk0 | rc_any | s_gk1 | s_gk2 | s_gk3;

		key_en[0] = s_rk0 | s_gk1;
		key_en[1] = (s_r0c1 & not_enc_dec) | (s_rc0 & enc_dec)
		          | (s_rc1 & not_enc_dec) | s_gk1;
		key_en[2] = (s_r0c2 & not_enc_dec) | (s_rc1 & enc_dec)
		          | (s_rc2 & not_enc_dec) | s_gk2;
		key_en[3] = (s_r0c3 & not_enc_dec) | (s_rc2 & enc_dec)
		          | (s_rc3 & not_enc_dec) | s_gk3;

		col_sel[1] = ~(r0_any | rc_any) | (rc_any & last_round_special_case);
		col_sel[0] = (s_r0c0 & enc_dec) | s_r0c1 | s_r0c2 | (s_r0c3 & not_enc_dec)
		           | (~last_round_special_case &
		              ((s_rc0 & (enc_dec | last_round))
		             | s_rc1 | s_rc2
		             | (s_rc3 & (not_enc_dec | last_round))));

		col_en[0] = s_r0c0 | s_rc0 | all_col;
		col_en[1] = s_r0c1 | s_rc1 | all_col;
		col_en[2] = s_r0c2 | s_rc2 | all_col;
		col_en[3] = s_r0c3 | s_rc3 | all_col;

		rd_count_en = s_rk0 | s_gk0;

		iv_cnt_en  = s_rc3 & lr_and_ctr;
		iv_cnt_sel = s_rc3 & lr_and_ctr;

		key_derivation_en = s_rdy & (op_mode == KEY_DERIVATION);
	end

// ---------------------------------------------------------------------
// Round counter
// ---------------------------------------------------------------------
wire rd_clear = s_idle | (s_gk3 & last_round);

always @(posedge clk, negedge rst_n)
	begin
		if(!rst_n)
			rd_count <= INITIAL_ROUND;
		else
			if(rd_clear)
				rd_count <= INITIAL_ROUND;
			else 
				if(rd_count_en)
					rd_count <= rd_count + 1'b1;
	end

assign round = rd_count;

endmodule