// file controller.v3.5.v

module control_unit
(
	output reg [ 2:0] sbox_sel,
	output reg [ 1:0] rk_sel,
	output reg [ 1:0] key_out_sel,
	output reg [ 1:0] col_sel,
	output reg [ 3:0] key_en,
	output reg [ 3:0] col_en,
	output     [ 3:0] round,
	output reg bypass_rk,
	output reg bypass_key_en,
	output reg key_sel,
	output reg iv_cnt_en,
	output reg iv_cnt_sel,
	output reg key_derivation_en,
	output end_comp,
	output key_init,
	output key_gen,
	output mode_ctr,
	output mode_cbc,
	output last_round,
  output encrypt_decrypt,	
	input [1:0] operation_mode,
	input [1:0] aes_mode,
	input start,
	input disable_core,
	input clk,
	input rst_n
);

localparam ENCRYPTION     = 2'b00;
localparam KEY_DERIVATION = 2'b01;
localparam DECRYPTION     = 2'b10;
localparam DECRYP_W_DERIV = 2'b11;

localparam ECB = 2'b00;
localparam CBC = 2'b01;
localparam CTR = 2'b10;

localparam INITIAL_ROUND     = 4'd00;

localparam IDLE        = 4'd00;
localparam ROUND0_COL0 = 4'd01;
localparam ROUND0_COL1 = 4'd02;
localparam ROUND0_COL2 = 4'd03;
localparam ROUND0_COL3 = 4'd04;
localparam ROUND_KEY0  = 4'd05;
localparam ROUND_COL0  = 4'd06;
localparam ROUND_COL1  = 4'd07;
localparam ROUND_COL2  = 4'd08;
localparam ROUND_COL3  = 4'd09;
localparam READY       = 4'd10;
localparam GEN_KEY0    = 4'd11;
localparam GEN_KEY1    = 4'd12;
localparam GEN_KEY2    = 4'd13;
localparam GEN_KEY3    = 4'd14;
localparam NOP         = 4'd15;

reg [3:0] state, next_state;
reg [3:0] rd_count;

wire rd_count_en;
wire op_key_derivation;
wire first_round;
wire [1:0] op_mode;
wire enc_dec;

wire last_round_and_mode_ctr;
wire last_round_special_case;
wire last_round_and_enc_dec;
wire not_enc_dec;

// ---------------------------------------------------------------
// One-hot style pre-decode of state (computed once, reused)
// ---------------------------------------------------------------
wire s_idle   = (state == IDLE);
wire s_r0c0   = (state == ROUND0_COL0);
wire s_r0c1   = (state == ROUND0_COL1);
wire s_r0c2   = (state == ROUND0_COL2);
wire s_r0c3   = (state == ROUND0_COL3);
wire s_rk0    = (state == ROUND_KEY0);
wire s_c0     = (state == ROUND_COL0);
wire s_c1     = (state == ROUND_COL1);
wire s_c2     = (state == ROUND_COL2);
wire s_c3     = (state == ROUND_COL3);
wire s_ready  = (state == READY);
wire s_gk0    = (state == GEN_KEY0);
wire s_gk1    = (state == GEN_KEY1);
wire s_gk2    = (state == GEN_KEY2);
wire s_gk3    = (state == GEN_KEY3);

wire s_gen_any = s_gk0 | s_gk1 | s_gk2 | s_gk3;
wire s_r0_any  = s_r0c0 | s_r0c1 | s_r0c2 | s_r0c3;
wire s_col_any = s_c0 | s_c1 | s_c2 | s_c3;

// State Flops Definition
always @(posedge clk, negedge rst_n)
	begin
		if(!rst_n)
			state <= IDLE;
		else
			if(disable_core)
				state <= IDLE;
			else
				state <= next_state;
	end

assign mode_ctr = (aes_mode == CTR);
assign mode_cbc = (aes_mode == CBC);

// op_mode[1] = ~mode_ctr & operation_mode[1]; encrypt = ~op_mode[1] | gen states
assign encrypt_decrypt = mode_ctr | ~operation_mode[1] | s_gen_any;

assign enc_dec = encrypt_decrypt | mode_ctr;
assign key_gen = s_rk0;

assign op_mode = (mode_ctr) ? ENCRYPTION : operation_mode;
assign op_key_derivation = (op_mode == KEY_DERIVATION);

assign key_init = start;

// last_round: rd_count == 10 (1010) or 11 (1011)
assign last_round  = rd_count[3] & ~rd_count[2] & rd_count[1];
assign first_round = ~(|rd_count);

assign not_enc_dec = ~enc_dec;
assign last_round_and_enc_dec = last_round & enc_dec;
assign last_round_and_mode_ctr = last_round & mode_ctr;
assign last_round_special_case = (last_round & mode_cbc & not_enc_dec) | last_round_and_mode_ctr;

// Next State Logic
always @(*)
	begin
		next_state = state;
		case(state)
			IDLE:
				begin
					if(!start)
						next_state = IDLE;
					else
						case(op_mode)
							ENCRYPTION    : next_state = ROUND0_COL0;
							DECRYPTION    : next_state = ROUND0_COL3;
							KEY_DERIVATION: next_state = GEN_KEY0;
							DECRYP_W_DERIV: next_state = GEN_KEY0;
							default       : next_state = IDLE;
						endcase
				end
			ROUND0_COL0:
				begin
					next_state = (enc_dec) ? ROUND0_COL1 : ROUND_KEY0; 
				end
			ROUND0_COL1:
				begin
					next_state = (enc_dec) ? ROUND0_COL2 : ROUND0_COL0;
				end
			ROUND0_COL2:
				begin
					next_state = (enc_dec) ? ROUND0_COL3 : ROUND0_COL1;
				end
			ROUND0_COL3:
				begin
					next_state = (enc_dec) ? ROUND_KEY0 : ROUND0_COL2;
				end
			ROUND_KEY0 :
				begin
					if(!first_round)
						begin
							next_state = (last_round) ? READY : NOP;
						end
					else
						begin
							next_state = (enc_dec) ? ROUND_COL0 : ROUND_COL3;
						end
				end
			NOP        :
				begin
					next_state = (enc_dec) ? ROUND_COL0 : ROUND_COL3;
				end
			ROUND_COL0 :
				begin
					next_state = (enc_dec) ? ROUND_COL1 : ROUND_KEY0;
				end
			ROUND_COL1 :
				begin
					next_state = (enc_dec) ? ROUND_COL2 : ROUND_COL0;
				end
			ROUND_COL2 :
				begin
					next_state = (enc_dec) ? ROUND_COL3 : ROUND_COL1;
				end
			ROUND_COL3 :
				begin
					if(last_round_and_enc_dec)
						next_state = READY;
					else
					next_state = (enc_dec) ? ROUND_KEY0 : ROUND_COL2;
				end
			GEN_KEY0   :
				begin
					next_state = GEN_KEY1;
				end
			GEN_KEY1   :
				begin
					next_state = GEN_KEY2;
				end
			GEN_KEY2   :
				begin
					next_state = GEN_KEY3;
				end
			GEN_KEY3   :
				begin
					if(last_round)
						next_state = (op_key_derivation) ? READY : ROUND0_COL3;
					else
						next_state = GEN_KEY0;
				end
			READY      :
				begin
					next_state = IDLE;
				end
		endcase
	end

// Output Logic
assign end_comp = s_ready;

// Shared terms for flat output equations
wire t_r0c0wide = s_r0c0 & ~enc_dec;
wire t_r0c3wide = s_r0c3 &  enc_dec;
wire t_c0wide   = s_c0 & ~enc_dec & ~last_round;
wire t_c3wide   = s_c3 &  enc_dec & ~last_round;

wire key_sel_w = s_rk0 | s_col_any | s_gk1 | s_gk2 | s_gk3 |
                 ((s_r0c1 | s_r0c2 | s_r0c3) & ~enc_dec);

wire [3:0] key_en_w;
assign key_en_w[0] = s_rk0 | s_gk1;
assign key_en_w[1] = (s_r0c1 & ~enc_dec) | (s_c0 & enc_dec) | (s_c1 & ~enc_dec) | s_gk1;
assign key_en_w[2] = (s_r0c2 & ~enc_dec) | (s_c1 & enc_dec) | (s_c2 & ~enc_dec) | s_gk2;
assign key_en_w[3] = (s_r0c3 & ~enc_dec) | (s_c2 & enc_dec) | (s_c3 & ~enc_dec) | s_gk3;

wire [3:0] col_en_w;
assign col_en_w[0] = s_r0c0 | s_c0 | t_r0c3wide | t_c3wide;
assign col_en_w[1] = t_r0c0wide | s_r0c1 | t_r0c3wide | t_c0wide | s_c1 | t_c3wide;
assign col_en_w[2] = t_r0c0wide | s_r0c2 | t_r0c3wide | t_c0wide | s_c2 | t_c3wide;
assign col_en_w[3] = t_r0c0wide | s_r0c3 | t_c0wide | s_c3;

wire col_sel1_w = ~(s_r0_any | s_col_any) | (s_col_any & last_round_special_case);
wire col_sel0_w = (s_r0c0 & enc_dec) | s_r0c1 | s_r0c2 | (s_r0c3 & ~enc_dec) |
                  (~last_round_special_case &
                   ((s_c0 & (enc_dec | last_round)) | s_c1 | s_c2 |
                    (s_c3 & (~enc_dec | last_round))));

always @(*)
	begin
		sbox_sel[2] = s_rk0 | s_gk0;
		sbox_sel[1] = s_r0c2 | s_r0c3 | s_c2 | s_c3;
		sbox_sel[0] = s_r0c1 | s_r0c3 | s_c1 | s_c3;

		rk_sel[0] = s_col_any &  last_round;
		rk_sel[1] = s_col_any & ~last_round;

		bypass_rk     = s_r0_any;
		bypass_key_en = s_r0_any | s_gk1 | s_gk2 | s_gk3;

		key_out_sel[1] = s_r0c2 | s_r0c3 | s_c2 | s_c3;
		key_out_sel[0] = s_r0c1 | s_r0c3 | s_c1 | s_c3;

		col_sel[1] = col_sel1_w;
		col_sel[0] = col_sel0_w;

		key_sel = key_sel_w;
		key_en  = key_en_w;
		col_en  = col_en_w;

		iv_cnt_en  = s_c3 & last_round_and_mode_ctr;
		iv_cnt_sel = s_c3 & last_round_and_mode_ctr;

		key_derivation_en = s_ready & ~mode_ctr & ~operation_mode[1] & operation_mode[0];
	end

// Round Counter
assign rd_count_en = s_rk0 | s_gk0;

wire rd_clear = s_idle | (s_gk3 & last_round);
wire [3:0] rd_toggle;
assign rd_toggle[0] = rd_count_en;
assign rd_toggle[1] = rd_count_en & rd_count[0];
assign rd_toggle[2] = rd_count_en & rd_count[0] & rd_count[1];
assign rd_toggle[3] = rd_count_en & rd_count[0] & rd_count[1] & rd_count[2];

wire [3:0] rd_count_nxt = (rd_count ^ rd_toggle) & {4{~rd_clear}};

always @(posedge clk, negedge rst_n)
	begin
		if(!rst_n)
			rd_count <= INITIAL_ROUND;
		else
			rd_count <= rd_count_nxt;
	end

assign round = rd_count;

endmodule