// file controller.v3.4.v

module control_unit
(
	output reg [ 2:0] sbox_sel,
	output reg [ 1:0] rk_sel,
	output reg [ 1:0] key_out_sel,
	output reg [ 1:0] col_sel,
	output reg [ 3:0] key_en,
	output reg [ 3:0] col_en,
	output     [ 3:0] round,
	output reg bypass_rk,
	output reg bypass_key_en,
	output reg key_sel,
	output reg iv_cnt_en,
	output reg iv_cnt_sel,
	output reg key_derivation_en,
	output end_comp,
	output key_init,
	output key_gen,
	output mode_ctr,
	output mode_cbc,
	output last_round,
  output encrypt_decrypt,	
	input [1:0] operation_mode,
	input [1:0] aes_mode,
	input start,
	input disable_core,
	input clk,
	input rst_n
);

//=============================================================================
// Operation Modes
//=============================================================================
localparam ENCRYPTION     = 2'b00;
localparam KEY_DERIVATION = 2'b01;
localparam DECRYPTION     = 2'b10;
localparam DECRYP_W_DERIV = 2'b11;

//=============================================================================
// AES Modes
//=============================================================================
localparam ECB = 2'b00;
localparam CBC = 2'b01;
localparam CTR = 2'b10;

localparam ENABLE = 1'b1;
localparam DISABLE = 1'b0;

localparam INITIAL_ROUND     = 4'd00;

//=============================================================================
// FSM STATES
//=============================================================================
localparam IDLE        = 4'd00;
localparam ROUND0_COL0 = 4'd01;
localparam ROUND0_COL1 = 4'd02;
localparam ROUND0_COL2 = 4'd03;
localparam ROUND0_COL3 = 4'd04;
localparam ROUND_KEY0  = 4'd05;
localparam ROUND_COL0  = 4'd06;
localparam ROUND_COL1  = 4'd07;
localparam ROUND_COL2  = 4'd08;
localparam ROUND_COL3  = 4'd09;
localparam READY       = 4'd10;
localparam GEN_KEY0    = 4'd11;
localparam GEN_KEY1    = 4'd12;
localparam GEN_KEY2    = 4'd13;
localparam GEN_KEY3    = 4'd14;
localparam NOP         = 4'd15;

reg [3:0] state, next_state;
reg [3:0] rd_count;

wire op_key_derivation;
wire first_round;
wire [1:0] op_mode;
wire enc_dec;

// One-hot style pre-decode of the state
wire s_idle = (state == IDLE);
wire s_r0c0 = (state == ROUND0_COL0);
wire s_r0c1 = (state == ROUND0_COL1);
wire s_r0c2 = (state == ROUND0_COL2);
wire s_r0c3 = (state == ROUND0_COL3);
wire s_rk0  = (state == ROUND_KEY0);
wire s_rc0  = (state == ROUND_COL0);
wire s_rc1  = (state == ROUND_COL1);
wire s_rc2  = (state == ROUND_COL2);
wire s_rc3  = (state == ROUND_COL3);
wire s_ready = (state == READY);
wire s_gk0  = (state == GEN_KEY0);
wire s_gk1  = (state == GEN_KEY1);
wire s_gk2  = (state == GEN_KEY2);
wire s_gk3  = (state == GEN_KEY3);

wire gk_any   = s_gk0 | s_gk1 | s_gk2 | s_gk3;
wire r0_any   = s_r0c0 | s_r0c1 | s_r0c2 | s_r0c3;
wire rc_any   = s_rc0 | s_rc1 | s_rc2 | s_rc3;
wire r0_12    = s_r0c1 | s_r0c2;

// Pre-computed intermediate signals
wire not_enc_dec;
wire not_last_round;
wire last_round_and_enc_dec;
wire last_round_and_mode_cbc_and_not_enc_dec;
wire last_round_and_mode_ctr;
wire last_round_special_case;

// State Flops Definition
always @(posedge clk, negedge rst_n)
	begin
		if(!rst_n)
			state <= IDLE;
		else
			if(disable_core)
				state <= IDLE;
			else
				state <= next_state;
	end

// op_mode == ENCRYPTION or KEY_DERIVATION  <=>  ~op_mode[1]
// with op_mode = ctr ? 00 : operation_mode
assign encrypt_decrypt = mode_ctr | ~operation_mode[1] | gk_any;

// mode_ctr already forces encrypt_decrypt high, so enc_dec == encrypt_decrypt
assign enc_dec = encrypt_decrypt;
assign key_gen = s_rk0;

assign op_key_derivation = (op_mode == KEY_DERIVATION);

assign mode_ctr = (aes_mode == CTR);
assign mode_cbc = (aes_mode == CBC);

assign key_init = start;

assign not_enc_dec = ~enc_dec;
assign not_last_round = ~last_round;
assign last_round_and_enc_dec = last_round & enc_dec;
assign last_round_and_mode_cbc_and_not_enc_dec = last_round & mode_cbc & not_enc_dec;
assign last_round_and_mode_ctr = last_round & mode_ctr;
assign last_round_special_case = last_round_and_mode_cbc_and_not_enc_dec | last_round_and_mode_ctr;

assign op_mode = (mode_ctr) ? ENCRYPTION : operation_mode;

// Next State Logic
always @(*)
	begin
		next_state = state;
		case(state)
			IDLE:
				begin
					if(!start)
						next_state = IDLE;
					else
						case(op_mode)
							ENCRYPTION    : next_state = ROUND0_COL0;
							DECRYPTION    : next_state = ROUND0_COL3;
							KEY_DERIVATION: next_state = GEN_KEY0;
							DECRYP_W_DERIV: next_state = GEN_KEY0;
							default       : next_state = IDLE;
						endcase
				end
			ROUND0_COL0:
				begin
					next_state = (enc_dec) ? ROUND0_COL1 : ROUND_KEY0; 
				end
			ROUND0_COL1:
				begin
					next_state = (enc_dec) ? ROUND0_COL2 : ROUND0_COL0;
				end
			ROUND0_COL2:
				begin
					next_state = (enc_dec) ? ROUND0_COL3 : ROUND0_COL1;
				end
			ROUND0_COL3:
				begin
					next_state = (enc_dec) ? ROUND_KEY0 : ROUND0_COL2;
				end
			ROUND_KEY0 :
				begin
					if(!first_round)
						begin
							next_state = (last_round) ? READY : NOP;
						end
					else
						begin
							next_state = (enc_dec) ? ROUND_COL0 : ROUND_COL3;
						end
				end
			NOP        :
				begin
					next_state = (enc_dec) ? ROUND_COL0 : ROUND_COL3;
				end
			ROUND_COL0 :
				begin
					next_state = (enc_dec) ? ROUND_COL1 : ROUND_KEY0;
				end
			ROUND_COL1 :
				begin
					next_state = (enc_dec) ? ROUND_COL2 : ROUND_COL0;
				end
			ROUND_COL2 :
				begin
					next_state = (enc_dec) ? ROUND_COL3 : ROUND_COL1;
				end
			ROUND_COL3 :
				begin
					if(last_round_and_enc_dec)
						next_state = READY;
					else
					next_state = (enc_dec) ? ROUND_KEY0 : ROUND_COL2;
				end
			GEN_KEY0   :
				begin
					next_state = GEN_KEY1;
				end
			GEN_KEY1   :
				begin
					next_state = GEN_KEY2;
				end
			GEN_KEY2   :
				begin
					next_state = GEN_KEY3;
				end
			GEN_KEY3   :
				begin
					if(last_round)
						next_state = (op_key_derivation) ? READY : ROUND0_COL3;
					else
						next_state = GEN_KEY0;
				end
			READY      :
				begin
					next_state = IDLE;
				end
		endcase
	end

// Output Logic
assign end_comp = s_ready;

// Shared sub-conditions for column enable / select
wire nE  = ~enc_dec;
wire nL  = ~last_round;
wire colall_cond = (s_r0c0 & nE) | (s_r0c3 & enc_dec) |
                   (s_rc0 & nE & nL) | (s_rc3 & enc_dec & nL);
wire nLS = ~last_round_special_case;

always @(*)
	begin
		// sbox_sel
		sbox_sel[2] = s_rk0 | s_gk0;
		sbox_sel[1] = s_r0c2 | s_r0c3 | s_rc2 | s_rc3;
		sbox_sel[0] = s_r0c1 | s_r0c3 | s_rc1 | s_rc3;

		// rk_sel
		rk_sel[1] = rc_any & nL;
		rk_sel[0] = rc_any & last_round;

		bypass_rk     = r0_any;
		bypass_key_en = r0_any | s_gk1 | s_gk2 | s_gk3;

		// key_out_sel
		key_out_sel[1] = s_r0c2 | s_r0c3 | s_rc2 | s_rc3;
		key_out_sel[0] = s_r0c1 | s_r0c3 | s_rc1 | s_rc3;

		// col_sel
		col_sel[1] = ~(r0_any | rc_any) | (rc_any & last_round_special_case);
		col_sel[0] = (s_r0c0 & enc_dec) | r0_12 | (s_r0c3 & nE) |
		             (s_rc0 & nLS & (enc_dec | last_round)) |
		             (s_rc1 & nLS) | (s_rc2 & nLS) |
		             (s_rc3 & nLS & (nE | last_round));

		// key_sel
		key_sel = ((r0_12 | s_r0c3) & nE) | s_rk0 | rc_any |
		          s_gk1 | s_gk2 | s_gk3;

		// key_en
		key_en[0] = s_rk0 | s_gk1;
		key_en[1] = (s_r0c1 & nE) | (s_rc0 & enc_dec) | (s_rc1 & nE) | s_gk1;
		key_en[2] = (s_r0c2 & nE) | (s_rc1 & enc_dec) | (s_rc2 & nE) | s_gk2;
		key_en[3] = (s_r0c3 & nE) | (s_rc2 & enc_dec) | (s_rc3 & nE) | s_gk3;

		// col_en
		col_en[0] = s_r0c0 | s_rc0 | colall_cond;
		col_en[1] = s_r0c1 | s_rc1 | colall_cond;
		col_en[2] = s_r0c2 | s_rc2 | colall_cond;
		col_en[3] = s_r0c3 | s_rc3 | colall_cond;

		// counter / iv / derivation
		iv_cnt_en  = s_rc3 & last_round_and_mode_ctr;
		iv_cnt_sel = s_rc3 & last_round_and_mode_ctr;
		key_derivation_en = s_ready & (op_mode == KEY_DERIVATION);
	end

// Round Counter
wire rd_count_en  = s_rk0 | s_gk0;
wire rd_count_clr = s_idle | (s_gk3 & last_round);

always @(posedge clk, negedge rst_n)
	begin
		if(!rst_n)
			rd_count <= INITIAL_ROUND;
		else
			if(rd_count_clr)
				rd_count <= INITIAL_ROUND;
			else 
				if(rd_count_en)
					rd_count <= rd_count + 1'b1;
	end

assign round = rd_count;
assign first_round = (rd_count == INITIAL_ROUND);
// rd_count == 10 (1010) or 11 (1011)
assign last_round  = rd_count[3] & ~rd_count[2] & rd_count[1];

endmodule