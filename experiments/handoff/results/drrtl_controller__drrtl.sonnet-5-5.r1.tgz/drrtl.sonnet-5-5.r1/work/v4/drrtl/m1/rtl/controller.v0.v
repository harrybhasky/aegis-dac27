// file controller.v3.1.v

module control_unit
(
	output reg [ 2:0] sbox_sel,
	output reg [ 1:0] rk_sel,
	output reg [ 1:0] key_out_sel,
	output reg [ 1:0] col_sel,
	output reg [ 3:0] key_en,
	output reg [ 3:0] col_en,
	output     [ 3:0] round,
	output reg bypass_rk,
	output reg bypass_key_en,
	output reg key_sel,
	output reg iv_cnt_en,
	output reg iv_cnt_sel,
	output reg key_derivation_en,
	output end_comp,
	output key_init,
	output key_gen,
	output mode_ctr,
	output mode_cbc,
	output last_round,
  output encrypt_decrypt,	
	input [1:0] operation_mode,
	input [1:0] aes_mode,
	input start,
	input disable_core,
	input clk,
	input rst_n
);

//=============================================================================
// Operation Modes
//=============================================================================
localparam ENCRYPTION     = 2'b00;
localparam KEY_DERIVATION = 2'b01;
localparam DECRYPTION     = 2'b10;
localparam DECRYP_W_DERIV = 2'b11;

//=============================================================================
// AES Modes
//=============================================================================
localparam ECB = 2'b00;
localparam CBC = 2'b01;
localparam CTR = 2'b10;

localparam INITIAL_ROUND     = 4'd00;

//=============================================================================
// FSM STATES
//=============================================================================
localparam IDLE        = 4'd00;
localparam ROUND0_COL0 = 4'd01;
localparam ROUND0_COL1 = 4'd02;
localparam ROUND0_COL2 = 4'd03;
localparam ROUND0_COL3 = 4'd04;
localparam ROUND_KEY0  = 4'd05;
localparam ROUND_COL0  = 4'd06;
localparam ROUND_COL1  = 4'd07;
localparam ROUND_COL2  = 4'd08;
localparam ROUND_COL3  = 4'd09;
localparam READY       = 4'd10;
localparam GEN_KEY0    = 4'd11;
localparam GEN_KEY1    = 4'd12;
localparam GEN_KEY2    = 4'd13;
localparam GEN_KEY3    = 4'd14;
localparam NOP         = 4'd15;

reg [3:0] state;
reg [3:0] rd_count;
wire [3:0] next_state;

wire first_round;
wire [1:0] op_mode;
wire enc_dec;
wire not_enc_dec;
wire gk_any;

// One-hot state pre-decode
wire s_idle = (state == IDLE);
wire s_r0c0 = (state == ROUND0_COL0);
wire s_r0c1 = (state == ROUND0_COL1);
wire s_r0c2 = (state == ROUND0_COL2);
wire s_r0c3 = (state == ROUND0_COL3);
wire s_rk0  = (state == ROUND_KEY0);
wire s_rc0  = (state == ROUND_COL0);
wire s_rc1  = (state == ROUND_COL1);
wire s_rc2  = (state == ROUND_COL2);
wire s_rc3  = (state == ROUND_COL3);
wire s_rdy  = (state == READY);
wire s_gk0  = (state == GEN_KEY0);
wire s_gk1  = (state == GEN_KEY1);
wire s_gk2  = (state == GEN_KEY2);
wire s_gk3  = (state == GEN_KEY3);
wire s_nop  = (state == NOP);

wire s_r0_any = s_r0c0 | s_r0c1 | s_r0c2 | s_r0c3;
wire s_rc_any = s_rc0 | s_rc1 | s_rc2 | s_rc3;
assign gk_any = s_gk0 | s_gk1 | s_gk2 | s_gk3;

// State flops
always @(posedge clk, negedge rst_n)
	begin
		if(!rst_n)
			state <= IDLE;
		else
			if(disable_core)
				state <= IDLE;
			else
				state <= next_state;
	end

assign mode_ctr = (aes_mode == CTR);
assign mode_cbc = (aes_mode == CBC);
assign op_mode = (mode_ctr) ? ENCRYPTION : operation_mode;

// ~op_mode[1] == mode_ctr | ~operation_mode[1]
assign encrypt_decrypt = mode_ctr | ~operation_mode[1] | gk_any;
assign enc_dec = mode_ctr | ~operation_mode[1] | gk_any;
assign not_enc_dec = ~enc_dec;

assign key_gen = s_rk0;
assign key_init = start;
assign end_comp = s_rdy;

// Round counter compares
assign first_round = ~(|rd_count);
assign last_round  = rd_count[3] & ~rd_count[2] & rd_count[1];   // 10 or 11
wire not_last_round = ~last_round;

wire last_round_and_mode_ctr = last_round & mode_ctr;
wire sp = (last_round & mode_cbc & not_enc_dec) | last_round_and_mode_ctr;
wire op_kd = (op_mode == KEY_DERIVATION);

// Next state logic: flat OR of per-state terms
wire [3:0] n_idle = s_idle ? (!start ? 4'd0 :
                              (op_mode == ENCRYPTION)     ? ROUND0_COL0 :
                              (op_mode == DECRYPTION)     ? ROUND0_COL3 : GEN_KEY0) : 4'd0;
wire [3:0] n_r0c0 = s_r0c0 ? (enc_dec ? ROUND0_COL1 : ROUND_KEY0) : 4'd0;
wire [3:0] n_r0c1 = s_r0c1 ? (enc_dec ? ROUND0_COL2 : ROUND0_COL0) : 4'd0;
wire [3:0] n_r0c2 = s_r0c2 ? (enc_dec ? ROUND0_COL3 : ROUND0_COL1) : 4'd0;
wire [3:0] n_r0c3 = s_r0c3 ? (enc_dec ? ROUND_KEY0 : ROUND0_COL2) : 4'd0;
wire [3:0] n_rk0  = s_rk0  ? (first_round ? (enc_dec ? ROUND_COL0 : ROUND_COL3)
                                          : (last_round ? READY : NOP)) : 4'd0;
wire [3:0] n_nop  = s_nop  ? (enc_dec ? ROUND_COL0 : ROUND_COL3) : 4'd0;
wire [3:0] n_rc0  = s_rc0  ? (enc_dec ? ROUND_COL1 : ROUND_KEY0) : 4'd0;
wire [3:0] n_rc1  = s_rc1  ? (enc_dec ? ROUND_COL2 : ROUND_COL0) : 4'd0;
wire [3:0] n_rc2  = s_rc2  ? (enc_dec ? ROUND_COL3 : ROUND_COL1) : 4'd0;
wire [3:0] n_rc3  = s_rc3  ? ((last_round & enc_dec) ? READY :
                              (enc_dec ? ROUND_KEY0 : ROUND_COL2)) : 4'd0;
wire [3:0] n_gk0  = s_gk0  ? GEN_KEY1 : 4'd0;
wire [3:0] n_gk1  = s_gk1  ? GEN_KEY2 : 4'd0;
wire [3:0] n_gk2  = s_gk2  ? GEN_KEY3 : 4'd0;
wire [3:0] n_gk3  = s_gk3  ? (last_round ? (op_kd ? READY : ROUND0_COL3) : GEN_KEY0) : 4'd0;
// READY -> IDLE (0)

assign next_state = n_idle | n_r0c0 | n_r0c1 | n_r0c2 | n_r0c3 | n_rk0 | n_nop |
                    n_rc0 | n_rc1 | n_rc2 | n_rc3 | n_gk0 | n_gk1 | n_gk2 | n_gk3;

// Output logic as AND-OR equations
wire rd_count_en = s_rk0 | s_gk0;

wire t_a0 = s_r0c0 & not_enc_dec;
wire t_a1 = s_r0c3 & enc_dec;
wire t_a2 = s_rc0 & not_enc_dec & not_last_round;
wire t_a3 = s_rc3 & enc_dec & not_last_round;
wire allA = t_a0 | t_a1 | t_a2 | t_a3;

wire [2:0] sbox_sel_w;
assign sbox_sel_w[2] = s_rk0 | s_gk0;
assign sbox_sel_w[1] = s_r0c2 | s_r0c3 | s_rc2 | s_rc3;
assign sbox_sel_w[0] = s_r0c1 | s_r0c3 | s_rc1 | s_rc3;

wire [1:0] rk_sel_w;
assign rk_sel_w[0] = s_rc_any & last_round;
assign rk_sel_w[1] = s_rc_any & not_last_round;

wire [1:0] key_out_sel_w;
assign key_out_sel_w[1] = s_r0c2 | s_r0c3 | s_rc2 | s_rc3;
assign key_out_sel_w[0] = s_r0c1 | s_r0c3 | s_rc1 | s_rc3;

wire bypass_rk_w     = s_r0_any;
wire bypass_key_en_w = s_r0_any | s_gk1 | s_gk2 | s_gk3;

wire key_sel_w = (s_r0c1 & not_enc_dec) | (s_r0c2 & not_enc_dec) | (s_r0c3 & not_enc_dec) |
                 s_rk0 | s_rc_any | s_gk1 | s_gk2 | s_gk3;

wire [1:0] col_sel_w;
assign col_sel_w[1] = ~(s_r0_any | (s_rc_any & ~sp));
assign col_sel_w[0] = (s_r0c0 & enc_dec) | s_r0c1 | s_r0c2 | (s_r0c3 & not_enc_dec) |
                      (s_rc0 & ~sp & (enc_dec | last_round)) |
                      (s_rc1 & ~sp) | (s_rc2 & ~sp) |
                      (s_rc3 & ~sp & (not_enc_dec | last_round));

wire [3:0] col_en_w;
assign col_en_w[0] = s_r0c0 | s_rc0 | (s_r0c3 & enc_dec);
assign col_en_w[1] = s_r0c1 | s_rc1 | allA;
assign col_en_w[2] = s_r0c2 | s_rc2 | allA;
assign col_en_w[3] = s_r0c3 | s_rc3 | t_a0 | t_a2;

wire [3:0] key_en_w;
assign key_en_w[0] = s_rk0 | s_gk1;
assign key_en_w[1] = (s_r0c1 & not_enc_dec) | (s_rc0 & enc_dec) | (s_rc1 & not_enc_dec) | s_gk1;
assign key_en_w[2] = (s_r0c2 & not_enc_dec) | (s_rc1 & enc_dec) | (s_rc2 & not_enc_dec) | s_gk2;
assign key_en_w[3] = (s_r0c3 & not_enc_dec) | (s_rc2 & enc_dec) | (s_rc3 & not_enc_dec) | s_gk3;

wire iv_en_w = s_rc3 & last_round_and_mode_ctr;
wire kd_en_w = s_rdy & op_kd;

always @(*)
	begin
		sbox_sel          = sbox_sel_w;
		rk_sel            = rk_sel_w;
		key_out_sel       = key_out_sel_w;
		col_sel           = col_sel_w;
		key_en            = key_en_w;
		col_en            = col_en_w;
		bypass_rk         = bypass_rk_w;
		bypass_key_en     = bypass_key_en_w;
		key_sel           = key_sel_w;
		iv_cnt_en         = iv_en_w;
		iv_cnt_sel        = iv_en_w;
		key_derivation_en = kd_en_w;
	end

// Round Counter
wire rd_clear = s_idle | (s_gk3 & last_round);

always @(posedge clk, negedge rst_n)
	begin
		if(!rst_n)
			rd_count <= INITIAL_ROUND;
		else
			if(rd_clear)
				rd_count <= INITIAL_ROUND;
			else 
				if(rd_count_en)
					rd_count <= rd_count + 1'b1;
	end

assign round = rd_count;

endmodule