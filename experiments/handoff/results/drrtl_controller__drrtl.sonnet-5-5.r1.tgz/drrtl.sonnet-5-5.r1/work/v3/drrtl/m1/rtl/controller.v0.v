// file controller.v2.1.v

module control_unit
(
	output reg [ 2:0] sbox_sel,
	output reg [ 1:0] rk_sel,
	output reg [ 1:0] key_out_sel,
	output reg [ 1:0] col_sel,
	output reg [ 3:0] key_en,
	output reg [ 3:0] col_en,
	output     [ 3:0] round,
	output reg bypass_rk,
	output reg bypass_key_en,
	output reg key_sel,
	output reg iv_cnt_en,
	output reg iv_cnt_sel,
	output reg key_derivation_en,
	output end_comp,
	output key_init,
	output key_gen,
	output mode_ctr,
	output mode_cbc,
	output last_round,
  output encrypt_decrypt,	
	input [1:0] operation_mode,
	input [1:0] aes_mode,
	input start,
	input disable_core,
	input clk,
	input rst_n
);

localparam ENCRYPTION     = 2'b00;
localparam KEY_DERIVATION = 2'b01;
localparam DECRYPTION     = 2'b10;
localparam DECRYP_W_DERIV = 2'b11;

localparam ECB = 2'b00;
localparam CBC = 2'b01;
localparam CTR = 2'b10;

localparam INITIAL_ROUND     = 4'd00;

// FSM STATES
localparam IDLE        = 4'd00;
localparam ROUND0_COL0 = 4'd01;
localparam ROUND0_COL1 = 4'd02;
localparam ROUND0_COL2 = 4'd03;
localparam ROUND0_COL3 = 4'd04;
localparam ROUND_KEY0  = 4'd05;
localparam ROUND_COL0  = 4'd06;
localparam ROUND_COL1  = 4'd07;
localparam ROUND_COL2  = 4'd08;
localparam ROUND_COL3  = 4'd09;
localparam READY       = 4'd10;
localparam GEN_KEY0    = 4'd11;
localparam GEN_KEY1    = 4'd12;
localparam GEN_KEY2    = 4'd13;
localparam GEN_KEY3    = 4'd14;
localparam NOP         = 4'd15;

reg [3:0] state, next_state;
reg [3:0] rd_count;

wire rd_count_en;
wire op_key_derivation;
wire first_round;
wire [1:0] op_mode;
wire enc_dec;

wire last_round_and_mode_cbc_and_not_enc_dec;
wire last_round_and_mode_ctr;
wire last_round_special_case;
wire last_round_and_enc_dec;
wire not_enc_dec;
wire not_last_round;

//=============================================================================
// One-hot state pre-decode (shared by all downstream logic)
//=============================================================================
wire s_idle = (state == IDLE);
wire s_r0c0 = (state == ROUND0_COL0);
wire s_r0c1 = (state == ROUND0_COL1);
wire s_r0c2 = (state == ROUND0_COL2);
wire s_r0c3 = (state == ROUND0_COL3);
wire s_key0 = (state == ROUND_KEY0);
wire s_c0   = (state == ROUND_COL0);
wire s_c1   = (state == ROUND_COL1);
wire s_c2   = (state == ROUND_COL2);
wire s_c3   = (state == ROUND_COL3);
wire s_rdy  = (state == READY);
wire s_gk0  = (state == GEN_KEY0);
wire s_gk1  = (state == GEN_KEY1);
wire s_gk2  = (state == GEN_KEY2);
wire s_gk3  = (state == GEN_KEY3);
wire s_nop  = (state == NOP);

wire s_gk_any = s_gk0 | s_gk1 | s_gk2 | s_gk3;
wire s_r0_any = s_r0c0 | s_r0c1 | s_r0c2 | s_r0c3;
wire s_c_any  = s_c0 | s_c1 | s_c2 | s_c3;

// State Flops Definition
always @(posedge clk, negedge rst_n)
	begin
		if(!rst_n)
			state <= IDLE;
		else
			if(disable_core)
				state <= IDLE;
			else
				state <= next_state;
	end

assign mode_ctr = (aes_mode == CTR);
assign mode_cbc = (aes_mode == CBC);

// op_mode == ENCRYPTION or KEY_DERIVATION  <=>  ~op_mode[1]
assign op_mode = (mode_ctr) ? ENCRYPTION : operation_mode;
wire op_enc_or_kd = mode_ctr | ~operation_mode[1];

assign encrypt_decrypt = op_enc_or_kd | s_gk_any;
assign enc_dec = op_enc_or_kd | s_gk_any | mode_ctr;
assign key_gen = s_key0;

assign op_key_derivation = ~mode_ctr & ~operation_mode[1] & operation_mode[0];

assign key_init = start;

assign not_enc_dec = ~enc_dec;
assign not_last_round = ~last_round;
assign last_round_and_enc_dec = last_round & enc_dec;
assign last_round_and_mode_cbc_and_not_enc_dec = last_round & mode_cbc & not_enc_dec;
assign last_round_and_mode_ctr = last_round & mode_ctr;
assign last_round_special_case = last_round_and_mode_cbc_and_not_enc_dec | last_round_and_mode_ctr;

//=============================================================================
// Next State Logic (flat AND-OR over one-hot state)
//=============================================================================
wire [3:0] idle_t = op_mode[0] ? GEN_KEY0 : (op_mode[1] ? ROUND0_COL3 : ROUND0_COL0);
wire [3:0] key0_t = first_round ? (enc_dec ? ROUND_COL0 : ROUND_COL3)
                                : (last_round ? READY : NOP);
wire [3:0] c3_t   = last_round_and_enc_dec ? READY : (enc_dec ? ROUND_KEY0 : ROUND_COL2);
wire [3:0] gk3_t  = last_round ? (op_key_derivation ? READY : ROUND0_COL3) : GEN_KEY0;

always @(*)
	begin
		next_state =
			  ({4{s_idle & start}} & idle_t)
			| ({4{s_r0c0}} & (enc_dec ? ROUND0_COL1 : ROUND_KEY0))
			| ({4{s_r0c1}} & (enc_dec ? ROUND0_COL2 : ROUND0_COL0))
			| ({4{s_r0c2}} & (enc_dec ? ROUND0_COL3 : ROUND0_COL1))
			| ({4{s_r0c3}} & (enc_dec ? ROUND_KEY0  : ROUND0_COL2))
			| ({4{s_key0}} & key0_t)
			| ({4{s_nop}}  & (enc_dec ? ROUND_COL0 : ROUND_COL3))
			| ({4{s_c0}}   & (enc_dec ? ROUND_COL1 : ROUND_KEY0))
			| ({4{s_c1}}   & (enc_dec ? ROUND_COL2 : ROUND_COL0))
			| ({4{s_c2}}   & (enc_dec ? ROUND_COL3 : ROUND_COL1))
			| ({4{s_c3}}   & c3_t)
			| ({4{s_gk0}}  & GEN_KEY1)
			| ({4{s_gk1}}  & GEN_KEY2)
			| ({4{s_gk2}}  & GEN_KEY3)
			| ({4{s_gk3}}  & gk3_t);
			// READY -> IDLE (0)
	end

// Output Logic
assign end_comp = s_rdy;

assign rd_count_en = s_key0 | s_gk0;

// Shared output terms
wire col_all_term = (s_r0c0 & not_enc_dec) | (s_r0c3 & enc_dec)
                  | (s_c0 & not_enc_dec & not_last_round)
                  | (s_c3 & enc_dec & not_last_round);

wire add_rk = (s_r0c0 & enc_dec) | s_r0c1 | s_r0c2 | (s_r0c3 & not_enc_dec)
            | (~last_round_special_case &
               ( (s_c0 & (enc_dec | last_round))
               | s_c1 | s_c2
               | (s_c3 & (not_enc_dec | last_round)) ));

wire shift_rows = (s_r0c0 & not_enc_dec) | (s_r0c3 & enc_dec)
                | (~last_round_special_case & not_last_round &
                   ( (s_c0 & not_enc_dec) | (s_c3 & enc_dec) ));

wire grp_c1_bit = s_r0c1 | s_r0c3 | s_c1 | s_c3;
wire grp_c2_bit = s_r0c2 | s_r0c3 | s_c2 | s_c3;

always @(*)
	begin
		sbox_sel[2] = s_key0 | s_gk0;
		sbox_sel[1] = grp_c2_bit;
		sbox_sel[0] = grp_c1_bit;

		rk_sel[1] = s_c_any & not_last_round;
		rk_sel[0] = s_c_any & last_round;

		bypass_rk = s_r0_any;
		bypass_key_en = s_r0_any | s_gk1 | s_gk2 | s_gk3;

		key_out_sel[1] = grp_c2_bit;
		key_out_sel[0] = grp_c1_bit;

		col_sel[0] = add_rk;
		col_sel[1] = ~(add_rk | shift_rows);

		key_sel = ((s_r0c1 | s_r0c2 | s_r0c3) & not_enc_dec)
		        | s_key0 | s_c_any | s_gk1 | s_gk2 | s_gk3;

		key_en[0] = s_key0 | s_gk1;
		key_en[1] = (s_r0c1 & not_enc_dec) | (s_c0 & enc_dec) | (s_c1 & not_enc_dec) | s_gk1;
		key_en[2] = (s_r0c2 & not_enc_dec) | (s_c1 & enc_dec) | (s_c2 & not_enc_dec) | s_gk2;
		key_en[3] = (s_r0c3 & not_enc_dec) | (s_c2 & enc_dec) | (s_c3 & not_enc_dec) | s_gk3;

		col_en[0] = s_r0c0 | s_c0 | col_all_term;
		col_en[1] = s_r0c1 | s_c1 | col_all_term;
		col_en[2] = s_r0c2 | s_c2 | col_all_term;
		col_en[3] = s_r0c3 | s_c3 | col_all_term;

		iv_cnt_en  = s_c3 & last_round_and_mode_ctr;
		iv_cnt_sel = s_c3 & last_round_and_mode_ctr;

		key_derivation_en = s_rdy & op_key_derivation;
	end

// Round Counter
wire rd_clear = s_idle | (s_gk3 & last_round);

always @(posedge clk, negedge rst_n)
	begin
		if(!rst_n)
			rd_count <= INITIAL_ROUND;
		else
			if(rd_clear)
				rd_count <= INITIAL_ROUND;
			else 
				if(rd_count_en)
					rd_count <= rd_count + 1'b1;
	end

assign round = rd_count;
assign first_round = ~(rd_count[3] | rd_count[2] | rd_count[1] | rd_count[0]);
// rd_count == 10 (1010) or 11 (1011)
assign last_round  = rd_count[3] & ~rd_count[2] & rd_count[1];

endmodule