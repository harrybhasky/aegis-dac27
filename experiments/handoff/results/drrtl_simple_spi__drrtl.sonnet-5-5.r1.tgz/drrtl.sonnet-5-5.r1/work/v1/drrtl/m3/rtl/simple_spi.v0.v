/////////////////////////////////////////////////////////////////////
////                                                             ////
////  OpenCores                    MC68HC11E based SPI interface ////
////                                                             ////
////  Author: Richard Herveille                                  ////
////          richard@asics.ws                                   ////
////          www.asics.ws                                       ////
////                                                             ////
/////////////////////////////////////////////////////////////////////
////                                                             ////
//// Copyright (C) 2002 Richard Herveille                        ////
////                    richard@asics.ws                         ////
////                                                             ////
//// This source file may be used and distributed without        ////
//// restriction provided that this copyright statement is not   ////
//// removed from the file and that any derivative work contains ////
//// the original copyright notice and the associated disclaimer.////
////                                                             ////
////     THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY     ////
//// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED   ////
//// TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS   ////
//// FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL THE AUTHOR      ////
//// OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,         ////
//// INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES    ////
//// (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE   ////
//// GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR        ////
//// BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF  ////
//// LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY, OR TORT  ////
//// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT  ////
//// OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         ////
//// POSSIBILITY OF SUCH DAMAGE.                                 ////
////                                                             ////
/////////////////////////////////////////////////////////////////////

//  CVS Log
//
//  $Id: simple_spi_top.v,v 1.5 2004/02/28 15:59:50 rherveille Exp $
//
//  $Date: 2004/02/28 15:59:50 $
//  $Revision: 1.5 $
//  $Author: rherveille $
//  $Locker:  $
//  $State: Exp $
//
// Change History:
//               $Log: simple_spi_top.v,v $
//               Revision 1.5  2004/02/28 15:59:50  rherveille
//               Fixed SCK_O generation bug.
//               This resulted in a major rewrite of the serial interface engine.
//
//               Revision 1.4  2003/08/01 11:41:54  rherveille
//               Fixed some timing bugs.
//
//               Revision 1.3  2003/01/09 16:47:59  rherveille
//               Updated clkcnt size and decoding due to new SPR bit assignments.
//
//               Revision 1.2  2003/01/07 13:29:52  rherveille
//               Changed SPR bits coding.
//
//               Revision 1.1.1.1  2002/12/22 16:07:15  rherveille
//               Initial release
//
//



//
// Motorola MC68HC11E based SPI interface
//
// Currently only MASTER mode is supported
//

// synopsys translate_off
`include "timescale.v"
// synopsys translate_on

module simple_spi_top(
  // 8bit WISHBONE bus slave interface
  input  wire       clk_i,         // clock
  input  wire       rst_i,         // reset (asynchronous active low)
  input  wire       cyc_i,         // cycle
  input  wire       stb_i,         // strobe
  input  wire [1:0] adr_i,         // address
  input  wire       we_i,          // write enable
  input  wire [7:0] dat_i,         // data input
  output reg  [7:0] dat_o,         // data output
  output reg        ack_o,         // normal bus termination
  output reg        inta_o,        // interrupt output

  // SPI port
  output reg        sck_o,         // serial clock output
  output wire       mosi_o,        // MasterOut SlaveIN
  input  wire       miso_i         // MasterIn SlaveOut
);

  reg  [7:0] spcr;
  wire [7:0] spsr;
  reg  [7:0] sper;
  reg  [7:0] treg, rreg;

  // fifo signals
  wire [7:0] rfdout;
  reg        wfre, rfwe;
  wire       rfre, rffull, rfempty;
  wire [7:0] wfdout;
  wire       wfwe, wffull, wfempty;

  // misc signals
  wire      tirq;
  wire      wfov;
  reg [1:0] state;
  reg [2:0] bcnt;

  // Wishbone interface
  wire wb_acc = cyc_i & stb_i;
  wire wb_wr  = wb_acc & we_i;

  // dat_i
  always @(posedge clk_i or negedge rst_i)
    if (~rst_i)
      begin
          spcr <= #1 8'h10;
          sper <= #1 8'h00;
      end
    else if (wb_wr)
      begin
        if (adr_i == 2'b00)
          spcr <= #1 dat_i | 8'h10;

        if (adr_i == 2'b11)
          sper <= #1 dat_i;
      end

  // write fifo
  wire adr_is_10 = (adr_i == 2'b10);
  assign wfwe = wb_acc & adr_is_10 & ack_o &  we_i;
  assign wfov = wfwe & wffull;

  // dat_o
  always @(posedge clk_i)
    case(adr_i) // synopsys full_case parallel_case
      2'b00: dat_o <= #1 spcr;
      2'b01: dat_o <= #1 spsr;
      2'b10: dat_o <= #1 rfdout;
      2'b11: dat_o <= #1 sper;
    endcase

  // read fifo
  assign rfre = wb_acc & adr_is_10 & ack_o & ~we_i;

  // ack_o
  always @(posedge clk_i or negedge rst_i)
    if (~rst_i)
      ack_o <= #1 1'b0;
    else
      ack_o <= #1 wb_acc & !ack_o;

  // decode Serial Peripheral Control Register
  wire       spie = spcr[7];
  wire       spe  = spcr[6];
  wire       dwom = spcr[5];
  wire       mstr = spcr[4];
  wire       cpol = spcr[3];
  wire       cpha = spcr[2];
  wire [1:0] spr  = spcr[1:0];

  // decode Serial Peripheral Extension Register
  wire [1:0] icnt = sper[7:6];
  wire [1:0] spre = sper[1:0];

  wire [3:0] espr = {spre, spr};

  // generate status register
  wire wr_spsr = wb_wr & (adr_i == 2'b01);

  reg spif;
  always @(posedge clk_i)
    if (~spe)
      spif <= #1 1'b0;
    else
      spif <= #1 (tirq | spif) & ~(wr_spsr & dat_i[7]);

  reg wcol;
  always @(posedge clk_i)
    if (~spe)
      wcol <= #1 1'b0;
    else
      wcol <= #1 (wfov | wcol) & ~(wr_spsr & dat_i[6]);

  assign spsr[7]   = spif;
  assign spsr[6]   = wcol;
  assign spsr[5:4] = 2'b00;
  assign spsr[3]   = wffull;
  assign spsr[2]   = wfempty;
  assign spsr[1]   = rffull;
  assign spsr[0]   = rfempty;

  // generate IRQ output (inta_o)
  always @(posedge clk_i)
    inta_o <= #1 spif & spie;

  // hookup read/write buffer fifo
  fifo4 #(8)
  rfifo(
	.clk   ( clk_i   ),
	.rst   ( rst_i   ),
	.clr   ( ~spe    ),
	.din   ( treg    ),
	.we    ( rfwe    ),
	.dout  ( rfdout  ),
	.re    ( rfre    ),
	.full  ( rffull  ),
	.empty ( rfempty )
  ),
  wfifo(
	.clk   ( clk_i   ),
	.rst   ( rst_i   ),
	.clr   ( ~spe    ),
	.din   ( dat_i   ),
	.we    ( wfwe    ),
	.dout  ( wfdout  ),
	.re    ( wfre    ),
	.full  ( wffull  ),
	.empty ( wfempty )
  );

  // zero detect of clkcnt: balanced tree, replicated per consumer cone
  wire cz_a_cnt = |clkcnt[3:0];
  wire cz_b_cnt = |clkcnt[7:4];
  wire cz_c_cnt = |clkcnt[11:8];
  wire cz_a_sm  = |clkcnt[3:0];
  wire cz_b_sm  = |clkcnt[7:4];
  wire cz_c_sm  = |clkcnt[11:8];

  wire ena_cnt = ~(cz_a_cnt | cz_b_cnt | cz_c_cnt);  // for clkcnt
  wire ena_sm  = ~(cz_a_sm  | cz_b_sm  | cz_c_sm);   // for state machine

  // generate clk divider
  reg [11:0] clkcnt;
  wire cnt_dec = spe & ~ena_cnt & (|state);
  always @(posedge clk_i)
    if(cnt_dec)
      clkcnt <= #1 clkcnt - 12'h1;
    else
      case (espr) // synopsys full_case parallel_case
        4'b0000: clkcnt <= #1 12'h0;
        4'b0001: clkcnt <= #1 12'h1;
        4'b0010: clkcnt <= #1 12'h3;
        4'b0011: clkcnt <= #1 12'hf;
        4'b0100: clkcnt <= #1 12'h1f;
        4'b0101: clkcnt <= #1 12'h7;
        4'b0110: clkcnt <= #1 12'h3f;
        4'b0111: clkcnt <= #1 12'h7f;
        4'b1000: clkcnt <= #1 12'hff;
        4'b1001: clkcnt <= #1 12'h1ff;
        4'b1010: clkcnt <= #1 12'h3ff;
        4'b1011: clkcnt <= #1 12'h7ff;
      endcase

  wire ena = ena_sm;

  // pre-decoded state / condition wires
  wire st_idle = (state == 2'b00);
  wire st_p2   = (state == 2'b01);
  wire st_p1   = (state == 2'b11);

  wire go_start  = st_idle & ~wfempty;
  wire st_p2_go  = st_p2 & ena;
  wire st_p1_go  = st_p1 & ena;
  wire bcnt_zero = ~|bcnt;
  wire [2:0] bcnt_dec = bcnt - 3'h1;
  wire p1_last   = st_p1_go & bcnt_zero;

  // idle sck: wfempty selects late
  wire sck_idle_start = cpha ? ~sck_o : cpol;
  wire sck_idle = (~wfempty) ? sck_idle_start : cpol;

  // next-state values (state machine)
  wire [1:0] state_n =
        st_idle ? (wfempty ? 2'b00 : 2'b01) :
        st_p2   ? (ena ? 2'b11 : 2'b01) :
        st_p1   ? (ena ? (bcnt_zero ? 2'b00 : 2'b01) : 2'b11) :
                  2'b00;

  wire [2:0] bcnt_n = st_idle ? 3'h7 : (st_p1_go ? bcnt_dec : bcnt);

  wire [7:0] treg_n = st_idle ? wfdout :
                      (st_p1_go ? {treg[6:0], miso_i} : treg);

  wire sck_n = st_idle ? sck_idle :
               st_p2_go ? ~sck_o :
               st_p1_go ? (bcnt_zero ? cpol : ~sck_o) :
                          sck_o;

  // transfer statemachine
  always @(posedge clk_i)
    if (~spe)
      begin
          state <= #1 2'b00;
          bcnt  <= #1 3'h0;
          treg  <= #1 8'h00;
          wfre  <= #1 1'b0;
          rfwe  <= #1 1'b0;
          sck_o <= #1 1'b0;
      end
    else
      begin
         wfre  <= #1 go_start;
         rfwe  <= #1 p1_last;
         state <= #1 state_n;
         bcnt  <= #1 bcnt_n;
         treg  <= #1 treg_n;
         sck_o <= #1 sck_n;
      end

  assign mosi_o = treg[7];

  // count number of transfers (for interrupt generation)
  reg [1:0] tcnt;
  always @(posedge clk_i)
    if (~spe)
      tcnt <= #1 icnt;
    else if (rfwe)
      if (|tcnt)
        tcnt <= #1 tcnt - 2'h1;
      else
        tcnt <= #1 icnt;

  assign tirq = ~|tcnt & rfwe;

endmodule

/////////////////////////////////////////////////////////////////////
////                                                             ////
//// FIFO 4 entries deep                                         ////
////                                                             ////
//// Authors: Rudolf Usselmann, Richard Herveille                ////
////          rudi@asics.ws     richard@asics.ws                 ////
////                                                             ////
////                                                             ////
//// Download from: http://www.opencores.org/projects/sasc       ////
////                http://www.opencores.org/projects/simple_spi ////
////                                                             ////
/////////////////////////////////////////////////////////////////////
////                                                             ////
//// Copyright (C) 2000-2002 Rudolf Usselmann, Richard Herveille ////
////                         www.asics.ws                        ////
////                         rudi@asics.ws, richard@asics.ws     ////
////                                                             ////
//// This source file may be used and distributed without        ////
//// restriction provided that this copyright statement is not   ////
//// removed from the file and that any derivative work contains ////
//// the original copyright notice and the associated disclaimer.////
////                                                             ////
////     THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY     ////
//// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED   ////
//// TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS   ////
//// FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL THE AUTHOR      ////
//// OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,         ////
//// INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES    ////
//// (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE   ////
//// GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR        ////
//// BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF  ////
//// LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY, OR TORT  ////
//// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT  ////
//// OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         ////
//// POSSIBILITY OF SUCH DAMAGE.                                 ////
////                                                             ////
/////////////////////////////////////////////////////////////////////

//  CVS Log
//
//  $Id: fifo4.v,v 1.1.1.1 2002/12/22 16:07:14 rherveille Exp $
//
//  $Date: 2002/12/22 16:07:14 $
//  $Revision: 1.1.1.1 $
//  $Author: rherveille $
//  $Locker:  $
//  $State: Exp $
//
// Change History:
//               $Log: fifo4.v,v $
//               Revision 1.1.1.1  2002/12/22 16:07:14  rherveille
//               Initial release
//
//

// synopsys translate_off
`include "timescale.v"

// 4 entry deep fast fifo
module fifo4(clk, rst, clr,  din, we, dout, re, full, empty);

parameter dw = 8;

input		clk, rst;
input		clr;
input   [dw:1]	din;
input		we;
output  [dw:1]	dout;
input		re;
output		full, empty;

reg     [dw:1]	mem[0:3];
reg     [1:0]   wp;
reg     [1:0]   rp;
wire    [1:0]   wp_p1;
wire    [1:0]   wp_p2;
wire    [1:0]   rp_p1;
wire		full, empty;
reg		gb;

always @(posedge clk or negedge rst)
        if(!rst)	wp <= #1 2'h0;
        else
        if(clr)		wp <= #1 2'h0;
        else
        if(we)		wp <= #1 wp_p1;

assign wp_p1 = wp + 2'h1;
assign wp_p2 = wp + 2'h2;

always @(posedge clk or negedge rst)
        if(!rst)	rp <= #1 2'h0;
        else
        if(clr)		rp <= #1 2'h0;
        else
        if(re)		rp <= #1 rp_p1;

assign rp_p1 = rp + 2'h1;

// Fifo Output
assign  dout = mem[ rp ];

// Write-pointer decode depends only on wp; late 'we' is ANDed last
wire wsel0 = (wp == 2'd0);
wire wsel1 = (wp == 2'd1);
wire wsel2 = (wp == 2'd2);
wire wsel3 = (wp == 2'd3);

wire we0 = wsel0 & we;
wire we1 = wsel1 & we;
wire we2 = wsel2 & we;
wire we3 = wsel3 & we;

always @(posedge clk) begin
        if(we0) mem[0] <= #1 din;
        if(we1) mem[1] <= #1 din;
        if(we2) mem[2] <= #1 din;
        if(we3) mem[3] <= #1 din;
end

// Status: shared compare
wire wp_eq_rp = (wp == rp);
assign empty = wp_eq_rp & !gb;
assign full  = wp_eq_rp &  gb;

// Guard Bit ...
always @(posedge clk)
	if(!rst)			gb <= #1 1'b0;
	else
	if(clr)				gb <= #1 1'b0;
	else
	if((wp_p1 == rp) & we)		gb <= #1 1'b1;
	else
	if(re)				gb <= #1 1'b0;

endmodule
