/////////////////////////////////////////////////////////////////////
////                                                             ////
////  OpenCores                    MC68HC11E based SPI interface ////
////                                                             ////
////  Author: Richard Herveille                                  ////
////          richard@asics.ws                                   ////
////          www.asics.ws                                       ////
////                                                             ////
/////////////////////////////////////////////////////////////////////
////                                                             ////
//// Copyright (C) 2002 Richard Herveille                        ////
////                    richard@asics.ws                         ////
////                                                             ////
//// This source file may be used and distributed without        ////
//// restriction provided that this copyright statement is not   ////
//// removed from the file and that any derivative work contains ////
//// the original copyright notice and the associated disclaimer.////
////                                                             ////
////     THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY     ////
//// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED   ////
//// TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS   ////
//// FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL THE AUTHOR      ////
//// OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,         ////
//// INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES    ////
//// (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE   ////
//// GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR        ////
//// BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF  ////
//// LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY, OR TORT  ////
//// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT  ////
//// OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         ////
//// POSSIBILITY OF SUCH DAMAGE.                                 ////
////                                                             ////
/////////////////////////////////////////////////////////////////////

//  CVS Log
//
//  $Id: simple_spi_top.v,v 1.5 2004/02/28 15:59:50 rherveille Exp $
//
//  $Date: 2004/02/28 15:59:50 $
//  $Revision: 1.5 $
//  $Author: rherveille $
//  $Locker:  $
//  $State: Exp $
//
// Change History:
//               $Log: simple_spi_top.v,v $
//               Revision 1.5  2004/02/28 15:59:50  rherveille
//               Fixed SCK_O generation bug.
//               This resulted in a major rewrite of the serial interface engine.
//
//               Revision 1.4  2003/08/01 11:41:54  rherveille
//               Fixed some timing bugs.
//
//               Revision 1.3  2003/01/09 16:47:59  rherveille
//               Updated clkcnt size and decoding due to new SPR bit assignments.
//
//               Revision 1.2  2003/01/07 13:29:52  rherveille
//               Changed SPR bits coding.
//
//               Revision 1.1.1.1  2002/12/22 16:07:15  rherveille
//               Initial release
//
//



//
// Motorola MC68HC11E based SPI interface
//
// Currently only MASTER mode is supported
//

// synopsys translate_off
`include "timescale.v"
// synopsys translate_on

module simple_spi_top(
  // 8bit WISHBONE bus slave interface
  input  wire       clk_i,         // clock
  input  wire       rst_i,         // reset (asynchronous active low)
  input  wire       cyc_i,         // cycle
  input  wire       stb_i,         // strobe
  input  wire [1:0] adr_i,         // address
  input  wire       we_i,          // write enable
  input  wire [7:0] dat_i,         // data input
  output reg  [7:0] dat_o,         // data output
  output reg        ack_o,         // normal bus termination
  output reg        inta_o,        // interrupt output

  // SPI port
  output reg        sck_o,         // serial clock output
  output wire       mosi_o,        // MasterOut SlaveIN
  input  wire       miso_i         // MasterIn SlaveOut
);

  reg  [7:0] spcr;
  wire [7:0] spsr;
  reg  [7:0] sper;
  reg  [7:0] treg, rreg;

  // fifo signals
  wire [7:0] rfdout;
  reg        wfre, rfwe;
  wire       rfre, rffull, rfempty;
  wire [7:0] wfdout;
  wire       wfwe, wffull, wfempty;

  // misc signals
  wire      tirq;
  wire      wfov;
  reg [1:0] state;
  reg [2:0] bcnt;

  // Wishbone interface
  wire wb_acc = cyc_i & stb_i;
  wire wb_wr  = wb_acc & we_i;

  always @(posedge clk_i or negedge rst_i)
    if (~rst_i)
      begin
          spcr <= 8'h10;
          sper <= 8'h00;
      end
    else if (wb_wr)
      begin
        if (adr_i == 2'b00)
          spcr <= dat_i | 8'h10;

        if (adr_i == 2'b11)
          sper <= dat_i;
      end

  // write fifo
  wire adr_is_10 = (adr_i == 2'b10);
  assign wfwe = wb_acc & adr_is_10 & ack_o &  we_i;
  assign wfov = wfwe & wffull;

  // dat_o
  always @(posedge clk_i)
    case(adr_i) // synopsys full_case parallel_case
      2'b00: dat_o <= spcr;
      2'b01: dat_o <= spsr;
      2'b10: dat_o <= rfdout;
      2'b11: dat_o <= sper;
    endcase

  // read fifo
  assign rfre = wb_acc & adr_is_10 & ack_o & ~we_i;

  // ack_o
  always @(posedge clk_i or negedge rst_i)
    if (~rst_i)
      ack_o <= 1'b0;
    else
      ack_o <= wb_acc & !ack_o;

  // decode Serial Peripheral Control Register
  wire       spie = spcr[7];
  wire       spe  = spcr[6];
  wire       dwom = spcr[5];
  wire       mstr = spcr[4];
  wire       cpol = spcr[3];
  wire       cpha = spcr[2];
  wire [1:0] spr  = spcr[1:0];

  // decode Serial Peripheral Extension Register
  wire [1:0] icnt = sper[7:6];
  wire [1:0] spre = sper[1:0];

  wire [3:0] espr = {spre, spr};

  // generate status register
  wire wr_spsr = wb_wr & (adr_i == 2'b01);

  reg spif;
  always @(posedge clk_i)
    if (~spe)
      spif <= 1'b0;
    else
      spif <= (tirq | spif) & ~(wr_spsr & dat_i[7]);

  reg wcol;
  always @(posedge clk_i)
    if (~spe)
      wcol <= 1'b0;
    else
      wcol <= (wfov | wcol) & ~(wr_spsr & dat_i[6]);

  assign spsr[7]   = spif;
  assign spsr[6]   = wcol;
  assign spsr[5:4] = 2'b00;
  assign spsr[3]   = wffull;
  assign spsr[2]   = wfempty;
  assign spsr[1]   = rffull;
  assign spsr[0]   = rfempty;

  // generate IRQ output (inta_o)
  always @(posedge clk_i)
    inta_o <= spif & spie;

  // hookup read/write buffer fifo
  fifo4 #(8)
  rfifo(
	.clk   ( clk_i   ),
	.rst   ( rst_i   ),
	.clr   ( ~spe    ),
	.din   ( treg    ),
	.we    ( rfwe    ),
	.dout  ( rfdout  ),
	.re    ( rfre    ),
	.full  ( rffull  ),
	.empty ( rfempty )
  ),
  wfifo(
	.clk   ( clk_i   ),
	.rst   ( rst_i   ),
	.clr   ( ~spe    ),
	.din   ( dat_i   ),
	.we    ( wfwe    ),
	.dout  ( wfdout  ),
	.re    ( wfre    ),
	.full  ( wffull  ),
	.empty ( wfempty )
  );

  //
  // clock divider: shared zero-group wires
  reg [11:0] clkcnt;

  wire nz_g0 = |clkcnt[3:0];
  wire nz_g1 = |clkcnt[7:4];
  wire nz_g2 = |clkcnt[11:8];
  wire z_g0  = ~nz_g0;
  wire z_g1  = ~nz_g1;
  wire z_g2  = ~nz_g2;

  // ena = (clkcnt == 0); replicated for separate consumer cones
  wire ena_s = z_g0 & z_g1 & z_g2;   // state / bcnt / sck / rfwe
  wire ena_t = z_g0 & z_g1 & z_g2;   // treg
  wire clk_nz = ~ena_s;

  // state decode
  wire st_idle = (state == 2'b00);
  wire st_01   = (state == 2'b01);
  wire st_11   = (state == 2'b11);
  wire st_10   = (state == 2'b10);
  wire state_nz = ~st_idle;

  // borrow-lookahead decrement
  wire [11:0] lower_zero;
  assign lower_zero[0]  = 1'b1;
  assign lower_zero[1]  = ~clkcnt[0];
  assign lower_zero[2]  = ~clkcnt[0] & ~clkcnt[1];
  assign lower_zero[3]  = ~clkcnt[0] & ~clkcnt[1] & ~clkcnt[2];
  assign lower_zero[4]  = z_g0;
  assign lower_zero[5]  = z_g0 & ~clkcnt[4];
  assign lower_zero[6]  = z_g0 & ~clkcnt[4] & ~clkcnt[5];
  assign lower_zero[7]  = z_g0 & ~clkcnt[4] & ~clkcnt[5] & ~clkcnt[6];
  assign lower_zero[8]  = z_g0 & z_g1;
  assign lower_zero[9]  = z_g0 & z_g1 & ~clkcnt[8];
  assign lower_zero[10] = z_g0 & z_g1 & ~clkcnt[8] & ~clkcnt[9];
  assign lower_zero[11] = z_g0 & z_g1 & ~clkcnt[8] & ~clkcnt[9] & ~clkcnt[10];

  wire [11:0] clkcnt_dec = clkcnt ^ lower_zero;

  // reload value (hold for unused espr codes, as in original)
  reg [11:0] clkcnt_reload;
  always @(*) begin
    case (espr) // synopsys full_case parallel_case
      4'b0000: clkcnt_reload = 12'h0;
      4'b0001: clkcnt_reload = 12'h1;
      4'b0010: clkcnt_reload = 12'h3;
      4'b0011: clkcnt_reload = 12'hf;
      4'b0100: clkcnt_reload = 12'h1f;
      4'b0101: clkcnt_reload = 12'h7;
      4'b0110: clkcnt_reload = 12'h3f;
      4'b0111: clkcnt_reload = 12'h7f;
      4'b1000: clkcnt_reload = 12'hff;
      4'b1001: clkcnt_reload = 12'h1ff;
      4'b1010: clkcnt_reload = 12'h3ff;
      4'b1011: clkcnt_reload = 12'h7ff;
      default: clkcnt_reload = clkcnt;
    endcase
  end

  wire dec_cond = spe & clk_nz & state_nz;

  always @(posedge clk_i)
    clkcnt <= dec_cond ? clkcnt_dec : clkcnt_reload;

  //
  // transfer statemachine (flattened next-state logic)
  wire bcnt_zero = ~|bcnt;
  wire [2:0] bcnt_dec;
  assign bcnt_dec[0] = ~bcnt[0];
  assign bcnt_dec[1] = bcnt[1] ^ ~bcnt[0];
  assign bcnt_dec[2] = bcnt[2] ^ (~bcnt[0] & ~bcnt[1]);

  wire sh_en    = st_11 & ena_t;           // treg shift enable
  wire step_en  = st_11 & ena_s;           // bcnt / state-11 enable
  wire ph_en    = st_01 & ena_s;           // state-01 enable

  // state next
  wire [1:0] st_next_idle = {1'b0, ~wfempty};
  wire [1:0] st_next_11   = bcnt_zero ? 2'b00 : 2'b01;
  reg  [1:0] state_n;
  always @(*) begin
    state_n = state;
    if (st_idle)       state_n = st_next_idle;
    else if (ph_en)    state_n = 2'b11;
    else if (step_en)  state_n = st_next_11;
    else if (st_10)    state_n = 2'b00;
  end

  // sck_o next
  wire sck_tog      = ~sck_o;
  wire sck_idle_hit = cpha ? sck_tog : cpol;     // used when ~wfempty
  wire sck_idle     = wfempty ? cpol : sck_idle_hit;
  wire sck_11       = bcnt_zero ? cpol : sck_tog;
  reg  sck_n;
  always @(*) begin
    sck_n = sck_o;
    if (st_idle)       sck_n = sck_idle;
    else if (ph_en)    sck_n = sck_tog;
    else if (step_en)  sck_n = sck_11;
  end

  // treg next
  wire [7:0] treg_shift = {treg[6:0], miso_i};
  wire [7:0] treg_n = st_idle ? wfdout : (sh_en ? treg_shift : treg);

  // bcnt next
  wire [2:0] bcnt_n = st_idle ? 3'h7 : (step_en ? bcnt_dec : bcnt);

  always @(posedge clk_i)
    if (~spe)
      begin
          state <= 2'b00;
          bcnt  <= 3'h0;
          treg  <= 8'h00;
          wfre  <= 1'b0;
          rfwe  <= 1'b0;
          sck_o <= 1'b0;
      end
    else
      begin
          state <= state_n;
          bcnt  <= bcnt_n;
          treg  <= treg_n;
          sck_o <= sck_n;
          wfre  <= st_idle & ~wfempty;
          rfwe  <= step_en & bcnt_zero;
      end

  assign mosi_o = treg[7];

  // count number of transfers (for interrupt generation)
  reg [1:0] tcnt;
  always @(posedge clk_i)
    if (~spe)
      tcnt <= icnt;
    else if (rfwe)
      if (|tcnt)
        tcnt <= tcnt - 2'h1;
      else
        tcnt <= icnt;

  assign tirq = ~|tcnt & rfwe;

endmodule

/////////////////////////////////////////////////////////////////////
////                                                             ////
//// FIFO 4 entries deep                                         ////
////                                                             ////
//// Authors: Rudolf Usselmann, Richard Herveille                ////
////          rudi@asics.ws     richard@asics.ws                 ////
////                                                             ////
////                                                             ////
//// Download from: http://www.opencores.org/projects/sasc       ////
////                http://www.opencores.org/projects/simple_spi ////
////                                                             ////
/////////////////////////////////////////////////////////////////////
////                                                             ////
//// Copyright (C) 2000-2002 Rudolf Usselmann, Richard Herveille ////
////                         www.asics.ws                        ////
////                         rudi@asics.ws, richard@asics.ws     ////
////                                                             ////
//// This source file may be used and distributed without        ////
//// restriction provided that this copyright statement is not   ////
//// removed from the file and that any derivative work contains ////
//// the original copyright notice and the associated disclaimer.////
////                                                             ////
////     THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY     ////
//// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED   ////
//// TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS   ////
//// FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL THE AUTHOR      ////
//// OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,         ////
//// INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES    ////
//// (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE   ////
//// GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR        ////
//// BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF  ////
//// LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY, OR TORT  ////
//// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT  ////
//// OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         ////
//// POSSIBILITY OF SUCH DAMAGE.                                 ////
////                                                             ////
/////////////////////////////////////////////////////////////////////

//  CVS Log
//
//  $Id: fifo4.v,v 1.1.1.1 2002/12/22 16:07:14 rherveille Exp $
//
//  $Date: 2002/12/22 16:07:14 $
//  $Revision: 1.1.1.1 $
//  $Author: rherveille $
//  $Locker:  $
//  $State: Exp $
//
// Change History:
//               $Log: fifo4.v,v $
//               Revision 1.1.1.1  2002/12/22 16:07:14  rherveille
//               Initial release
//
//

// synopsys translate_off
`include "timescale.v"

// 4 entry deep fast fifo
module fifo4(clk, rst, clr,  din, we, dout, re, full, empty);

parameter dw = 8;

input		clk, rst;
input		clr;
input   [dw:1]	din;
input		we;
output  [dw:1]	dout;
input		re;
output		full, empty;

reg     [dw:1]	mem[0:3];
reg     [1:0]   wp;
reg     [1:0]   rp;
wire    [1:0]   wp_p1;
wire    [1:0]   wp_p2;
wire    [1:0]   rp_p1;
wire		full, empty;
reg		gb;

always @(posedge clk or negedge rst)
        if(!rst)	wp <= 2'h0;
        else
        if(clr)		wp <= 2'h0;
        else
        if(we)		wp <= wp_p1;

assign wp_p1 = wp + 2'h1;
assign wp_p2 = wp + 2'h2;

always @(posedge clk or negedge rst)
        if(!rst)	rp <= 2'h0;
        else
        if(clr)		rp <= 2'h0;
        else
        if(re)		rp <= rp_p1;

assign rp_p1 = rp + 2'h1;

// Fifo Output
assign  dout = mem[ rp ];

// Fifo Input: pre-decoded per-entry write enables
wire we_sel0 = we & (wp == 2'd0);
wire we_sel1 = we & (wp == 2'd1);
wire we_sel2 = we & (wp == 2'd2);
wire we_sel3 = we & (wp == 2'd3);

always @(posedge clk) begin
        if(we_sel0) mem[0] <= din;
        if(we_sel1) mem[1] <= din;
        if(we_sel2) mem[2] <= din;
        if(we_sel3) mem[3] <= din;
end

// Status: shared pointer compare
wire wp_eq = ~|(wp ^ rp);
assign empty = wp_eq & !gb;
assign full  = wp_eq &  gb;

// Guard Bit ...
always @(posedge clk)
	if(!rst)			gb <= 1'b0;
	else
	if(clr)				gb <= 1'b0;
	else
	if((wp_p1 == rp) & we)		gb <= 1'b1;
	else
	if(re)				gb <= 1'b0;

endmodule
