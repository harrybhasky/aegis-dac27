read_liberty /home/lalit/Documents/dev/aegis-dac27/aegis_agents/pdk/nangate45.lib
read_verilog /home/lalit/Documents/dev/aegis-dac27/aegis_agents/flow/runs/drrtl_uart/aegis.sonnet-5-5.r1/work/v4/regions/r_4ddc8c15e2/C3/eval/sta/netlist.v
link_design uart_top_design
read_sdc /home/lalit/Documents/dev/aegis-dac27/aegis_agents/flow/designs/drrtl_uart/drrtl_uart.sdc
set ::env(AEGIS_MARGIN) 0.0
set ::env(AEGIS_STA_RPT) /home/lalit/Documents/dev/aegis-dac27/aegis_agents/flow/runs/drrtl_uart/aegis.sonnet-5-5.r1/work/v4/regions/r_4ddc8c15e2/C3/eval/sta/endpoints.rpt
source /home/lalit/Documents/dev/aegis-dac27/aegis_agents/tools/sta_endpoints.tcl
report_checks -path_delay max -format full -group_path_count 1 > /home/lalit/Documents/dev/aegis-dac27/aegis_agents/flow/runs/drrtl_uart/aegis.sonnet-5-5.r1/work/v4/regions/r_4ddc8c15e2/C3/eval/sta/groups.rpt
report_checks -unconstrained -path_delay max -format end -group_path_count 5 > /home/lalit/Documents/dev/aegis-dac27/aegis_agents/flow/runs/drrtl_uart/aegis.sonnet-5-5.r1/work/v4/regions/r_4ddc8c15e2/C3/eval/sta/unconstrained.rpt
exit