module uart_top_design (
    input wire clk,
    input wire rst,
    input wire [1:0] address,
    input wire [31:0] write_data,
    input wire we,
    output wire tx,
    input wire rx,
    input wire re,
    output reg [7:0] read_data
);
    
    // Register Interface

    localparam BAUD_DATA = 0;
    localparam ENABLE = 1;
    localparam TX_DATA = 2;
    localparam RX_DATA = 3;

    reg [31:0] baud_division;
    reg enable;
    reg [7:0] data_out;
    wire [7:0] data_in;

    always @(*) begin
        if (rst) begin
            baud_division <= 0;
            enable <= 0;
            data_out <= 0;
        end
        else begin
            casex (address)
                BAUD_DATA: begin
                    if (we) begin
                        baud_division <= write_data;
                    end
                end
                ENABLE: begin
                    if (we) begin
                        enable <= write_data[0];
                    end
                end
                TX_DATA: begin
                    if (we) begin
                        data_out <= write_data[7:0];
                    end
                end
                RX_DATA: begin
                    if (re) begin
                        read_data <= data_in;
                    end
                end
                // default: 
            endcase
        end
    end

    // Baud Rate Generator

    wire baud_tick;

    uart_baud_rate uut_baud_rate (
        .clk (clk),
        .rst (rst),
        .baud_division (baud_division),
        .en (enable),
        .baud_tick (baud_tick)
    );

    // Transmitter

    uart_tx uut_tx (
        .clk (clk),
        .rst (rst),
        .baud_tick (baud_tick),
        .ext_data_in (data_out),
        .en (enable),
        .tx (tx)
    );

    // Receiver

    uart_rx uut_rx (
        .clk (clk),
        .rst (rst),
        .baud_tick (baud_tick),
        .rx (rx),
        .ext_data_out (data_in)
    );
    
endmodule
module uart_baud_rate (
    input wire clk,
    input wire rst,
    input wire [31:0] baud_division,
    input wire en,
    output reg baud_tick
);

    /*
    Clock Frequency: f  = 20 MHz
    Baud Rate:       Bd = 9600 bit/s
    
    Baud Division = ____f____
                     16 x Bd
    */

    reg temp_en;
    reg delayed_en;

    always @(posedge clk) begin
        if (rst) begin
            temp_en <= 0;
            delayed_en <= 0;
        end
        else begin
            if ((en == 0) || (en == 1)) begin
                temp_en <= en;
                delayed_en <= temp_en;
            end
            else begin
                temp_en <= temp_en;
                delayed_en <= delayed_en;
            end
        end
    end
    
    reg [31:0] baud_count;

    // Parallel flag computation (independent of the counter increment chain)
    wire        div_nz    = |baud_division;
    wire        start     = en & ~delayed_en;
    wire        match     = ~(|(baud_count ^ baud_division));
    wire        sel_inc   = div_nz & ~start & ~match;
    wire        sel_one   = div_nz & start;
    wire        tick_nxt  = div_nz & (start ? baud_tick : match);

    // Explicit parallel-prefix AND carries for the incrementer
    wire [31:0] carry;
    assign carry[0] = 1'b1;
    genvar gi;
    generate
        for (gi = 1; gi < 32; gi = gi + 1) begin : g_carry
            assign carry[gi] = &baud_count[gi-1:0];
        end
    endgenerate
    wire [31:0] inc = baud_count ^ carry;

    // AND-OR next-count selection (flat, no priority mux chain)
    wire [31:0] count_nxt = ({32{sel_inc}} & inc) | {31'b0, sel_one};

    always @(posedge clk) begin
        if (rst) begin
            baud_count <= 0;
            baud_tick <= 0;
        end
        else begin
            baud_count <= count_nxt;
            baud_tick <= tick_nxt;
        end
    end
    
endmodule
module uart_rx (
    input clk,
    input rst,
    input baud_tick,
    input rx,
    output reg [7:0] ext_data_out
);
    
    reg [3:0] count_16;
    reg count_16_indication;
    localparam IDLE = 0;
    localparam START = 1;
    localparam DATA = 2;
    localparam STOP = 3;

    reg [1:0] current_state, next_state;

    always @(posedge clk) begin
        if (rst) begin
            count_16 <= 0;
            count_16_indication <= 0;
        end
        else begin
            if (baud_tick == 1) begin
                if (current_state == START) begin
                    if (count_16 == 7) begin
                        count_16 <= 0;
                        count_16_indication <= 1;
                    end
                    else begin
                        count_16 <= count_16 + 1;
                        count_16_indication <= 0;
                    end
                end
                else if ((current_state == DATA) || (current_state == STOP)) begin
                    if (count_16 == 15) begin
                        count_16 <= 0;
                        count_16_indication <= 1;
                    end
                    else begin
                        count_16 <= count_16 + 1;
                        count_16_indication <= 0;
                    end
                end
                else begin
                    count_16 <= 0;
                    count_16_indication <= 0;
                end
            end
            else begin
                count_16 <= count_16;
                count_16_indication <= 0;
            end
        end
    end

    reg [2:0] count_8;
    reg count_8_indication;
    reg [7:0] data_save;

    // Shared sub-conditions (all independent of baud_tick)
    wire       in_data_st   = (current_state == DATA);
    wire       c16_is_15    = (count_16 == 4'd15);
    wire       data_at_c16  = in_data_st & c16_is_15;
    wire       c8_is_7      = (count_8 == 3'd7);
    wire       fire_ind_pre = data_at_c16 & c8_is_7;

    // Precomputed branch values
    wire [2:0] c8_plus1     = count_8 + 3'd1;
    wire [2:0] c8_advance   = c8_is_7 ? 3'd0 : c8_plus1;
    wire [2:0] c8_hold      = in_data_st ? count_8 : 3'd0;
    wire [7:0] ds_shifted   = {data_save[6:0], rx};

    // baud_tick is only used as the final qualifier
    wire       shift_en     = baud_tick & data_at_c16;

    always @(posedge clk) begin
        if (rst) begin
            count_8 <= 0;
            count_8_indication <= 0;
            data_save <= 0;
        end
        else begin
            count_8 <= shift_en ? c8_advance : c8_hold;
            count_8_indication <= baud_tick & fire_ind_pre;
            data_save <= shift_en ? ds_shifted : data_save;
        end
    end

    always @(posedge clk) begin
        if (rst) begin
            ext_data_out <= 0;
        end
        else begin
            ext_data_out <= data_save;
        end
    end

    // Finite State Machine

    

    always @(posedge clk) begin
        if (rst) begin
            current_state <= 0;
        end
        else begin
            current_state <= next_state;
        end
    end

    always @(*) begin
        if (rst) begin
            next_state = 0;
        end
        else begin
            case (current_state)
                IDLE: begin
                    if (rx == 0) begin
                        next_state = START;
                    end
                end
                START: begin
                    if ((count_16_indication == 1) && (rx == 0)) begin
                        next_state = DATA;
                    end
                end
                DATA: begin
                    if (count_8_indication == 1) begin
                        next_state = STOP;
                    end
                end
                STOP: begin
                    if ((count_16_indication == 1) && (rx == 1)) begin
                        next_state = IDLE;
                    end
                end
                default: next_state = IDLE;
            endcase
        end
    end

endmodule
module uart_tx (
    input wire clk,
    input wire rst,
    input wire baud_tick,
    input wire [7:0] ext_data_in,
    input wire en,
    output reg tx
);

    reg [3:0] count_16;
    reg count_16_indication;
    localparam IDLE = 0;
    localparam START = 1;
    localparam DATA = 2;
    localparam STOP = 3;

    reg [1:0] current_state, next_state;

    // Shared terms computed once from early-arriving registers; baud_tick only selects at the end.
    // Replicated per-consumer copies of the enable condition (active & ~wrap).
    (* keep = "true" *) wire c16_go_b0 = (|current_state) & ~(&count_16);
    (* keep = "true" *) wire c16_go_b1 = (|current_state) & ~(&count_16);
    (* keep = "true" *) wire c16_go_b2 = (|current_state) & ~(&count_16);
    (* keep = "true" *) wire c16_go_b3 = (|current_state) & ~(&count_16);
    (* keep = "true" *) wire c16_ind_tick = (|current_state) & (&count_16);

    wire [3:0] c16_nxt;
    assign c16_nxt[0] = c16_go_b0 & ~count_16[0];
    assign c16_nxt[1] = c16_go_b1 & (count_16[1] ^ count_16[0]);
    assign c16_nxt[2] = c16_go_b2 & (count_16[2] ^ (count_16[1] & count_16[0]));
    assign c16_nxt[3] = c16_go_b3 & (count_16[3] ^ (count_16[2] & count_16[1] & count_16[0]));

    always @(posedge clk) begin
        if (rst) begin
            count_16 <= 0;
            count_16_indication <= 0;
        end
        else begin
            count_16[0] <= baud_tick ? c16_nxt[0] : count_16[0];
            count_16[1] <= baud_tick ? c16_nxt[1] : count_16[1];
            count_16[2] <= baud_tick ? c16_nxt[2] : count_16[2];
            count_16[3] <= baud_tick ? c16_nxt[3] : count_16[3];
            count_16_indication <= baud_tick & c16_ind_tick;
        end
    end

    reg [2:0] count_8;
    reg count_8_indication;
    reg [7:0] data_save;

    always @(posedge clk) begin
        if (rst) begin
            count_8 <= 0;
            count_8_indication <= 0;
            data_save <= 0;
        end
        else begin
            if (current_state == DATA) begin
                if ((baud_tick == 1) && (count_16 == 15)) begin
                    if (count_8 == 7) begin
                        count_8 <= 0;
                        count_8_indication <= 1;
                        data_save <= data_save;
                    end
                    else begin
                        count_8 <= count_8 + 1;
                        count_8_indication <= 0;
                        data_save <= {data_save[6:0],1'b0};
                    end
                end
                else begin
                    count_8 <= count_8;
                    count_8_indication <= 0;
                    data_save <= data_save;
                end
            end
            else begin
                count_8 <= 0;
                count_8_indication <= 0;
                data_save <= ext_data_in;
            end
        end
    end
    
    // Finite State Machine

    

    always @(posedge clk) begin
        if (rst) begin
            current_state <= 0;
        end
        else begin
            current_state <= next_state;
        end
    end

    always @(*) begin
        if (rst) begin
            next_state = 0;
        end
        else begin
            case (current_state)
                IDLE: begin
                    tx = 1;
                    if (en == 1) begin
                        next_state = START;
                    end
                end
                START: begin
                    tx = 0;
                    if (count_16_indication == 1) begin
                        next_state = DATA;
                    end
                end
                DATA: begin
                    tx = data_save[7];
                    if (count_8_indication == 1) begin
                        next_state = STOP;
                    end
                end
                STOP: begin
                    tx = 1;
                    if (count_16_indication == 1) begin
                        next_state = IDLE;
                    end
                end
                default: next_state = IDLE;
            endcase
        end
    end

endmodule