// distributed under the mit license
// https://opensource.org/licenses/mit-license.php

`timescale 1 ns / 1 ps
`default_nettype none
module rptr_empty

    #(
    parameter ADDRSIZE = 4
    )(
    input  wire                rclk,
    input  wire                rrst_n,
    input  wire                rinc,
    input  wire [ADDRSIZE  :0] rq2_wptr,
    output reg                 rempty,
    output reg                 arempty,
    output wire [ADDRSIZE-1:0] raddr,
    output reg  [ADDRSIZE  :0] rptr
    );

    reg  [ADDRSIZE:0] rbin;
    wire [ADDRSIZE:0] rgraynext, rbinnext, rgraynextm1;
    wire              arempty_val, rempty_val;

    // lookahead helper signals
    wire              inc = rinc & ~rempty;
    wire [ADDRSIZE:0] cin;    // carry into each bit of rbin + inc
    wire [ADDRSIZE:0] p1;     // rbin + 1
    wire [ADDRSIZE:0] p2;     // rbin + 2
    wire [ADDRSIZE:0] bnextp1; // rbinnext + 1

    genvar gi;
    generate
        for (gi = 0; gi <= ADDRSIZE; gi = gi + 1) begin : g_la
            if (gi == 0) begin : g0
                assign cin[0] = inc;
                assign p1[0]  = ~rbin[0];
                assign p2[0]  = rbin[0];
            end else begin : gn
                assign cin[gi] = inc & (&rbin[gi-1:0]);
                assign p1[gi]  = rbin[gi] ^ (&rbin[gi-1:0]);
                if (gi == 1) begin : g1
                    assign p2[gi] = ~rbin[1];
                end else begin : g2
                    assign p2[gi] = rbin[gi] ^ (&rbin[gi-1:1]);
                end
            end
        end
    endgenerate

    //-------------------
    // GRAYSTYLE2 pointer
    //-------------------
    always @(posedge rclk or negedge rrst_n) begin

        if (!rrst_n)
            {rbin, rptr} <= 0;
        else
            {rbin, rptr} <= {rbinnext, rgraynext};

    end

    // Memory read-address pointer (okay to use binary to address memory)
    assign raddr     = rbin[ADDRSIZE-1:0];
    assign rbinnext  = rbin ^ cin;
    assign rgraynext = (rbinnext >> 1) ^ rbinnext;
    assign bnextp1   = inc ? p2 : p1;
    assign rgraynextm1 = (bnextp1 >> 1) ^ bnextp1;

    //---------------------------------------------------------------
    // FIFO empty when the next rptr == synchronized wptr or on reset
    //---------------------------------------------------------------
    assign rempty_val = (rgraynext == rq2_wptr);
    assign arempty_val = (rgraynextm1 == rq2_wptr);

    always @ (posedge rclk or negedge rrst_n) begin

        if (!rrst_n) begin
            arempty <= 1'b0;
            rempty <= 1'b1;
        end
        else begin
            arempty <= arempty_val;
            rempty <= rempty_val;
        end

    end

endmodule

`resetall
