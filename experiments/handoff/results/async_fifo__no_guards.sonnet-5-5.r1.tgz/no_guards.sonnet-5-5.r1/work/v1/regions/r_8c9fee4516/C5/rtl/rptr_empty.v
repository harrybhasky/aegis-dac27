// distributed under the mit license
// https://opensource.org/licenses/mit-license.php

`timescale 1 ns / 1 ps
`default_nettype none
module rptr_empty

    #(
    parameter ADDRSIZE = 4
    )(
    input  wire                rclk,
    input  wire                rrst_n,
    input  wire                rinc,
    input  wire [ADDRSIZE  :0] rq2_wptr,
    output reg                 rempty,
    output reg                 arempty,
    output wire [ADDRSIZE-1:0] raddr,
    output reg  [ADDRSIZE  :0] rptr
    );

    reg  [ADDRSIZE:0] rbin;
    wire [ADDRSIZE:0] rgraynext, rbinnext, rgraynextm1;
    wire              arempty_val, rempty_val;

    wire              ren;
    wire [ADDRSIZE:0] rbin_p1, rbin_p2;
    wire [ADDRSIZE:0] rgray_p0, rgray_p1, rgray_p2;
    wire              eq_p0, eq_p1, eq_p2;

    //-------------------
    // GRAYSTYLE2 pointer
    //-------------------
    always @(posedge rclk or negedge rrst_n) begin

        if (!rrst_n)
            {rbin, rptr} <= 0;
        else
            {rbin, rptr} <= {rbinnext, rgraynext};

    end

    // Memory read-address pointer (okay to use binary to address memory)
    assign raddr     = rbin[ADDRSIZE-1:0];

    assign ren       = rinc & ~rempty;
    assign rbin_p1   = rbin + 1'b1;
    assign rbin_p2   = rbin + 2'd2;
    assign rgray_p0  = (rbin    >> 1) ^ rbin;
    assign rgray_p1  = (rbin_p1 >> 1) ^ rbin_p1;
    assign rgray_p2  = (rbin_p2 >> 1) ^ rbin_p2;

    assign rbinnext    = ren ? rbin_p1  : rbin;
    assign rgraynext   = ren ? rgray_p1 : rgray_p0;
    assign rgraynextm1 = ren ? rgray_p2 : rgray_p1;

    //---------------------------------------------------------------
    // FIFO empty when the next rptr == synchronized wptr or on reset
    //---------------------------------------------------------------
    assign eq_p0 = (rgray_p0 == rq2_wptr);
    assign eq_p1 = (rgray_p1 == rq2_wptr);
    assign eq_p2 = (rgray_p2 == rq2_wptr);

    assign rempty_val  = ren ? eq_p1 : eq_p0;
    assign arempty_val = ren ? eq_p2 : eq_p1;

    always @ (posedge rclk or negedge rrst_n) begin

        if (!rrst_n) begin
            arempty <= 1'b0;
            rempty <= 1'b1;
        end
        else begin
            arempty <= arempty_val;
            rempty <= rempty_val;
        end

    end

endmodule

`resetall
