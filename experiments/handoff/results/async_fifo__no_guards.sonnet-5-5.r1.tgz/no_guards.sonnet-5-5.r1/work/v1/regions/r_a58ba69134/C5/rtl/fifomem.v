// distributed under the mit license
// https://opensource.org/licenses/mit-license.php

`timescale 1 ns / 1 ps
`default_nettype none
module fifomem

    #(
        parameter  DATASIZE = 8,    // Memory data word width
        parameter  ADDRSIZE = 4,    // Number of mem address bits
        parameter  FALLTHROUGH = "TRUE" // First word fall-through
    ) (
        input  wire                wclk,
        input  wire                wclken,
        input  wire [ADDRSIZE-1:0] waddr,
        input  wire [DATASIZE-1:0] wdata,
        input  wire                wfull,
        input  wire                rclk,
        input  wire                rclken,
        input  wire [ADDRSIZE-1:0] raddr,
        output wire [DATASIZE-1:0] rdata
    );

    localparam DEPTH = 1<<ADDRSIZE;

    reg [DATASIZE-1:0] mem [0:DEPTH-1];
    reg [DATASIZE-1:0] rdata_r;

    wire [DEPTH/2-1:0] pair_en;
    wire [DEPTH-1:0]   word_we;
    integer            wi;

    genvar g;
    generate
        for (g = 0; g < DEPTH/2; g = g + 1) begin : wen_gen
            // early-arriving pair decode (waddr[ADDRSIZE-1:1], wclken, wfull)
            assign pair_en[g]     = wclken & ~wfull & (waddr[ADDRSIZE-1:1] == g);
            // late bit waddr[0] (from wbin_reg[0]) is the final AND only
            assign word_we[2*g]   = pair_en[g] & ~waddr[0];
            assign word_we[2*g+1] = pair_en[g] &  waddr[0];
        end
    endgenerate

    always @(posedge wclk) begin
        for (wi = 0; wi < DEPTH; wi = wi + 1)
            if (word_we[wi]) mem[wi] <= wdata;
    end

    generate
        if (FALLTHROUGH == "TRUE")
        begin : fallthrough
            assign rdata = mem[raddr];
        end
        else
        begin : registered_read
            always @(posedge rclk) begin
                if (rclken)
                    rdata_r <= mem[raddr];
            end
            assign rdata = rdata_r;
        end
    endgenerate

endmodule

`resetall
