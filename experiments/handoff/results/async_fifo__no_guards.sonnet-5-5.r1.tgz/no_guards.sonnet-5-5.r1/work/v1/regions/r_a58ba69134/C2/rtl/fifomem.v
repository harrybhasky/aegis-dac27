// distributed under the mit license
// https://opensource.org/licenses/mit-license.php

`timescale 1 ns / 1 ps
`default_nettype none
module fifomem

    #(
        parameter  DATASIZE = 8,    // Memory data word width
        parameter  ADDRSIZE = 4,    // Number of mem address bits
        parameter  FALLTHROUGH = "TRUE" // First word fall-through
    ) (
        input  wire                wclk,
        input  wire                wclken,
        input  wire [ADDRSIZE-1:0] waddr,
        input  wire [DATASIZE-1:0] wdata,
        input  wire                wfull,
        input  wire                rclk,
        input  wire                rclken,
        input  wire [ADDRSIZE-1:0] raddr,
        output wire [DATASIZE-1:0] rdata
    );

    localparam DEPTH = 1<<ADDRSIZE;

    reg [DATASIZE-1:0] mem [0:DEPTH-1];
    reg [DATASIZE-1:0] rdata_r;

    // Shannon expansion on late bit waddr[0]: early decode of upper bits,
    // waddr[0] used only as the final select.
    wire                wr_ok = wclken && !wfull;
    wire [DEPTH/2-1:0]  hi_dec;
    wire [DEPTH-1:0]    wen;

    genvar j;
    generate
        for (j = 0; j < DEPTH/2; j = j + 1) begin : g_dec
            assign hi_dec[j]  = wr_ok && (waddr[ADDRSIZE-1:1] == j);
            assign wen[2*j]   = waddr[0] ? 1'b0      : hi_dec[j];
            assign wen[2*j+1] = waddr[0] ? hi_dec[j] : 1'b0;
        end
    endgenerate

    integer k;
    always @(posedge wclk) begin
        for (k = 0; k < DEPTH; k = k + 1) begin
            if (wen[k])
                mem[k] <= wdata;
        end
    end

    generate
        if (FALLTHROUGH == "TRUE")
        begin : fallthrough
            assign rdata = mem[raddr];
        end
        else
        begin : registered_read
            always @(posedge rclk) begin
                if (rclken)
                    rdata_r <= mem[raddr];
            end
            assign rdata = rdata_r;
        end
    endgenerate

endmodule

`resetall
