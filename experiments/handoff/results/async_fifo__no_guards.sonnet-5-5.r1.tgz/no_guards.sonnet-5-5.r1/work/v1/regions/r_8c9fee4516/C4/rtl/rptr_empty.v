// distributed under the mit license
// https://opensource.org/licenses/mit-license.php

`timescale 1 ns / 1 ps
`default_nettype none
module rptr_empty

    #(
    parameter ADDRSIZE = 4
    )(
    input  wire                rclk,
    input  wire                rrst_n,
    input  wire                rinc,
    input  wire [ADDRSIZE  :0] rq2_wptr,
    output reg                 rempty,
    output reg                 arempty,
    output wire [ADDRSIZE-1:0] raddr,
    output reg  [ADDRSIZE  :0] rptr
    );

    reg  [ADDRSIZE:0] rbin;
    wire [ADDRSIZE:0] rgraynext, rbinnext, rgraynextm1;
    wire              arempty_val, rempty_val;

    //-------------------
    // GRAYSTYLE2 pointer
    //-------------------
    always @(posedge rclk or negedge rrst_n) begin

        if (!rrst_n)
            {rbin, rptr} <= 0;
        else
            {rbin, rptr} <= {rbinnext, rgraynext};

    end

    // Memory read-address pointer (okay to use binary to address memory)
    assign raddr     = rbin[ADDRSIZE-1:0];

    // Lookahead precompute of rbin+1 and rbin+2 (parallel AND-prefix, no serial carry)
    wire              rinc_en = rinc & ~rempty;
    wire [ADDRSIZE:0] rbin_p1, rbin_p2;
    wire [ADDRSIZE:0] g0, g1, g2;

    genvar gi;
    generate
        for (gi = 0; gi <= ADDRSIZE; gi = gi + 1) begin : la
            if (gi == 0) begin : b0
                assign rbin_p1[gi] = ~rbin[0];
                assign rbin_p2[gi] = rbin[0];
            end else if (gi == 1) begin : b1
                assign rbin_p1[gi] = rbin[1] ^ rbin[0];
                assign rbin_p2[gi] = ~rbin[1];
            end else begin : bn
                assign rbin_p1[gi] = rbin[gi] ^ (&rbin[gi-1:0]);
                assign rbin_p2[gi] = rbin[gi] ^ (&rbin[gi-1:1]);
            end
        end
    endgenerate

    assign g0 = (rbin    >> 1) ^ rbin;
    assign g1 = (rbin_p1 >> 1) ^ rbin_p1;
    assign g2 = (rbin_p2 >> 1) ^ rbin_p2;

    assign rbinnext    = rinc_en ? rbin_p1 : rbin;
    assign rgraynext   = rinc_en ? g1 : g0;
    assign rgraynextm1 = rinc_en ? g2 : g1;

    //---------------------------------------------------------------
    // FIFO empty when the next rptr == synchronized wptr or on reset
    //---------------------------------------------------------------
    assign rempty_val = (rgraynext == rq2_wptr);
    assign arempty_val = (rgraynextm1 == rq2_wptr);

    always @ (posedge rclk or negedge rrst_n) begin

        if (!rrst_n) begin
            arempty <= 1'b0;
            rempty <= 1'b1;
        end
        else begin
            arempty <= arempty_val;
            rempty <= rempty_val;
        end

    end

endmodule

`resetall
