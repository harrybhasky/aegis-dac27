// distributed under the mit license
// https://opensource.org/licenses/mit-license.php

`timescale 1 ns / 1 ps
`default_nettype none
module fifomem

    #(
        parameter  DATASIZE = 8,    // Memory data word width
        parameter  ADDRSIZE = 4,    // Number of mem address bits
        parameter  FALLTHROUGH = "TRUE" // First word fall-through
    ) (
        input  wire                wclk,
        input  wire                wclken,
        input  wire [ADDRSIZE-1:0] waddr,
        input  wire [DATASIZE-1:0] wdata,
        input  wire                wfull,
        input  wire                rclk,
        input  wire                rclken,
        input  wire [ADDRSIZE-1:0] raddr,
        output wire [DATASIZE-1:0] rdata
    );

    localparam DEPTH = 1<<ADDRSIZE;

    reg [DATASIZE-1:0] mem [0:DEPTH-1];
    reg [DATASIZE-1:0] rdata_r;

    // Shannon expansion on late signal waddr[0]: upper address bits and
    // enable are decoded early; waddr[0] is only the final AND per word.
    wire [DEPTH-1:0]   we;
    wire [DEPTH/2-1:0] we_hi;
    genvar j;
    generate
        for (j = 0; j < DEPTH/2; j = j + 1) begin : g_we
            assign we_hi[j]  = wclken && !wfull && (waddr[ADDRSIZE-1:1] == j);
            assign we[2*j]   = we_hi[j] & ~waddr[0];
            assign we[2*j+1] = we_hi[j] &  waddr[0];
        end
    endgenerate

    integer k;
    always @(posedge wclk) begin
        for (k = 0; k < DEPTH; k = k + 1)
            if (we[k])
                mem[k] <= wdata;
    end

    generate
        if (FALLTHROUGH == "TRUE")
        begin : fallthrough
            assign rdata = mem[raddr];
        end
        else
        begin : registered_read
            always @(posedge rclk) begin
                if (rclken)
                    rdata_r <= mem[raddr];
            end
            assign rdata = rdata_r;
        end
    endgenerate

endmodule

`resetall
