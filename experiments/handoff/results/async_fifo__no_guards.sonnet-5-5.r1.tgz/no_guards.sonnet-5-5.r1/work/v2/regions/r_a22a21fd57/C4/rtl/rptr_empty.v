// distributed under the mit license
// https://opensource.org/licenses/mit-license.php

`timescale 1 ns / 1 ps
`default_nettype none
module rptr_empty

    #(
    parameter ADDRSIZE = 4
    )(
    input  wire                rclk,
    input  wire                rrst_n,
    input  wire                rinc,
    input  wire [ADDRSIZE  :0] rq2_wptr,
    output reg                 rempty,
    output reg                 arempty,
    output wire [ADDRSIZE-1:0] raddr,
    output reg  [ADDRSIZE  :0] rptr
    );

    reg  [ADDRSIZE:0] rbin;
    wire [ADDRSIZE:0] rgraynext, rbinnext, rgraynextm1;
    wire              arempty_val, rempty_val;
    wire [ADDRSIZE:0] rbinnext_p1;

    //-------------------
    // GRAYSTYLE2 pointer
    //-------------------
    always @(posedge rclk or negedge rrst_n) begin

        if (!rrst_n)
            {rbin, rptr} <= 0;
        else
            {rbin, rptr} <= {rbinnext, rgraynext};

    end

    // Memory read-address pointer (okay to use binary to address memory)
    assign raddr     = rbin[ADDRSIZE-1:0];
    wire              rinc_en = rinc & ~rempty;
    assign rbinnext  = rbin + ((rinc & ~rempty) ? 1 : 0);
    assign rgraynext = (rbinnext >> 1) ^ rbinnext;
    // Precompute rbin+1 / rbin+2 candidates off the late enable, then select
    wire [ADDRSIZE:0] rbin_p1_c = rbin + 1'b1;
    wire [ADDRSIZE:0] rbin_p2_c = rbin + 2'd2;
    wire [ADDRSIZE:0] gray_p1_c = (rbin_p1_c >> 1) ^ rbin_p1_c;
    wire [ADDRSIZE:0] gray_p2_c = (rbin_p2_c >> 1) ^ rbin_p2_c;
    wire              eq_p1_c   = (gray_p1_c == rq2_wptr);
    wire              eq_p2_c   = (gray_p2_c == rq2_wptr);
    assign rbinnext_p1 = rinc_en ? rbin_p2_c : rbin_p1_c;
    assign rgraynextm1 = rinc_en ? gray_p2_c : gray_p1_c;

    //---------------------------------------------------------------
    // FIFO empty when the next rptr == synchronized wptr or on reset
    //---------------------------------------------------------------
    assign rempty_val = (rgraynext == rq2_wptr);
    assign arempty_val = rinc_en ? eq_p2_c : eq_p1_c;

    always @ (posedge rclk or negedge rrst_n) begin

        if (!rrst_n) begin
            arempty <= 1'b0;
            rempty <= 1'b1;
        end
        else begin
            arempty <= arempty_val;
            rempty <= rempty_val;
        end

    end

endmodule

`resetall
