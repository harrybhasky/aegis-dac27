// distributed under the mit license
// https://opensource.org/licenses/mit-license.php

`timescale 1 ns / 1 ps
`default_nettype none
module fifomem

    #(
        parameter  DATASIZE = 8,    // Memory data word width
        parameter  ADDRSIZE = 4,    // Number of mem address bits
        parameter  FALLTHROUGH = "TRUE" // First word fall-through
    ) (
        input  wire                wclk,
        input  wire                wclken,
        input  wire [ADDRSIZE-1:0] waddr,
        input  wire [DATASIZE-1:0] wdata,
        input  wire                wfull,
        input  wire                rclk,
        input  wire                rclken,
        input  wire [ADDRSIZE-1:0] raddr,
        output wire [DATASIZE-1:0] rdata
    );

    localparam DEPTH = 1<<ADDRSIZE;

    reg [DATASIZE-1:0] mem [0:DEPTH-1];
    reg [DATASIZE-1:0] rdata_r;

    // Shared prefix: common write gating computed once
    wire             write_go  = wclken & ~wfull;

    // Two-level predecode: split address into low/high groups
    localparam LO = (ADDRSIZE+1)/2;
    localparam HI = ADDRSIZE-LO;
    wire [(1<<LO)-1:0] lo_dec = {{((1<<LO)-1){1'b0}}, 1'b1} << waddr[LO-1:0];
    wire [(1<<HI)-1:0] hi_dec = {{((1<<HI)-1){1'b0}}, 1'b1} << waddr[ADDRSIZE-1:LO];
    // Fold the late write enable into the small high-group decode (fanout 1<<HI, not DEPTH)
    wire [(1<<HI)-1:0] hi_en   = hi_dec & {(1<<HI){write_go}};

    // Branch-local tests: one AND2 per word
    wire [DEPTH-1:0] word_we;
    genvar g;
    generate
        for (g = 0; g < DEPTH; g = g + 1) begin : we_gen
            assign word_we[g] = hi_en[g >> LO] & lo_dec[g & ((1<<LO)-1)];
        end
    endgenerate
    integer          wi;

    always @(posedge wclk) begin
        for (wi = 0; wi < DEPTH; wi = wi + 1)
            if (word_we[wi]) mem[wi] <= wdata;
    end

    generate
        if (FALLTHROUGH == "TRUE")
        begin : fallthrough
            assign rdata = mem[raddr];
        end
        else
        begin : registered_read
            always @(posedge rclk) begin
                if (rclken)
                    rdata_r <= mem[raddr];
            end
            assign rdata = rdata_r;
        end
    endgenerate

endmodule

`resetall
