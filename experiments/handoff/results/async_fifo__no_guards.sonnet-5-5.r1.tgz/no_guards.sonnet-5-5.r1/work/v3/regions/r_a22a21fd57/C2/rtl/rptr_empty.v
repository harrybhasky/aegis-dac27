// distributed under the mit license
// https://opensource.org/licenses/mit-license.php

`timescale 1 ns / 1 ps
`default_nettype none
module rptr_empty

    #(
    parameter ADDRSIZE = 4
    )(
    input  wire                rclk,
    input  wire                rrst_n,
    input  wire                rinc,
    input  wire [ADDRSIZE  :0] rq2_wptr,
    output reg                 rempty,
    output reg                 arempty,
    output wire [ADDRSIZE-1:0] raddr,
    output reg  [ADDRSIZE  :0] rptr
    );

    reg  [ADDRSIZE:0] rbin;
    wire [ADDRSIZE:0] rgraynext, rbinnext, rgraynextm1;
    wire              arempty_val, rempty_val;
    wire [ADDRSIZE:0] rbinnext_p1;

    //-------------------
    // GRAYSTYLE2 pointer
    //-------------------
    always @(posedge rclk or negedge rrst_n) begin

        if (!rrst_n)
            {rbin, rptr} <= 0;
        else
            {rbin, rptr} <= {rbinnext, rgraynext};

    end

    // Memory read-address pointer (okay to use binary to address memory)
    assign raddr     = rbin[ADDRSIZE-1:0];

    // Select-style: precompute rbin+1 and rbin+2 in parallel, choose by enable
    wire              rinc_en    = rinc & ~rempty;
    wire [ADDRSIZE:0] rbin_p1    = rbin + {{ADDRSIZE{1'b0}}, 1'b1};
    wire [ADDRSIZE:0] rbin_p2    = rbin + {{(ADDRSIZE-1){1'b0}}, 2'b10};
    wire [ADDRSIZE:0] rgray_p1   = (rbin_p1 >> 1) ^ rbin_p1;
    wire [ADDRSIZE:0] rgray_p2   = (rbin_p2 >> 1) ^ rbin_p2;
    wire              match_p1   = (rgray_p1 == rq2_wptr);
    wire              match_p2   = (rgray_p2 == rq2_wptr);

    assign rbinnext  = rinc_en ? rbin_p1 : rbin;
    assign rgraynext = (rbinnext >> 1) ^ rbinnext;
    assign rbinnext_p1 = rinc_en ? rbin_p2 : rbin_p1;
    assign rgraynextm1 = rinc_en ? rgray_p2 : rgray_p1;

    //---------------------------------------------------------------
    // FIFO empty when the next rptr == synchronized wptr or on reset
    //---------------------------------------------------------------
    assign rempty_val = (rgraynext == rq2_wptr);
    assign arempty_val = rinc_en ? match_p2 : match_p1;

    always @ (posedge rclk or negedge rrst_n) begin

        if (!rrst_n) begin
            arempty <= 1'b0;
            rempty <= 1'b1;
        end
        else begin
            arempty <= arempty_val;
            rempty <= rempty_val;
        end

    end

endmodule

`resetall
