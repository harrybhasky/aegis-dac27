// distributed under the mit license
// https://opensource.org/licenses/mit-license.php

`timescale 1 ns / 1 ps
`default_nettype none
module wptr_full

	#(
		parameter ADDRSIZE = 4
	)(
		input  wire                wclk,
		input  wire                wrst_n,
		input  wire                winc,
		input  wire [ADDRSIZE  :0] wq2_rptr,
		output reg                 wfull,
		output reg                 awfull,
		output wire [ADDRSIZE-1:0] waddr,
		output reg  [ADDRSIZE  :0] wptr
	);

    reg  [ADDRSIZE:0] wbin;
    wire [ADDRSIZE:0] wgraynext, wbinnext, wgraynextp1;
    wire              awfull_val, wfull_val;

	// GRAYSTYLE2 pointer
	always @(posedge wclk or negedge wrst_n) begin

		if (!wrst_n)
			{wbin, wptr} <= 0;
		else
			{wbin, wptr} <= {wbinnext, wgraynext};

	end

    // Memory write-address pointer (okay to use binary to address memory)
    assign waddr = wbin[ADDRSIZE-1:0];

    // Select-style variant: precompute wbin, wbin+1, wbin+2 and their gray codes
    // and full compares off the late wbin[0] path; the increment enable only selects.
    wire              inc = winc & ~wfull;
    wire [ADDRSIZE:0] wb1 = wbin + 1'b1;
    wire [ADDRSIZE:0] wb2 = wbin + 2'd2;
    wire [ADDRSIZE:0] wg0 = (wbin >> 1) ^ wbin;
    wire [ADDRSIZE:0] wg1 = (wb1  >> 1) ^ wb1;
    wire [ADDRSIZE:0] wg2 = (wb2  >> 1) ^ wb2;
    wire [ADDRSIZE:0] wcmp = {~wq2_rptr[ADDRSIZE:ADDRSIZE-1], wq2_rptr[ADDRSIZE-2:0]};
    wire              weq0 = (wg0 == wcmp);
    wire              weq1 = (wg1 == wcmp);
    wire              weq2 = (wg2 == wcmp);

    assign wbinnext    = inc ? wb1 : wbin;
    assign wgraynext   = inc ? wg1 : wg0;
    assign wgraynextp1 = inc ? wg2 : wg1;

    //------------------------------------------------------------------
    // Simplified version of the three necessary full-tests:
    // assign wfull_val=((wgnext[ADDRSIZE] !=wq2_rptr[ADDRSIZE] ) &&
    //                   (wgnext[ADDRSIZE-1]  !=wq2_rptr[ADDRSIZE-1]) &&
    // (wgnext[ADDRSIZE-2:0]==wq2_rptr[ADDRSIZE-2:0]));
    //------------------------------------------------------------------

     assign wfull_val  = inc ? weq1 : weq0;
     assign awfull_val = inc ? weq2 : weq1;

     always @(posedge wclk or negedge wrst_n) begin

        if (!wrst_n) begin
            awfull <= 1'b0;
            wfull  <= 1'b0;
        end else begin
            awfull <= awfull_val;
            wfull  <= wfull_val;
        end
    end

endmodule

`resetall
