// distributed under the mit license
// https://opensource.org/licenses/mit-license.php

`timescale 1 ns / 1 ps
`default_nettype none
module wptr_full

	#(
		parameter ADDRSIZE = 4
	)(
		input  wire                wclk,
		input  wire                wrst_n,
		input  wire                winc,
		input  wire [ADDRSIZE  :0] wq2_rptr,
		output reg                 wfull,
		output reg                 awfull,
		output wire [ADDRSIZE-1:0] waddr,
		output reg  [ADDRSIZE  :0] wptr
	);

    reg  [ADDRSIZE:0] wbin;
    wire [ADDRSIZE:0] wgraynext, wbinnext, wgraynextp1;
    wire              awfull_val, wfull_val;

	// GRAYSTYLE2 pointer
	always @(posedge wclk or negedge wrst_n) begin

		if (!wrst_n)
			{wbin, wptr} <= 0;
		else
			{wbin, wptr} <= {wbinnext, wgraynext};

	end

    // Memory write-address pointer (okay to use binary to address memory)
    assign waddr = wbin[ADDRSIZE-1:0];

    // Precompute both candidates from registered wbin; late "inc" only drives final muxes
    wire              inc = winc & ~wfull;
    wire [ADDRSIZE:0] wb_p1 = wbin + {{ADDRSIZE{1'b0}},1'b1};
    wire [ADDRSIZE:0] wb_p2 = wbin + {{(ADDRSIZE-1){1'b0}},2'b10};
    wire [ADDRSIZE:0] g_p0  = (wbin >> 1) ^ wbin;
    wire [ADDRSIZE:0] g_p1  = (wb_p1 >> 1) ^ wb_p1;
    wire [ADDRSIZE:0] g_p2  = (wb_p2 >> 1) ^ wb_p2;

    assign wbinnext    = inc ? wb_p1 : wbin;
    assign wgraynext   = inc ? g_p1  : g_p0;
    assign wgraynextp1 = inc ? g_p2  : g_p1;

    //------------------------------------------------------------------
    // Simplified version of the three necessary full-tests:
    // assign wfull_val=((wgnext[ADDRSIZE] !=wq2_rptr[ADDRSIZE] ) &&
    //                   (wgnext[ADDRSIZE-1]  !=wq2_rptr[ADDRSIZE-1]) &&
    // (wgnext[ADDRSIZE-2:0]==wq2_rptr[ADDRSIZE-2:0]));
    //------------------------------------------------------------------

     wire [ADDRSIZE:0] full_tgt = {~wq2_rptr[ADDRSIZE:ADDRSIZE-1],wq2_rptr[ADDRSIZE-2:0]};
     wire eq_p0 = (g_p0 == full_tgt);
     wire eq_p1 = (g_p1 == full_tgt);
     wire eq_p2 = (g_p2 == full_tgt);

     assign wfull_val  = inc ? eq_p1 : eq_p0;
     assign awfull_val = inc ? eq_p2 : eq_p1;

     always @(posedge wclk or negedge wrst_n) begin

        if (!wrst_n) begin
            awfull <= 1'b0;
            wfull  <= 1'b0;
        end else begin
            awfull <= awfull_val;
            wfull  <= wfull_val;
        end
    end

endmodule

`resetall
