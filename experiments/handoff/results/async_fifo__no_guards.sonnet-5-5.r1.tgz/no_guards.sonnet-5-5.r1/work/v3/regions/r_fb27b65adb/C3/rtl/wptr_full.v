// distributed under the mit license
// https://opensource.org/licenses/mit-license.php

`timescale 1 ns / 1 ps
`default_nettype none
module wptr_full

	#(
		parameter ADDRSIZE = 4
	)(
		input  wire                wclk,
		input  wire                wrst_n,
		input  wire                winc,
		input  wire [ADDRSIZE  :0] wq2_rptr,
		output reg                 wfull,
		output reg                 awfull,
		output wire [ADDRSIZE-1:0] waddr,
		output reg  [ADDRSIZE  :0] wptr
	);

    reg  [ADDRSIZE:0] wbin;
    wire [ADDRSIZE:0] wgraynext, wbinnext, wgraynextp1;
    wire              awfull_val, wfull_val;

    wire              wen;
    wire [ADDRSIZE:0] wbin_p1, wbin_p2;
    wire [ADDRSIZE:0] wgray_p0, wgray_p1, wgray_p2;
    wire [ADDRSIZE:0] wtarget;
    wire              weq0, weq1, weq2;

	// GRAYSTYLE2 pointer
	always @(posedge wclk or negedge wrst_n) begin

		if (!wrst_n)
			{wbin, wptr} <= 0;
		else
			{wbin, wptr} <= {wbinnext, wgraynext};

	end

    // Memory write-address pointer (okay to use binary to address memory)
    assign waddr = wbin[ADDRSIZE-1:0];
    assign wen       = winc & ~wfull;
    assign wbin_p1   = wbin + 1'b1;
    assign wbin_p2   = wbin + 2'd2;
    assign wgray_p0  = (wbin    >> 1) ^ wbin;
    assign wgray_p1  = (wbin_p1 >> 1) ^ wbin_p1;
    assign wgray_p2  = (wbin_p2 >> 1) ^ wbin_p2;
    assign wbinnext    = wen ? wbin_p1  : wbin;
    assign wgraynext   = wen ? wgray_p1 : wgray_p0;
    assign wgraynextp1 = wen ? wgray_p2 : wgray_p1;

    //------------------------------------------------------------------
    // Simplified version of the three necessary full-tests:
    // assign wfull_val=((wgnext[ADDRSIZE] !=wq2_rptr[ADDRSIZE] ) &&
    //                   (wgnext[ADDRSIZE-1]  !=wq2_rptr[ADDRSIZE-1]) &&
    // (wgnext[ADDRSIZE-2:0]==wq2_rptr[ADDRSIZE-2:0]));
    //------------------------------------------------------------------

     assign wtarget = {~wq2_rptr[ADDRSIZE:ADDRSIZE-1],wq2_rptr[ADDRSIZE-2:0]};
     assign weq0 = (wgray_p0 == wtarget);
     assign weq1 = (wgray_p1 == wtarget);
     assign weq2 = (wgray_p2 == wtarget);
     assign wfull_val  = wen ? weq1 : weq0;
     assign awfull_val = wen ? weq2 : weq1;

     always @(posedge wclk or negedge wrst_n) begin

        if (!wrst_n) begin
            awfull <= 1'b0;
            wfull  <= 1'b0;
        end else begin
            awfull <= awfull_val;
            wfull  <= wfull_val;
        end
    end

endmodule

`resetall
