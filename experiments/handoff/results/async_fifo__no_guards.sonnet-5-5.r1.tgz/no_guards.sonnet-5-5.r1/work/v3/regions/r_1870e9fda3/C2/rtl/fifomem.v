// distributed under the mit license
// https://opensource.org/licenses/mit-license.php

`timescale 1 ns / 1 ps
`default_nettype none
module fifomem

    #(
        parameter  DATASIZE = 8,    // Memory data word width
        parameter  ADDRSIZE = 4,    // Number of mem address bits
        parameter  FALLTHROUGH = "TRUE" // First word fall-through
    ) (
        input  wire                wclk,
        input  wire                wclken,
        input  wire [ADDRSIZE-1:0] waddr,
        input  wire [DATASIZE-1:0] wdata,
        input  wire                wfull,
        input  wire                rclk,
        input  wire                rclken,
        input  wire [ADDRSIZE-1:0] raddr,
        output wire [DATASIZE-1:0] rdata
    );

    localparam DEPTH = 1<<ADDRSIZE;

    reg [DATASIZE-1:0] mem [0:DEPTH-1];
    reg [DATASIZE-1:0] rdata_r;

    // Two-level predecode: low/high address halves decoded independently,
    // with the write gate folded into the (small) high-half decode so each
    // word enable is a single AND2 of two predecoded lines.
    localparam LO_BITS = ADDRSIZE/2;
    localparam HI_BITS = ADDRSIZE - LO_BITS;
    localparam LO_N    = 1<<LO_BITS;
    localparam HI_N    = 1<<HI_BITS;

    wire             write_go  = wclken & ~wfull;
    wire [LO_N-1:0]  lo_dec    = {{(LO_N-1){1'b0}}, 1'b1} << waddr[LO_BITS-1:0];
    wire [HI_N-1:0]  hi_dec    = {{(HI_N-1){1'b0}}, 1'b1} << waddr[ADDRSIZE-1:LO_BITS];
    wire [HI_N-1:0]  hi_dec_g  = hi_dec & {HI_N{write_go}};
    reg  [DEPTH-1:0] word_we;
    integer          wi;
    integer          wj;

    always @* begin
        for (wj = 0; wj < DEPTH; wj = wj + 1)
            word_we[wj] = hi_dec_g[wj >> LO_BITS] & lo_dec[wj & (LO_N-1)];
    end

    always @(posedge wclk) begin
        for (wi = 0; wi < DEPTH; wi = wi + 1)
            if (word_we[wi]) mem[wi] <= wdata;
    end

    generate
        if (FALLTHROUGH == "TRUE")
        begin : fallthrough
            assign rdata = mem[raddr];
        end
        else
        begin : registered_read
            always @(posedge rclk) begin
                if (rclken)
                    rdata_r <= mem[raddr];
            end
            assign rdata = rdata_r;
        end
    endgenerate

endmodule

`resetall
