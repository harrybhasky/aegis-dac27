// distributed under the mit license
// https://opensource.org/licenses/mit-license.php

`timescale 1 ns / 1 ps
`default_nettype none
module wptr_full

	#(
		parameter ADDRSIZE = 4
	)(
		input  wire                wclk,
		input  wire                wrst_n,
		input  wire                winc,
		input  wire [ADDRSIZE  :0] wq2_rptr,
		output reg                 wfull,
		output reg                 awfull,
		output wire [ADDRSIZE-1:0] waddr,
		output reg  [ADDRSIZE  :0] wptr
	);

    reg  [ADDRSIZE:0] wbin;
    wire [ADDRSIZE:0] wgraynext, wbinnext, wgraynextp1;
    wire              awfull_val, wfull_val;

    // Precomputed candidates (independent of the late winc/wfull enable)
    wire [ADDRSIZE:0] b1, b2, g0, g1, g2, tgt;
    wire              en, eq0, eq1, eq2;

	// GRAYSTYLE2 pointer
	always @(posedge wclk or negedge wrst_n) begin

		if (!wrst_n)
			{wbin, wptr} <= 0;
		else
			{wbin, wptr} <= {wbinnext, wgraynext};

	end

    // Memory write-address pointer (okay to use binary to address memory)
    assign waddr = wbin[ADDRSIZE-1:0];

    assign en  = winc & ~wfull;
    assign b1  = wbin + 1'b1;
    assign b2  = wbin + 2'd2;
    assign g0  = (wbin >> 1) ^ wbin;
    assign g1  = (b1 >> 1) ^ b1;
    assign g2  = (b2 >> 1) ^ b2;

    assign wbinnext    = en ? b1 : wbin;
    assign wgraynext   = en ? g1 : g0;
    assign wgraynextp1 = en ? g2 : g1;

    //------------------------------------------------------------------
    // Simplified version of the three necessary full-tests:
    // assign wfull_val=((wgnext[ADDRSIZE] !=wq2_rptr[ADDRSIZE] ) &&
    //                   (wgnext[ADDRSIZE-1]  !=wq2_rptr[ADDRSIZE-1]) &&
    // (wgnext[ADDRSIZE-2:0]==wq2_rptr[ADDRSIZE-2:0]));
    //------------------------------------------------------------------

     assign tgt = {~wq2_rptr[ADDRSIZE:ADDRSIZE-1],wq2_rptr[ADDRSIZE-2:0]};
     assign eq0 = (g0 == tgt);
     assign eq1 = (g1 == tgt);
     assign eq2 = (g2 == tgt);

     assign wfull_val  = en ? eq1 : eq0;
     assign awfull_val = en ? eq2 : eq1;

     always @(posedge wclk or negedge wrst_n) begin

        if (!wrst_n) begin
            awfull <= 1'b0;
            wfull  <= 1'b0;
        end else begin
            awfull <= awfull_val;
            wfull  <= wfull_val;
        end
    end

endmodule

`resetall
