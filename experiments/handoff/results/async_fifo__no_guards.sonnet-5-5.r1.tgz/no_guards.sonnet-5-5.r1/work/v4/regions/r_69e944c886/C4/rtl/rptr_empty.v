// distributed under the mit license
// https://opensource.org/licenses/mit-license.php

`timescale 1 ns / 1 ps
`default_nettype none
module rptr_empty

    #(
    parameter ADDRSIZE = 4
    )(
    input  wire                rclk,
    input  wire                rrst_n,
    input  wire                rinc,
    input  wire [ADDRSIZE  :0] rq2_wptr,
    output reg                 rempty,
    output reg                 arempty,
    output wire [ADDRSIZE-1:0] raddr,
    output reg  [ADDRSIZE  :0] rptr
    );

    reg  [ADDRSIZE:0] rbin;
    wire [ADDRSIZE:0] rgraynext, rbinnext, rgraynextm1;
    wire              arempty_val, rempty_val;
    wire [ADDRSIZE:0] rbinnext_p1;

    //-------------------
    // GRAYSTYLE2 pointer
    //-------------------
    always @(posedge rclk or negedge rrst_n) begin

        if (!rrst_n)
            {rbin, rptr} <= 0;
        else
            {rbin, rptr} <= {rbinnext, rgraynext};

    end

    // Memory read-address pointer (okay to use binary to address memory)
    assign raddr     = rbin[ADDRSIZE-1:0];
    wire              rinc_en     = rinc & ~rempty;
    wire [ADDRSIZE:0] rbin_hold   = rbin;
    wire [ADDRSIZE:0] rbin_inc    = rbin + 1'b1;
    wire [ADDRSIZE:0] rgray_hold  = (rbin_hold >> 1) ^ rbin_hold;
    wire [ADDRSIZE:0] rgray_inc   = (rbin_inc >> 1) ^ rbin_inc;
    wire              req_hold    = (rgray_hold == rq2_wptr);
    wire              req_inc     = (rgray_inc == rq2_wptr);
    assign rbinnext  = rinc_en ? rbin_inc : rbin_hold;
    assign rgraynext = rinc_en ? rgray_inc : rgray_hold;
    assign rbinnext_p1 = rbinnext + 1'b1;
    assign rgraynextm1 = (rbinnext_p1 >> 1) ^ rbinnext_p1;

    //---------------------------------------------------------------
    // FIFO empty when the next rptr == synchronized wptr or on reset
    //---------------------------------------------------------------
    assign rempty_val = rinc_en ? req_inc : req_hold;
    assign arempty_val = (rgraynextm1 == rq2_wptr);

    always @ (posedge rclk or negedge rrst_n) begin

        if (!rrst_n) begin
            arempty <= 1'b0;
            rempty <= 1'b1;
        end
        else begin
            arempty <= arempty_val;
            rempty <= rempty_val;
        end

    end

endmodule

`resetall
