// distributed under the mit license
// https://opensource.org/licenses/mit-license.php

`timescale 1 ns / 1 ps
`default_nettype none
module wptr_full

	#(
		parameter ADDRSIZE = 4
	)(
		input  wire                wclk,
		input  wire                wrst_n,
		input  wire                winc,
		input  wire [ADDRSIZE  :0] wq2_rptr,
		output reg                 wfull,
		output reg                 awfull,
		output wire [ADDRSIZE-1:0] waddr,
		output reg  [ADDRSIZE  :0] wptr
	);

    reg  [ADDRSIZE:0] wbin;
    wire [ADDRSIZE:0] wgraynext, wbinnext, wgraynextp1;
    wire              awfull_val, wfull_val;

    // Shannon-expansion helpers (late signal: wbin[0])
    wire                winc_eff  = winc & ~wfull;
    wire [ADDRSIZE-1:0] upper_p1  = wbin[ADDRSIZE:1] + 1'b1;
    wire [ADDRSIZE:0]   bn_l0     = {wbin[ADDRSIZE:1], winc_eff};
    wire [ADDRSIZE:0]   bn_l1     = winc_eff ? {upper_p1, 1'b0} : {wbin[ADDRSIZE:1], 1'b1};
    wire [ADDRSIZE:0]   gn_l0     = (bn_l0 >> 1) ^ bn_l0;
    wire [ADDRSIZE:0]   gn_l1     = (bn_l1 >> 1) ^ bn_l1;
    wire [ADDRSIZE:0]   bn_l0_p1  = bn_l0 + 1'b1;
    wire [ADDRSIZE:0]   bn_l1_p1  = bn_l1 + 1'b1;
    wire [ADDRSIZE:0]   gp1_l0    = (bn_l0_p1 >> 1) ^ bn_l0_p1;
    wire [ADDRSIZE:0]   gp1_l1    = (bn_l1_p1 >> 1) ^ bn_l1_p1;
    wire [ADDRSIZE:0]   full_cmp  = {~wq2_rptr[ADDRSIZE:ADDRSIZE-1],wq2_rptr[ADDRSIZE-2:0]};
    wire                wfull_l0  = (gn_l0  == full_cmp);
    wire                wfull_l1  = (gn_l1  == full_cmp);
    wire                awfull_l0 = (gp1_l0 == full_cmp);
    wire                awfull_l1 = (gp1_l1 == full_cmp);

	// GRAYSTYLE2 pointer
	always @(posedge wclk or negedge wrst_n) begin

		if (!wrst_n)
			{wbin, wptr} <= 0;
		else
			{wbin, wptr} <= {wbinnext, wgraynext};

	end

    // Memory write-address pointer (okay to use binary to address memory)
    assign waddr = wbin[ADDRSIZE-1:0];
    assign wbinnext    = wbin[0] ? bn_l1  : bn_l0;
    assign wgraynext   = wbin[0] ? gn_l1  : gn_l0;
    assign wgraynextp1 = wbin[0] ? gp1_l1 : gp1_l0;

    //------------------------------------------------------------------
    // Simplified version of the three necessary full-tests:
    // assign wfull_val=((wgnext[ADDRSIZE] !=wq2_rptr[ADDRSIZE] ) &&
    //                   (wgnext[ADDRSIZE-1]  !=wq2_rptr[ADDRSIZE-1]) &&
    // (wgnext[ADDRSIZE-2:0]==wq2_rptr[ADDRSIZE-2:0]));
    //------------------------------------------------------------------

     assign wfull_val  = wbin[0] ? wfull_l1  : wfull_l0;
     assign awfull_val = wbin[0] ? awfull_l1 : awfull_l0;

     always @(posedge wclk or negedge wrst_n) begin

        if (!wrst_n) begin
            awfull <= 1'b0;
            wfull  <= 1'b0;
        end else begin
            awfull <= awfull_val;
            wfull  <= wfull_val;
        end
    end

endmodule

`resetall
