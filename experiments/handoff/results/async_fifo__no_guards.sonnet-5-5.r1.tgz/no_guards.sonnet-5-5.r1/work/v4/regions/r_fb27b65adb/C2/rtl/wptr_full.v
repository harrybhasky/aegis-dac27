// distributed under the mit license
// https://opensource.org/licenses/mit-license.php

`timescale 1 ns / 1 ps
`default_nettype none
module wptr_full

	#(
		parameter ADDRSIZE = 4
	)(
		input  wire                wclk,
		input  wire                wrst_n,
		input  wire                winc,
		input  wire [ADDRSIZE  :0] wq2_rptr,
		output reg                 wfull,
		output reg                 awfull,
		output wire [ADDRSIZE-1:0] waddr,
		output reg  [ADDRSIZE  :0] wptr
	);

    reg  [ADDRSIZE:0] wbin;
    wire [ADDRSIZE:0] wgraynext, wbinnext, wgraynextp1;
    wire              awfull_val, wfull_val;

    // Parallel arithmetic branches (independent of the winc/wfull control)
    wire [ADDRSIZE:0] wbin_p1 = wbin + 1'b1;
    wire [ADDRSIZE:0] wbin_p2 = wbin + 2'd2;
    wire [ADDRSIZE:0] wgray_p0 = (wbin    >> 1) ^ wbin;
    wire [ADDRSIZE:0] wgray_p1 = (wbin_p1 >> 1) ^ wbin_p1;
    wire [ADDRSIZE:0] wgray_p2 = (wbin_p2 >> 1) ^ wbin_p2;
    wire [ADDRSIZE:0] wcmp_tgt = {~wq2_rptr[ADDRSIZE:ADDRSIZE-1],wq2_rptr[ADDRSIZE-2:0]};
    wire              weq_p0 = (wgray_p0 == wcmp_tgt);
    wire              weq_p1 = (wgray_p1 == wcmp_tgt);
    wire              weq_p2 = (wgray_p2 == wcmp_tgt);
    wire              winc_ok = winc & ~wfull;

	// GRAYSTYLE2 pointer
	always @(posedge wclk or negedge wrst_n) begin

		if (!wrst_n)
			{wbin, wptr} <= 0;
		else
			{wbin, wptr} <= {wbinnext, wgraynext};

	end

    // Memory write-address pointer (okay to use binary to address memory)
    assign waddr = wbin[ADDRSIZE-1:0];
    assign wbinnext  = winc_ok ? wbin_p1 : wbin;
    assign wgraynext = winc_ok ? wgray_p1 : wgray_p0;
    assign wgraynextp1 = winc_ok ? wgray_p2 : wgray_p1;

    //------------------------------------------------------------------
    // Simplified version of the three necessary full-tests:
    // assign wfull_val=((wgnext[ADDRSIZE] !=wq2_rptr[ADDRSIZE] ) &&
    //                   (wgnext[ADDRSIZE-1]  !=wq2_rptr[ADDRSIZE-1]) &&
    // (wgnext[ADDRSIZE-2:0]==wq2_rptr[ADDRSIZE-2:0]));
    //------------------------------------------------------------------

     assign wfull_val = winc_ok ? weq_p1 : weq_p0;
     assign awfull_val = winc_ok ? weq_p2 : weq_p1;

     always @(posedge wclk or negedge wrst_n) begin

        if (!wrst_n) begin
            awfull <= 1'b0;
            wfull  <= 1'b0;
        end else begin
            awfull <= awfull_val;
            wfull  <= wfull_val;
        end
    end

endmodule

`resetall
