// distributed under the mit license
// https://opensource.org/licenses/mit-license.php

`timescale 1 ns / 1 ps
`default_nettype none
module wptr_full

	#(
		parameter ADDRSIZE = 4
	)(
		input  wire                wclk,
		input  wire                wrst_n,
		input  wire                winc,
		input  wire [ADDRSIZE  :0] wq2_rptr,
		output reg                 wfull,
		output reg                 awfull,
		output wire [ADDRSIZE-1:0] waddr,
		output reg  [ADDRSIZE  :0] wptr
	);

    reg  [ADDRSIZE:0] wbin;
    wire [ADDRSIZE:0] wgraynext, wbinnext, wgraynextp1;
    wire              awfull_val, wfull_val;

    // Shannon expansion on late signal wbin[0]
    wire              inc = winc & ~wfull;
    wire [ADDRSIZE:0] wbin_b0 = {wbin[ADDRSIZE:1], 1'b0};
    wire [ADDRSIZE:0] wbin_b1 = {wbin[ADDRSIZE:1], 1'b1};
    wire [ADDRSIZE:0] wbn0 = wbin_b0 + {{ADDRSIZE{1'b0}}, inc};
    wire [ADDRSIZE:0] wbn1 = wbin_b1 + {{ADDRSIZE{1'b0}}, inc};
    wire [ADDRSIZE:0] wbn0p1 = wbn0 + 1'b1;
    wire [ADDRSIZE:0] wbn1p1 = wbn1 + 1'b1;
    wire [ADDRSIZE:0] wg0   = (wbn0 >> 1) ^ wbn0;
    wire [ADDRSIZE:0] wg1   = (wbn1 >> 1) ^ wbn1;
    wire [ADDRSIZE:0] wg0p1 = (wbn0p1 >> 1) ^ wbn0p1;
    wire [ADDRSIZE:0] wg1p1 = (wbn1p1 >> 1) ^ wbn1p1;
    wire [ADDRSIZE:0] full_cmp = {~wq2_rptr[ADDRSIZE:ADDRSIZE-1],wq2_rptr[ADDRSIZE-2:0]};
    wire              wf0  = (wg0   == full_cmp);
    wire              wf1  = (wg1   == full_cmp);
    wire              awf0 = (wg0p1 == full_cmp);
    wire              awf1 = (wg1p1 == full_cmp);

	// GRAYSTYLE2 pointer
	always @(posedge wclk or negedge wrst_n) begin

		if (!wrst_n)
			{wbin, wptr} <= 0;
		else
			{wbin, wptr} <= {wbinnext, wgraynext};

	end

    // Memory write-address pointer (okay to use binary to address memory)
    assign waddr = wbin[ADDRSIZE-1:0];
    assign wbinnext    = wbin[0] ? wbn1  : wbn0;
    assign wgraynext   = wbin[0] ? wg1   : wg0;
    assign wgraynextp1 = wbin[0] ? wg1p1 : wg0p1;

    //------------------------------------------------------------------
    // Simplified version of the three necessary full-tests:
    // assign wfull_val=((wgnext[ADDRSIZE] !=wq2_rptr[ADDRSIZE] ) &&
    //                   (wgnext[ADDRSIZE-1]  !=wq2_rptr[ADDRSIZE-1]) &&
    // (wgnext[ADDRSIZE-2:0]==wq2_rptr[ADDRSIZE-2:0]));
    //------------------------------------------------------------------

     assign wfull_val  = wbin[0] ? wf1  : wf0;
     assign awfull_val = wbin[0] ? awf1 : awf0;

     always @(posedge wclk or negedge wrst_n) begin

        if (!wrst_n) begin
            awfull <= 1'b0;
            wfull  <= 1'b0;
        end else begin
            awfull <= awfull_val;
            wfull  <= wfull_val;
        end
    end

endmodule

`resetall
